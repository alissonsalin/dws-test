---
name: lint
description: "Keep code lint-compliant during implementation and run repository-required lint validation across Java, Node.js, and Python workflows."
argument-hint: "Describe the stack, lint tool, and whether you need implementation-time lint compliance or formal lint validation"
---

# Lint Compliance and Validation

## When to Use

- A feature touches files governed by a repository lint tool such as ESLint, Ruff, Flake8, Checkstyle, Spotless, or similar.
- A prior verification attempt failed because of lint violations and the workflow needs a focused remediation loop.
- You need implementation guidance that keeps code aligned with repository lint rules before formal validation runs.
- You need to run the repository-required lint command as part of formal validation.

## Implementation Guidance

- Write code and update files with the repository lint rules in mind.
- Prefer patterns that already exist in the codebase instead of introducing style drift.
- You may use non-gating formatting or autofix commands only when they are safe, targeted, and directly support the implementation.
- Do not treat implementation-time edits or local cleanup as proof that lint has passed.
- Keep formal lint verification separate from implementation work when the surrounding workflow distinguishes between implementation and validation.

## Validation Guidance

- Run the repository-required lint command as part of formal validation.
- Pair lint execution with the repository command-resilience guidance when commands fail.
- If lint fails, capture the failure briefly, fix the material issue, and rerun the validation command.

## Procedure

1. Identify the repository lint tool and the files changed by the feature.
2. Follow the matching language skill first, then apply this lint skill for lint-specific behavior.
3. Keep edits aligned with existing code style, naming, imports, formatting, and file organization.
4. Run one required lint command for the active stack or module when formal validation is needed.
5. If the lint command fails, fix the material issue instead of suppressing the rule unless the repository already uses an approved suppression pattern.
6. Report the lint result briefly: command, pass or fail, affected area, and fix status.

## Stack Guidance

- Java: prefer repository-approved tools such as Checkstyle or Spotless; if coverage tooling also exists, keep that separate from lint.
- Node.js and TypeScript: prefer the repository ESLint command and only use `--fix` when the change is scoped and safe.
- Python: prefer repository tools such as Ruff or Flake8; keep formatter behavior separate unless the repository combines them intentionally.

## Constraints

- Do not disable rules globally to make the build pass.
- Do not introduce new lint tooling as part of a feature unless the task explicitly requires it.
- Do not claim lint compliance from manual inspection alone when the repository expects a lint command to run.
- Keep lint fixes limited to files affected by the task unless a broader fix is explicitly requested.

## Recommended Pairings

- `.github/skills/cli-resilience/SKILL.md` for retry-safe lint command execution.
- `.github/skills/gradle/SKILL.md` for `build.gradle` or `build.gradle.kts` Checkstyle plugin setup in Java projects.
- `.github/skills/java/SKILL.md`, `.github/skills/nodejs/SKILL.md`, or `.github/skills/python/SKILL.md` for language-specific implementation rules.
- `.github/skills/java-cli/SKILL.md` or `.github/skills/node-python-cli/SKILL.md` when lint commands are run in a validation phase.
