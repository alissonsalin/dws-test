#!/usr/bin/env bash

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
SOURCE_GITHUB="$REPO_ROOT/.github"

echo "Copilot instruction installer"
echo
if [ ! -d "$SOURCE_GITHUB" ]; then
  echo "[ERROR] Source folder not found: $SOURCE_GITHUB"
  exit 1
fi

echo "Source: $SOURCE_GITHUB"
read -r -p "Enter target repository path: " TARGET_REPO

if [ -z "${TARGET_REPO:-}" ]; then
  echo "[ERROR] Target repository path is required."
  exit 1
fi

TARGET_REPO="${TARGET_REPO%\"}"
TARGET_REPO="${TARGET_REPO#\"}"

if [ ! -d "$TARGET_REPO" ]; then
  echo "[ERROR] Target repository does not exist: $TARGET_REPO"
  exit 1
fi

TARGET_GITHUB="$TARGET_REPO/.github"
mkdir -p "$TARGET_GITHUB"

TOTAL_FILES=$(find "$SOURCE_GITHUB" -type f | wc -l | tr -d ' ')
TOTAL_DIRS=$(find "$SOURCE_GITHUB" -type d | wc -l | tr -d ' ')
TARGET_FILES=0
TARGET_DIRS=0

echo "[INFO] Copying full .github content (files and folders)..."
if cp -a "$SOURCE_GITHUB/." "$TARGET_GITHUB/"; then
  COPY_STATUS="SUCCESS"
else
  COPY_STATUS="FAILURE"
fi

echo
echo "Install summary"
echo "- Source: $SOURCE_GITHUB"
echo "- Target: $TARGET_GITHUB"
echo "- Source files: $TOTAL_FILES"
echo "- Source folders: $TOTAL_DIRS"

if [ "$TOTAL_FILES" -eq 0 ]; then
  echo "Status: NO_FILES_TO_COPY"
  echo "[WARN] Source .github exists but has no files. Add instruction files and run again."
  exit 1
fi

TARGET_FILES=$(find "$TARGET_GITHUB" -type f | wc -l | tr -d ' ')
TARGET_DIRS=$(find "$TARGET_GITHUB" -type d | wc -l | tr -d ' ')

echo "- Target files: $TARGET_FILES"
echo "- Target folders: $TARGET_DIRS"

if [ "$TARGET_FILES" -lt "$TOTAL_FILES" ]; then
  echo "[ERROR] Target has fewer files than source after copy."
  echo "Status: FAILURE"
  exit 1
fi

if [ "$TARGET_DIRS" -lt "$TOTAL_DIRS" ]; then
  echo "[ERROR] Target has fewer folders than source after copy."
  echo "Status: FAILURE"
  exit 1
fi

if [ "$COPY_STATUS" = "SUCCESS" ]; then
  echo "Status: SUCCESS"
  echo "[SUCCESS] Copilot instruction files were copied successfully."
  echo "[SUCCESS] Project ready: $TARGET_REPO"
  echo "[SUCCESS] You can now use Copilot Chat with project instructions in this repository."
  exit 0
fi

echo "Status: FAILURE"
exit 1
