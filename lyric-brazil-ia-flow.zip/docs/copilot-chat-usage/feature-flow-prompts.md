# Feature Flow Prompts

Start the flow by selecting the `feature-flow` agent or using `@feature-flow` in chat.

Use your first prompt to clearly define:

1. Feature name and goal
2. Requirement source
3. Expected output for Step 1
4. Language or stack, if known

## Example A: Feature Details From Files

Start a new feature flow for Customer Notification Rules.
Source type: file.
Use feature details from docs/requirements/customer-notification-rules.md.
Execute Step 1 and provide a clear Requirement Summary.

## Example B: Feature Details From Jira

Start a new feature flow for Payment Retry Policy.
Source type: Jira.
Use Jira ticket PAY-2487 as the requirement source.
Run Step 1 and summarize scope, assumptions, and success criteria.

## Example C: Feature Details From Confluence

Start a new feature flow for Contract Expiration Alerts.
Source type: Confluence.
Use page Product / Alerts / Contract Expiration v2.
Run Step 1 and summarize all functional and non-functional requirements.

## Example D: Feature Details From User Input

Start a new feature flow for Self-Service Password Reset.
Source type: user input.
Feature details:
- User requests reset by email
- Token valid for 15 minutes
- Max 3 attempts
- Audit logs required
Run Step 1 and produce a requirement summary.

## Continue Through Steps

After Step 1 is complete, you can either continue step by step or use the shortcut `Implement this` to let the agent continue through the remaining steps automatically.

Typical Step 5 question you may see in non-autonomous mode:
Step 5 gate: Do you want to run security validation for this feature?

## Next

Continue to [Tech Refresh Orchestrator Prompts](tech-refresh-orchestrator-prompts.md).