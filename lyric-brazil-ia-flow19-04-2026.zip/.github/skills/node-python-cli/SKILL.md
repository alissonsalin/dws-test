---
name: node-python-cli
description: "Run Node.js or Python workflow commands with preflight checks, fix-driven retries, and concise remediation tracking. Use when Node.js or Python verification or test commands need resilient execution."
argument-hint: "Describe the stack, workflow phase, target command, and current failure if any"
---

# Node and Python Command Resilience Rules

## When to Use

- A Node.js or Python verification command is about to run.
- A Node.js or Python test command fails and needs fix-driven retries.
- You need stack-specific preflight checks before running the target command.

## Preflight Checks

- Confirm required tools are in PATH.
- Confirm expected files exist, such as `package.json`, `pyproject.toml`, or `requirements.txt`.
- Confirm the working directory context.
- If preflight fails, fix the environment or command context first.

## Retry and Remediation Policy

- Follow `.github/instructions/command-resilience.instructions.md` as the shared baseline.
- Keep commands minimal, non-interactive, and fix-driven; continue remediation for recoverable errors, do not rerun unchanged failures, and do not mark recoverable command errors as failed workflow steps.

## Node Package Manager Detection

- Determine the package manager once from repository signals before selecting Node.js test commands:
	- `pnpm-lock.yaml` -> `pnpm`
	- `yarn.lock` -> `yarn`
	- `package-lock.json` or `npm-shrinkwrap.json` -> `npm`

## Approved Test Command Selection

### Node.js

- Read `package.json` scripts and use the first matching approved script in this order:
	- coverage run: `test:coverage`
	- CI-oriented run: `test:ci`
	- baseline run: `test`
- Use the matching package-manager command exactly:
	- `npm run test:coverage`, `npm run test:ci`, or `npm test`
	- `pnpm run test:coverage`, `pnpm run test:ci`, or `pnpm test`
	- `yarn test:coverage`, `yarn test:ci`, or `yarn test`
- Do not call `jest`, `vitest`, `mocha`, or another test runner directly when a project script already exists.
- If no test script exists, stop and inspect repository docs or existing tasks before inventing a direct runner command.

### Python

- Prefer the repository-defined Python test command when one is documented in the README, Makefile, task runner, or project scripts.
- If no wrapper command is documented, select the command from project signals:
	- if `pytest` is configured or implied by `pyproject.toml`, `pytest.ini`, or `tox.ini`, use `python -m pytest`
	- if coverage is required and `pytest-cov` is configured, use `python -m pytest --cov --cov-report=term-missing --cov-report=html`
- Do not switch between `pytest`, `unittest`, `tox`, `nox`, or ad-hoc module commands unless repository configuration clearly requires that tool.
- Prefer `python -m pytest` over bare `pytest` to avoid environment-path drift.

## Security Command Handling

- Use `.github/skills/security/SKILL.md` for Node.js and Python security validation command selection and fallback rules.

## Reporting

- After each attempt, summarize the command executed, key result, fix applied, and next action.
- Capture repeated failure patterns and successful fixes in improvement notes.