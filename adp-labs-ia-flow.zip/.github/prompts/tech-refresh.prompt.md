---
mode: ask
description: "Use for tech refresh initiatives (e.g., NodeJS to Java) that require prerequisite analysis before running the standard Step 1 to Step 9 workflow."
---

# Tech Refresh Workflow (Opt-in)

Use this prompt only for technology refresh initiatives.
Do not modify or replace the default feature workflow.

## Execution Rules

1. Run Phase A first.
2. Do not start Step 1 to Step 9 until Phase A is completed and user approval is explicitly captured.
3. After approval, run the repository standard Step 1 to Step 9 checklist and status updates exactly as defined by existing instructions.
4. Keep this workflow non-destructive by default and ask before any risky operation.

## Phase A - Mandatory Prerequisite Analysis

### A0. Target Java Project Path (Mandatory)

Ask first:

Please share the Java project path where the migrated code should be implemented.

1. ✅ I will paste the full absolute path
2. 📁 Use a folder inside current workspace (provide folder name)
3. ❌ I do not have a Java project yet and want a suggested structure first

- Do not start A1 to A5 until this path decision is captured.
- If the path is missing or ambiguous, ask again.

### A1. Scope and Current State Analysis

- Identify source system boundaries and modules.
- Map APIs, background jobs, event consumers/producers, integrations, and database dependencies.
- Capture baseline behavior and non-functional metrics (latency, throughput, resource usage, error profile).

### A2. Code and Architecture Analysis

- Assess code complexity, coupling, and framework lock-in points.
- Identify migration blockers (unsupported libraries, hidden side effects, runtime assumptions).
- Classify components by migration risk: low, medium, high.

### A3. Migration Plan

- Propose migration strategy per component:
  - Strangler migration for high-risk paths.
  - Parallel run or shadow validation where possible.
  - Big bang migration only for small isolated areas.
- Define migration waves with order, dependencies, and rollback criteria.
- Define compatibility strategy for API contracts, data models, and operational behavior.

### A4. Validation Plan

- Define parity validation for:
  - Functional behavior.
  - API contracts (request, response, error format).
  - Data consistency and idempotency.
  - Security controls.
  - Performance and scalability.
- Define verification evidence required before cutover.

### A5. Approval Gate (Hard Stop)

Ask:

Would you like to proceed to Step 1 to Step 9 using this approved analysis?

1. ✅ Yes
2. ❌ No

- If yes, continue to Step 1 with checklist status tracking.
- If no, refine Phase A and ask again.

## Phase B - Standard Step 1 to Step 9

After approval in A5:

- Execute the repository standard Step 1 to Step 9 workflow in order.
- Keep all required gates and checklist icons.
- Preserve design-first enforcement and command-resilience rules.
- Keep Step 9 mandatory.
