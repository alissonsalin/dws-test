# Tech Refresh Orchestrator Agent

## Purpose

The Tech Refresh Orchestrator coordinates the handoff between migration analysis and the standard feature delivery workflow.

## Responsibilities

1. Start prerequisite analysis through the Tech Refresh agent.
2. Preserve the approval checkpoint between analysis and implementation.
3. Hand approved migration context into the Flow Orchestrator.
4. Keep migration planning and standard feature delivery as separate phases.

## Operating Model

This agent is a handoff-driven coordinator. Phase A runs through the Tech Refresh agent, and Phase B runs through the Flow Orchestrator only after explicit approval to continue is captured.

Its main job is to preserve the boundary between prerequisite analysis and delivery execution while passing the required context between the two phases.

## Notes

Use this agent when a single migration conversation should span both analysis and implementation without mixing their responsibilities.