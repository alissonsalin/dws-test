# Agents

## Purpose

This page documents the custom agents used in this repository. Agents are responsible for workflow orchestration, tool usage rules, and role-specific execution behavior.

## When To Use Agents

Use an agent when you need:

- end-to-end workflow sequencing
- explicit tool expectations or restrictions
- autonomous execution behavior
- a focused role for a recurring workflow

## Agent File Structure

An agent file starts with YAML frontmatter between `---` markers. This header defines how VS Code discovers the agent, what it can call, and what handoff buttons are exposed before the instruction body begins.

### Example

```yaml
---
description: "Use to orchestrate tech refresh work through explicit handoffs."
tools: [read, agent, todo]
agents: [tech-refresh, feature-flow]
argument-hint: "Describe the migration scope, current system/module, target stack, and source references."
handoffs:
	- label: Start Prerequisite Analysis
		agent: tech-refresh
		prompt: "Start prerequisite tech refresh analysis only."
		send: true
---
```

### Header Fields

| Field | Purpose | Notes |
|---|---|---|
| `description` | Discovery text for the agent picker and model routing. | Write this as the trigger surface: include "Use when..." language and the workflows or keywords that should activate the agent. |
| `tools` | Declares which tool groups the agent is allowed to use. | Keep this minimal. Only include the capabilities the agent actually needs. |
| `agents` | Lists the other custom agents this agent can invoke directly through the agent tool. | This is for subagent-style delegation. It is separate from `handoffs:` and is not the button definition itself. |
| `argument-hint` | Short UI hint shown to the user when they are about to invoke the agent. | Use this to ask for the minimum context the workflow needs. |
| `handoffs` | Defines explicit handoff buttons shown in the agent UI. | Use this when the workflow should move the user into another agent intentionally and visibly. |

### Handoff Fields

| Field | Purpose | Notes |
|---|---|---|
| `label` | Text shown on the handoff button. | Keep it action-oriented and short. |
| `agent` | The target agent that receives the handoff. | This must match the target custom agent name exactly. |
| `prompt` | The instruction payload sent with the handoff. | Be explicit about scope, stop conditions, and required return fields when chaining workflows. |
| `send` | Controls whether current conversation context is sent with the handoff. | Use `true` when the next agent needs the current chat context; use `false` when the target should rely on the prompt and already-captured context only. |

### Field Relationships

1. Use `description` to make the agent discoverable.
2. Use `tools` to constrain what the agent can do.
3. Use `agents` only when the agent may call other agents programmatically through the agent tool.
4. Use `handoffs` when you want explicit UI buttons for a visible workflow transition.
5. An agent can define both `agents` and `handoffs` when it needs both direct delegation and button-based transitions.

### Notes

1. Keep the frontmatter focused on capability and routing; keep detailed workflow rules in the body below the header.
2. Quote long `description`, `argument-hint`, and `prompt` values to avoid YAML parsing issues.
3. If the agent file exposes handoff buttons, document the approval rules and stop conditions in the body so the handoff semantics stay unambiguous.

## Agent in This Repository

### `.github/agents/feature-flow.agent.md`

- Primary feature delivery agent for the repository.
- Owns the Step 1 to Step 9 workflow.
- Controls design-first behavior, checklist updates, gates, tool usage, troubleshooting flow, and Step 9 follow-through.
- Is invoked through the agent picker or with `@feature-flow` in chat.

### `.github/agents/tech-refresh.agent.md`

- Migration-analysis agent for technology refresh initiatives.
- Owns prerequisite analysis, migration planning, validation planning, and approval readiness.
- Stops before normal feature delivery unless explicitly continued.

### `.github/agents/tech-refresh-orchestrator.agent.md`

- Handoff-based migration coordinator for this repository.
- Starts with `tech-refresh` for prerequisite analysis, then continues with `feature-flow` after explicit approval.
- Is the preferred entry point when you want a single migration conversation that preserves the boundary between analysis and delivery.

## What The Feature Agent Controls

- startup behavior and deferred backlog carry-forward
- TODO list initialization and updates
- design approval and gate handling
- implementation sequencing
- language skill activation during implementation phases
- command execution behavior
- validation, troubleshooting, and continuous improvement flow

## What The Tech Refresh Orchestrator Controls

- handoff sequencing between migration analysis and feature delivery
- explicit approval checkpoint between the two handoffs
- passing approved migration context into the standard feature workflow
- keeping tech refresh and feature flow responsibilities separate instead of mixing them into one agent

## What Should Stay Out of Agents

- deep language-specific implementation rules
- file-pattern-specific guidance better expressed with `applyTo`
- narrow, opt-in remediation workflows better handled by skills

## Relationship To Other Customizations

1. `.github/copilot-instructions.md` points feature work to the feature agent.
2. `.github/instructions/*.instructions.md` provide technical detail when file scopes match.
3. `.github/skills/*/SKILL.md` provide specialized on-demand workflows that complement the agent.

For implementation work, the agent is expected to use the user's explicit language choice when provided, otherwise detect the target stack at the start of implementation, load one primary implementation baseline skill, and then add supporting skills only when the feature needs them.

## Related References

- [Custom Instructions](custom-instructions.md)
- [Skills](skills.md)
- [Tech Refresh](tech-refresh.md)
- [Flow - Overview](../flow/flow.md)
- [Flow - Step 4](../flow/step-4.md)