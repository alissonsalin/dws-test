# IDE Setup

After installation, set up and verify your IDE environment.

## Visual Studio Code

1. Open the target repository in Visual Studio Code.
2. Confirm these paths exist:
   - .github/copilot-instructions.md
   - .github/instructions/
   - .github/agents/
   - .github/skills/
3. Ensure GitHub Copilot and Copilot Chat extensions are installed and authenticated.
4. Open Copilot Chat and start a new chat session.

## IntelliJ IDEA

1. Open the target repository in IntelliJ IDEA.
2. Confirm these paths exist:
   - .github/copilot-instructions.md
   - .github/instructions/
   - .github/agents/
   - .github/skills/
3. Ensure the GitHub Copilot plugin is installed and authenticated.
4. Open GitHub Copilot Chat and start a new chat session.
5. If you plan to run the feature workflow agents, open the chat tool configuration and enable Built-in tools for `flow-orchestrator`, `planner`, and `coder`.
6. In the Configure Tools dialog, keep all Built-in tools enabled for those agents unless your environment requires a narrower policy.
7. Pay special attention to the tools needed for file editing, search, terminal execution, validation, and subagent delegation.
8. If the agent starts explaining changes instead of editing files or running commands, re-open Configure Tools and confirm the Built-in tools are still enabled.

## Next Step

Go to [Copilot Usage](copilot-usage.md).