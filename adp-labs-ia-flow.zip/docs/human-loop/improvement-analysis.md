# Improvement Analysis

## Why This Section Matters

At the end of the workflow, humans extract lessons and decide what to improve now versus later.

Not every improvement should be implemented immediately. Process quality grows when teams intentionally prioritize improvements and capture deferred ideas in a visible backlog.

## What Human Interaction Improves

- Prioritizes high-value process improvements.
- Distinguishes immediate fixes from deferred backlog ideas.
- Creates reusable guidance for future features and migrations.
- Strengthens consistency across sessions and contributors.

## Recommended Checkpoints

1. Summarize what worked and what did not.
2. Classify improvements as apply-now or defer.
3. Capture command or workflow failures for reuse.
4. Confirm closure criteria before final handoff.

## Related

- [Human Interaction Diagram](human-interaction-diagram.md)