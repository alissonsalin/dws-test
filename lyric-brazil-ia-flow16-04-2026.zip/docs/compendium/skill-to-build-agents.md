# Skill to Build Agents

## Purpose

This page captures the core capabilities and practices required to design and maintain effective agents.

## Core Skills

1. System Design: Build an architecture where the LLM, tools, databases, and sub-agents work together as a coherent system.
2. Tool and Contract Design: Define strict tool schemas and contracts so agents use valid inputs and predictable outputs.
3. Retrieval Engineering: Improve retrieval quality through better chunking, embeddings, and re-ranking so agents receive strong context.
4. Reliability Engineering: Apply retries, backoff, timeouts, and circuit breakers so the system handles failures gracefully.
5. Security and Safety: Protect the agent against prompt injection, enforce permission boundaries, and filter unsafe output.
6. Evaluation and Observability: Use tracing and automated evaluation to measure quality, debug failures, and improve from evidence.
7. Product Thinking: Design agent interactions to communicate clearly, handle errors well, and build user trust.

## Notes

Use this page to document the practical skills needed to create agents that are useful, constrained, maintainable, and trustworthy.