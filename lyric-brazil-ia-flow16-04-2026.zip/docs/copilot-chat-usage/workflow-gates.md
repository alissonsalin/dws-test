# Workflow Gates

Copilot must stop and ask at specific gates instead of assuming.

## Mandatory Gates

1. Step 2 completion gate before implementation.
   - Copilot must not implement code before Step 2 technical design is complete.
2. Step 5 security-validation gate.
   - By default, security validation is skipped unless it was explicitly requested.
   - In interactive mode, Copilot asks once whether to run security validation before executing the approved security command.
   - If the decision is no or the step was not requested, Step 5 is skipped and the reason is recorded.
   - If the approved Java command is a dedicated CVE task, Copilot reports CVE findings explicitly.
3. Step 9 improvement decision gate.
   - At the end of Step 9, Copilot asks whether to apply improvements now or save them for later.
4. Destructive or ambiguous operations.
   - Copilot pauses for explicit confirmation before destructive or ambiguous actions.
5. Java version ambiguity gate.
   - If Java detection output is ambiguous, Copilot must ask for explicit version confirmation.

## Checklist Visibility

When a feature workflow starts, Copilot continuously shows a full checklist with one status per step.

Status icons:

1. ✅ completed
2. 🔄 in-progress
3. ⏳ pending
4. ❌ failed or blocker
5. ⏭ skipped

Copilot also provides short progress updates while it works, then summarizes what changed, what passed, and what remains.

## Next

Continue to [Command Behavior](command-behavior.md).