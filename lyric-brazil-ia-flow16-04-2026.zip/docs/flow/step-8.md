# Step 8: Troubleshooting and Debugging

## Mandatory Delegation

This step is performed by the `diagnostics` agent. The agent must analyze the technical design and final implementation to generate code-based log queries and health check procedures. Reference the feature's design document and existing troubleshooting guides for context.

## Purpose

This step creates the feature support documentation for troubleshooting and debugging. It uses the outputs from Steps 1 through 4 to capture root causes, fixes, validation points, and production investigation guidance.

## Why This Step Matters

Ignoring issues:
- Leads to problems in production that could have been caught
- Wastes time on unrelated debugging later
- Reduces user confidence in the feature
- Prevents learning from mistakes

Systematic troubleshooting documentation:
- Identifies root causes (not just symptoms)
- Fixes problems completely, not just temporarily
- Provides insights for production monitoring
- Builds team knowledge

## What You'll Do

1. **Use Planner for This Step**:
   - Keep Step 8 as a documentation step
   - Use `planner` to produce the troubleshooting content
   - Use outputs from Steps 1 through 4 as the source material

2. **Identify Issues** — Issues may come from:
   - Failed tests during Step 6
   - Design mismatches discovered in Step 7
   - Performance problems under load testing
   - Security vulnerabilities missed in Step 5
   - Integration problems with external systems

3. **Root Cause Analysis**:
   - **Reproduce the issue**: Can you reliably trigger it with specific input?
   - **Isolate the problem**: Is it in your code, a dependency, or infrastructure?
   - **Trace the execution**: Use logs and debugging tools to follow the code path
   - **Ask why repeatedly**: Keep asking "why?" until you find the root cause

   Example:
   ```
   Problem: Login endpoint returns 500 error
   Why? → Database query failed
   Why? → User table doesn't exist in test database
   Why? → Migration script wasn't run before tests
   Root Cause: Test setup doesn't run migrations
   Fix: Update test configuration to run migrations before test suite
   ```

4. **Use Logs and Debugging Tools**:
   - Review application logs for error messages and stack traces
   - Use a debugger to step through code and inspect variables
   - Check database state and query performance
   - Monitor system resources (CPU, memory) for performance issues

5. **Propose and Implement Fixes**:
   - Propose a fix that addresses the root cause (not just the symptom)
   - Implement the fix in code
   - Verify the fix with a focused test
   - Re-run full test suite to ensure no regressions

6. **Re-Validate**:
   - Run all tests again to confirm the fix works
   - Verify that no new issues were introduced
   - Update tests if the issue reveals a missing test case

7. **Document the Issue**:
   - Record what went wrong and how it was fixed
   - Update the technical design document with any architectural changes when needed
   - Note any edge cases to test in similar features
   - Create or update `documentation/<feature-name>/<feature-name>-troubleshooting.md`

## Production Monitoring and Observability

For production deployment, create monitoring and debugging tools:

### Logging Queries (Example)

For Java with Slf4j and aggregated logging (Splunk, ELK, etc.):

```java
// Log login attempts and outcomes
logger.info("Login attempt", 
    kv("user_email", email),
    kv("status", result ? "success" : "failed"),
    kv("timestamp", System.currentTimeMillis())
);

// Log errors with context
logger.error("Database connection failed",
    kv("database", "users_db"),
    kv("retry_attempt", retryCount),
    kv("error", e.getMessage())
);
```

### Splunk Query Examples

```
source=application.log login_attempt
| stats count by status
| timechart count by status

source=application.log error
| grep "Database connection failed"
| stats count by database
```

### Circuit Breaker Monitoring

If using Resilience4j:
```java
circuitBreaker.onEvent(event -> 
    logger.warn("Circuit breaker state change",
        kv("name", "external-api"),
        kv("state", event.getStateTransition().getToState()),
        kv("timestamp", System.currentTimeMillis())
    )
);
```

## Output

- All identified issues have been root-cause analyzed and fixed
- Full test suite passes after fixes
- Documentation of issues and solutions in the troubleshooting document
- Splunk queries based on the logs generated in the implemented code
- Lessons learned recorded for team knowledge

## When To Proceed

Before moving to Step 9:
- All issues discovered have been investigated and fixed
- Tests pass consistently
- Root causes are understood
- Production monitoring is in place
- Team understands what to watch for in production

---

**Previous Step:** [Step 7 - Compare and Adjust](step-7.md)  
**Next Step:** [Step 9 - Continuous Improvement](step-9.md)
