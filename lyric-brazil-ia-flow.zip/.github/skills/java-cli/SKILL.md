---
name: java-cli
description: "Run Java workflow commands with repository-approved Java version detection, Gradle Wrapper preference, and Step 4 timing rules. Use when starting Java implementation, build verification, or Java security validation."
argument-hint: "Describe the Java workflow phase, command goal, and any current command failure"
---

# Java Command Execution Rules

Use this skill for Java-specific command timing and environment decisions.

## When to Use

- Step 4 Java implementation is starting.
- You need to choose or run a Java build, test, or security command.
- You need the repository-approved Java version detection flow.

## Command Selection Rules

- Prefer Gradle Wrapper over system Gradle.
- Run commands from the project root unless a different path is explicitly required.
- Keep command usage minimal and goal-oriented.
- Avoid destructive commands unless explicitly requested.
- Do not use interactive commands when a non-interactive alternative exists.

## Commands by Phase

- For new Java projects, or when the project is not yet buildable, add or update required `build.gradle` or `build.gradle.kts` dependencies and plugins during Step 4.
- Complete framework bootstrap and required dependency setup before running validation or verification commands.
- If missing dependencies or plugins are the reason a command would fail, fix the build configuration first instead of discovering the gap later.
- Treat Step 4 dependency or plugin changes as the trigger for later dependency-security validation.
- For new Java projects, or when Java coverage setup changes, follow `.github/skills/jacoco/SKILL.md` for required JaCoCo plugin, task, verification, and lifecycle expectations.

## Approved Java Test Commands

- Use Gradle Wrapper as the default Java test runner for this repository.
- Run Java test commands from the project root.
- Approved Java test-and-coverage command:
	- Windows: `.\\gradlew test jacocoTestReport jacocoTestCoverageVerification`
	- macOS and Linux: `./gradlew test jacocoTestReport jacocoTestCoverageVerification`
- Use `.github/skills/jacoco/SKILL.md` for JaCoCo report expectations, coverage thresholds, and required Gradle build wiring.
- Do not split Step 6 into multiple equivalent Gradle test commands. Use the single approved verification command.
- Do not switch to `gradle test`, Maven commands, IDE-only test actions, or direct JUnit runners unless the repository build tool is different or the user explicitly asks for that change.
- Do not invent alternate Java test commands when the wrapper and Gradle tasks are already available.

## Approved Java Security Commands

- Use Gradle Wrapper as the default Java security-validation runner for this repository.
- Run Java security commands from the project root.
- Use dependency-security validation only when the build changed because dependencies or plugins were added or updated, or when the user explicitly asks for CVE validation.
- Approved Java dependency update and vulnerability command:
	- Windows: `.\\gradlew dependencyUpdates`
	- macOS and Linux: `./gradlew dependencyUpdates`
- If the repository later adopts a dedicated CVE plugin or task, use that repository-defined wrapper task instead of inventing a new command.
- Do not switch to `gradle dependencyUpdates`, Maven dependency commands, IDE inspections, or ad-hoc scanners when the approved wrapper command is available.
- Do not run multiple overlapping Java security commands in the same Step 5 cycle unless the repository explicitly defines them.

## Java Environment Inspection

- Windows: `java -version`
- macOS and Linux: `java --version`
- Run this inspection exactly once at the start of Step 4 for each Java feature workflow.
- Do not run the inspection again later unless the user explicitly requests it.
- Parse the first version token into a major Java version.
- If the detected major version is 21 or higher, use that detected major version for project Java configuration.
- If the detected major version is lower than 21, configure the project to Java 21 and note that local JDK upgrade is required for runtime execution.
- If parsing fails or output is ambiguous, ask for explicit version confirmation before changing Java version settings.

## Retry and Reporting

- Follow `.github/instructions/command-resilience.instructions.md` for shared preflight checks, retry behavior, and failure reporting.
- Summarize results in plain language after execution.
- Highlight only the relevant lines: pass/fail status, errors, warnings, and artifact paths.