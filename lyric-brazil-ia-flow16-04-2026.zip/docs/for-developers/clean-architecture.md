# Clean Architecture

## Purpose

Clean architecture keeps business logic independent from frameworks, transport layers, and infrastructure details.

## Layer Model

1. `domain`: core business entities and rules.
2. `usecase`: application orchestration and business use cases.
3. `adapter`: boundary mapping (controllers, request/response conversion).
4. `gateway`: infrastructure integrations (database, external APIs, file systems, queues).

## Responsibility Matrix

1. `domain`
	- Entities, value objects, business invariants.
	- No framework imports.
	- No transport/persistence concerns.
2. `usecase`
	- Coordinates domain behavior.
	- Defines interfaces for external dependencies.
	- Owns business-level validation and error mapping.
3. `adapter`
	- Input/output conversion only.
	- HTTP/controller logic, request validation at boundary.
	- Delegates business decisions to use cases.
4. `gateway`
	- Implements outbound interfaces (DB/API/queue/file).
	- Handles retries/timeouts/mapping of external contracts.

## Dependency Direction

- Outer layers may depend on inner layers.
- Inner layers must not depend on outer layers.
- `domain` must remain independent from frameworks and infrastructure.
- Interfaces belong to the business flow (`usecase`), with implementations in `gateway`.

## Data Contract Rules

- Use explicit request/response models between layers.
- Avoid passing framework objects (HTTP request, ORM entities) into `domain`/`usecase`.
- Keep serialization concerns in adapters.

## Common Anti-Patterns To Avoid

1. Business logic inside controllers.
2. Direct database calls from `usecase` without an interface boundary.
3. Domain objects annotated with framework-specific persistence/web annotations (unless strictly required and justified).
4. Shared utility classes that bypass architecture boundaries.

## Practical Validation Checklist

- Controllers map inputs/outputs and delegate only.
- Use case tests run without web/database runtime.
- Gateway tests validate integration mapping and error translation.
- Architecture tests enforce forbidden dependencies.

## Related Technical References

- [Arch Unit](../technologies/arch-unit.md)
- [Java](../technologies/java.md)
- [NodeJS](../technologies/nodejs.md)
- [Python](../technologies/python.md)

## Related Flow Steps

- [Step 4 - Start Implementation](../flow/step-4.md)
- [Step 6 - Create Unit Tests](../flow/step-6.md)
- [Step 7 - Compare & Adjust](../flow/step-7.md)
