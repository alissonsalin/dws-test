# Get Started

Use this section to install the shared .github Copilot customization pack and start using it quickly.

## Start Here

1. [Prerequisites](get-started/prerequisites.md)
2. [Installation](get-started/installation.md)
3. [IDE Setup](get-started/ide-setup.md)
4. [Copilot Usage](get-started/copilot-usage.md)
5. [Troubleshooting](get-started/troubleshooting.md)

## Developer References

1. [For developers - Overview](for-developers/overview.md)
2. [For developers - Clean Architecture](for-developers/clean-architecture.md)
3. [Technologies - Arch Unit](technologies/arch-unit.md)
4. [Technologies](technologies/java.md)
5. [For developers - Unit test](for-developers/unit-test.md)

## Optional Workflows

Use this path only for occasional technology migration initiatives (for example NodeJS to Java).

1. Tech refresh orchestrator agent: .github/agents/tech-refresh-orchestrator.agent.md
2. Tech refresh agent: .github/agents/tech-refresh.agent.md
3. Tech refresh instruction: .github/instructions/tech-refresh.instructions.md

The handoff-based tech refresh path starts with prerequisite analysis through `tech-refresh` and only then continues into Step 1 to Step 9 through `feature-flow` after explicit approval.
