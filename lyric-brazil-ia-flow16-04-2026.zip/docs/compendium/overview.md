# Compendium

## Purpose

This section centralizes workflow guardrails, step actions, agent roles, and reference material used across the GEN AI Flow.

## Scope

The Compendium references the main concepts behind this repository, including GEN AI, Agent Engineer, and Agentic AI.

Detailed explanations should live in dedicated pages under this section so each concept can be maintained independently.

## Notes

Use this area for cross-cutting guidance that does not belong to a single workflow step. The Compendium should explain shared concepts and operating rules that support the full GEN AI and agentic delivery model.