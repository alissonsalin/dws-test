---
description: "Use when the feature-flow or tech-refresh agents are running implementation, verification, or security commands and need resilient retry and remediation behavior across Java, Node.js, and Python."
---

# Command Resilience and Retry Policy

- Keep command usage minimal and goal-oriented.
- Use OS-appropriate command variants when sharing or executing commands.
- Prefer non-interactive commands when alternatives exist.
- Include a brief explanation for each command so intent is clear.

# Preflight Before Validation Commands

- Before running workflow validation commands, perform lightweight preflight checks for:
  - required tools in PATH
  - expected files for the stack and step
  - working directory context
- If preflight fails, fix environment or command context first, then execute the target command.

# Retry and Remediation Rules

- Continue remediation for recoverable errors; do not stop the full workflow for non-destructive issues.
- If a command fails, apply a material fix before retrying.
- Do not rerun a command if the error fingerprint is unchanged from the previous attempt.
- Keep retries fix-driven and iterative until resolved, unless the issue is destructive, ambiguous, or blocked by an explicit user gate.
- Do not mark a workflow step as failed for recoverable command errors; keep it in-progress while remediation is ongoing.

# Validation Scope and Minimization

- Within standard feature workflows, keep validation executions scoped to policy-approved steps.
- Do not run extra diagnostics outside approved workflow unless explicitly requested by the user.
- Coverage and coverage-gap commands are allowed only when explicitly requested.
- Git changed-file commands are allowed only when the workspace is a git repository; if `.git` is missing, continue with file-based reporting.

# Reporting and Improvement Capture

- After each attempt, summarize:
  - command executed
  - key error or pass result
  - fix applied
  - next action
- Capture command failures and successful remediations for improvement notes.
- Save these details for each failed attempt:
  - executed command or validation name
  - workflow step where it failed
  - key error message or output excerpt
  - probable root cause
  - fix applied
  - whether retry succeeded

# Java-specific Execution Notes

- For Java workflows, record Java detection decisions in execution notes:
  - command executed
  - detected Java major version
  - configured project Java version
  - reason when detected and configured versions differ
