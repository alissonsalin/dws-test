# Tech Refresh

## Purpose

Use the tech refresh workflow for migration initiatives where an existing system or module is being moved to a different technology stack, such as NodeJS to Java. This workflow adds a mandatory prerequisite analysis phase before the standard Step 1 to Step 9 feature flow starts.

## Source Files

- `.github/agents/tech-refresh-orchestrator.agent.md`
- `.github/agents/tech-refresh.agent.md`
- `.github/instructions/tech-refresh.instructions.md`

These files extend the standard repository workflow. They do not replace the default feature flow. The orchestrator agent is the preferred entry point when you want explicit handoffs from prerequisite analysis into the standard feature workflow.

## When To Use It

Use this workflow when the request is primarily about technology migration rather than a net-new feature.

Typical cases:

1. Migrating an API or background process from one stack to another.
2. Refreshing framework or runtime foundations across a bounded module.
3. Planning phased cutover from a legacy service to a new Java implementation.

Do not use this workflow for routine feature delivery that stays within the current stack and architecture.

## Workflow Model

The tech refresh flow has two phases:

1. **Phase A - Mandatory Prerequisite Analysis**
2. **Phase B - Standard Step 1 to Step 9 Workflow**

Phase B is blocked until Phase A is completed and explicitly approved.

In the recommended setup, the transition between these phases is exposed through agent handoff buttons:

1. `tech-refresh-orchestrator` -> `tech-refresh`
2. `tech-refresh-orchestrator` -> `feature-flow`
3. `tech-refresh` -> `feature-flow`

## Phase A - Mandatory Prerequisite Analysis

Before any Step 1 to Step 9 execution, complete the following analysis:

1. **Target Java Project Path**
   Ask for the Java project path first. Do not continue until the target path is explicit.
2. **Scope and Current State Analysis**
   Identify system boundaries, modules, APIs, jobs, event flows, integrations, persistence dependencies, and baseline non-functional behavior.
3. **Code and Architecture Analysis**
   Assess coupling, framework lock-in, complexity, hidden runtime assumptions, and migration blockers.
4. **Migration Plan**
   Define migration strategy by component, migration waves, dependencies, compatibility rules, and rollback criteria.
5. **Validation Plan**
   Define parity checks for functionality, contracts, data consistency, security, and performance.
6. **Approval Gate**
   Ask for explicit approval before entering the standard Step 1 to Step 9 workflow.

## Required Analysis Output

The prerequisite analysis should cover these sections:

1. Requirement Summary
2. Current State Analysis
3. Target State Architecture
4. Migration Plan by Waves
5. Validation Plan
6. Risks and Rollback
7. Approval Decision and Date

The analysis should also include:

- Component inventory for APIs, jobs, events, persistence, and integrations.
- Risk matrix with impact and likelihood.
- Dependency migration constraints and fallback options.
- Validation coverage for functional, contract, data, security, and performance checks.

## Approval Gate

The approval gate is a hard stop:

1. Complete the analysis and migration plan.
2. Ask whether to proceed to Step 1 to Step 9 using the approved analysis.
3. Continue only after the answer is explicitly yes.

If approval is not recorded, do not document or execute the standard feature workflow steps.

## Phase B - Standard Workflow After Approval

Once Phase A is approved, return to the normal repository workflow:

1. Run the standard Step 1 to Step 9 checklist.
2. Preserve the existing design-first gate.
3. Load language-specific implementation policy only when implementation explicitly starts in the target language. Use the corresponding language skill at that point instead of always-on language instructions.
4. Keep the standard interactive approvals for design, CVE validation, and improvements.
5. Keep Step 9 mandatory.

This means tech refresh adds an approval-driven front door, not a separate replacement lifecycle.

## Agent Entry Point

Preferred handoff-based agent invocation:

```text
@tech-refresh-orchestrator Use the tech refresh workflow for a NodeJS to Java migration.
Start with prerequisite analysis through tech-refresh.
After approval, continue through feature-flow using the approved analysis as source context.
```

Expected button flow:

1. `Start Prerequisite Analysis`
2. `Continue To Feature Flow`

The orchestrator defines both buttons in its own `handoffs:` section. The second button is intended for use only after explicit approval is captured.

Direct analysis-only invocation:

```text
@tech-refresh Use the tech refresh workflow for a NodeJS to Java migration.
Start with Phase A prerequisite analysis.
Ask for the target Java project path first.
Do not begin Step 1 to Step 9 until approval is explicitly captured.
```

## Developer Notes

- Keep the workflow non-destructive by default.
- Ask before risky operations.
- Treat the prerequisite analysis as the source of truth for later implementation planning.
- Keep default feature workflow instructions unchanged.
- Prefer the orchestrator when you want the migration analysis and implementation flow to stay connected through explicit handoffs.

## Related References

- [Custom Instructions](custom-instructions.md)
- [Agents](agents.md)
- [Skills](skills.md)
- [For Developers - Overview](overview.md)
- [Feature Flow Prompts](../copilot-chat-usage/feature-flow-prompts.md)
- [Step 1 - Identify Feature Details](../flow/step-1.md)
- [Step 2 - Create Technical Design](../flow/step-2.md)