---
description: "Use when flow-orchestrator or tech-refresh runs implementation, verification, or security commands and needs resilient retry and remediation behavior across Java, Node.js, and Python."
---

# Command Resilience and Retry Policy

- Keep commands minimal, goal-oriented, OS-appropriate, and non-interactive when possible; include a brief explanation for each command.

# Preflight Before Validation Commands

- Before validation commands, check required tools in PATH, expected files for the stack and step, and working directory context.
- If preflight fails, fix environment or command context before executing the target command.

# Retry and Remediation Rules

- Continue remediation for recoverable errors; do not stop the full workflow for non-destructive issues.
- If a command fails, apply a material fix before retrying.
- Do not rerun a command if the error fingerprint is unchanged from the previous attempt.
- Keep retries fix-driven and iterative until resolved, unless the issue is destructive, ambiguous, or blocked by an explicit user gate.
- Keep workflow steps in-progress during recoverable command remediation; do not mark them failed unless the issue is destructive, ambiguous, or explicitly blocked.

# Validation Scope and Minimization

- Within standard feature workflows, keep validation executions scoped to policy-approved steps.
- Do not run extra diagnostics outside approved workflow unless explicitly requested by the user.
- Coverage and coverage-gap commands are allowed only when explicitly requested.
- Git changed-file commands are allowed only when the workspace is a git repository; if `.git` is missing, continue with file-based reporting.

# Reporting and Improvement Capture

- After each attempt, summarize command executed, key error or pass result, fix applied, and next action.
- Capture failures and successful remediations for improvement notes, including executed command or validation name, workflow step, key error or output excerpt, probable root cause, fix applied, and whether retry succeeded.

# Java-specific Execution Notes

- For Java workflows, record command executed, detected Java major version, configured project Java version, and the reason when detected and configured versions differ.
