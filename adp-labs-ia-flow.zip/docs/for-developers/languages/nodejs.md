# NodeJS

## Purpose

Define NodeJS implementation expectations aligned with clean architecture and command resilience.

## Core Technical Stack

1. Clean architecture folder layout.
2. Boundary validation in adapters/routes.
3. Deterministic business-layer tests.
4. Command resilience for verification/security flows.

## Key Expectations

- Clean architecture layout (`src/domain`, `src/usecase`, `src/adapter`, `src/gateway`).
- Thin route/controller handlers and business logic in use cases/domain.
- Input validation at boundaries.
- Secure logging and secrets handling.
- Deterministic tests for changed paths.

## Recommended Structure

```text
src/
	domain/
	usecase/
	adapter/
	gateway/
```

## API Boundary Pattern

- Adapter/route layer:
	- validate request payload and params
	- map to use-case input DTO
	- delegate to use case
	- map use-case output to HTTP response
- Keep business branching out of route handlers.

## Integration Pattern

- Gateway modules own external API/DB clients.
- Use explicit timeout and retry policy for outbound calls.
- Translate transport-specific errors into business-safe errors before returning to use cases.

## Command And Validation Guidance

- Follow Node/Python command resilience guidance.
- Avoid extra diagnostics unless explicitly requested.
- Use fix-driven retries and unchanged-error prevention.

## Testing Model

- Unit-test `domain` and `usecase` without runtime framework dependencies.
- Mock only external boundaries (DB, HTTP clients, queues).
- Add route/controller tests for request validation and response mapping.

## Related Technical References

- [Clean Architecture](../clean-architecture.md)
- [Unit test](../unit-test.md)

## Related Flow Steps

- [Step 4 - Start Implementation](../../flow/step-4.md)
- [Step 5 - Security Validation](../../flow/step-5.md)
- [Step 6 - Create Unit Tests](../../flow/step-6.md)
