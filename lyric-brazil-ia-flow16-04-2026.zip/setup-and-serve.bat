@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "REPO_ROOT=%~dp0"
for %%I in ("%REPO_ROOT%.") do set "REPO_ROOT=%%~fI"
cd /d "%REPO_ROOT%"

echo [INFO] Repository root: %REPO_ROOT%

where python >nul 2>&1
if errorlevel 1 (
  echo [WARN] Python not found. Trying to install with winget...
  where winget >nul 2>&1
  if errorlevel 1 (
    echo [ERROR] winget not found. Install Python manually from https://www.python.org/downloads/windows/
    exit /b 1
  )

  winget install --id Python.Python.3.12 -e --source winget
  if errorlevel 1 (
    echo [ERROR] Python installation failed. Install manually and re-run this script.
    exit /b 1
  )
)

python --version >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python is still not available in PATH. Restart terminal and run again.
  exit /b 1
)

python -m ensurepip --upgrade >nul 2>&1
if errorlevel 1 (
  echo [WARN] ensurepip was not needed or failed; continuing.
)

if not exist ".venv" (
  echo [INFO] Creating virtual environment...
  python -m venv .venv
  if errorlevel 1 (
    echo [ERROR] Failed to create virtual environment.
    exit /b 1
  )
)

echo [INFO] Installing Python dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 (
  echo [ERROR] Failed to upgrade pip.
  exit /b 1
)

".venv\Scripts\python.exe" -m pip install mkdocs mkdocs-material pymdown-extensions
if errorlevel 1 (
  echo [ERROR] Failed to install MkDocs dependencies.
  exit /b 1
)

echo [INFO] Starting MkDocs with livereload...
".venv\Scripts\python.exe" -m mkdocs serve --livereload
