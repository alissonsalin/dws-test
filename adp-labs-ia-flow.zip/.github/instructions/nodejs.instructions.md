---
applyTo: "**/*.{js,ts,json,yml,yaml}"
description: "Use when implementing Node.js features with clean architecture and modern best practices for this project."
---

# Node.js Implementation Rules

- Follow clean architecture boundaries: domain, usecase, adapter, gateway.
- For command execution resilience and retry-reduction behavior, follow `.github/instructions/node-python-cli-resilience.instructions.md`.
- Keep business logic in use cases and domain, not controllers or route handlers.
- Keep controllers and route handlers focused on input/output mapping and delegation.
- Use constructor-based or module-level dependency injection.
- Prefer TypeScript for type safety and maintainability (if project uses it).
- Use async/await for asynchronous operations; avoid callback hell.
- Maintain immutable data structures where practical.

# Project Structure and Dependencies

- Organize code in `src/domain`, `src/usecase`, `src/adapter`, `src/gateway` directories.
- Keep dependencies declared in `package.json` with clear versions.
- Use npm workspaces for monorepo management if applicable.
- Document dependency changes and updates in commit messages.
- Pin production dependencies to known-good versions; use `^` for minor updates only.

# Express.js and API Conventions (if applicable)

- Use Express middleware for request logging and error handling at boundaries.
- Keep route definitions in dedicated route files (not mixed with business logic).
- Use `app.use()` only for middleware; keep route handlers thin.
- Return consistent JSON response formats (e.g., `{ data, error, status }`).
- Use appropriate HTTP status codes (200, 201, 400, 401, 404, 500).
- Document API endpoints with clear error scenarios.

# Code Quality and Testing

- Use consistent linting (ESLint) and formatting (Prettier).
- Validate and sanitize inputs at route boundaries.
- Never expose sensitive data in logs or responses (no passwords, tokens, PII).
- Use environment variables for configuration and secrets.
- Write unit tests with Jest or Mocha; use meaningful test names.
- Aim for >95% test coverage for critical business logic.

# Reliability and Performance

- Use connection pooling for database access.
- Implement retry logic with exponential backoff for external API calls.
- Use caching (Redis, in-memory) for frequently accessed data.
- Prefer async operations over blocking calls.
- Monitor memory usage and leak prevention.
- Add request timeouts and circuit breakers for external dependencies.

# Security Best Practices

- Validate and sanitize all external inputs (query params, request body, files).
- Use HTTPS in production; enforce secure cookies (httpOnly, secure, sameSite).
- Hash passwords with bcrypt or similar; never store plaintext.
- Use JWT or session-based authentication; validate tokens on every protected endpoint.
- Implement rate limiting for public APIs.
- Keep dependencies updated; run `npm audit` regularly.
- Encrypt sensitive data at rest and in transit.
