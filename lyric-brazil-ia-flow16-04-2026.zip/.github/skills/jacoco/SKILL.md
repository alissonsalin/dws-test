---
name: jacoco
description: "Configure or validate JaCoCo coverage reporting and verification in Java Gradle projects. Use when Java implementation or test work needs coverage reports, verification rules, or Gradle JaCoCo setup."
argument-hint: "Describe the Java module, current Gradle test setup, and whether you need report generation, verification rules, or build wiring"
---

# JaCoCo Coverage Rules

## When to Use

- Java Step 4 or Step 6 needs JaCoCo setup or updates.
- A Gradle Java project is missing JaCoCo plugin or coverage verification tasks.
- You need to interpret or summarize JaCoCo report output.
- You need coverage verification rules for clean architecture layers.

## Required Build Configuration

- Keep JaCoCo configuration in `build.gradle` or `build.gradle.kts`.
- Apply the Gradle JaCoCo plugin for Java projects that require coverage reporting.
- For new Java projects, or when coverage setup is missing, define both `jacocoTestReport`.
- Keep coverage verification attached to the build lifecycle by wiring `check` with `dependsOn jacocoTestCoverageVerification`.
- Keep JaCoCo configuration in the build, not in ad-hoc shell scripts or manual-only instructions.

## Coverage Verification Model

- Treat coverage as a layer-based verification gate, not as a single 100% line-coverage target.
- `domain` layer: 90%+ line coverage.
- `usecase` layer: 90%+ line coverage.
- `gateway` layer: 90%+ line coverage.
- `adapter` layer: prioritize controller, slice, contract, or integration correctness over raw unit-only coverage targets.
- Do not close Java test work if changed `domain`, `usecase`, or `gateway` code is below the documented floor unless the gap is explicitly documented and approved.

## Reporting Expectations

- Generate the JaCoCo HTML report as the standard Java coverage artifact.
- Review the report in the same verification cycle as test execution.
- If a valid current JaCoCo report already exists and the code under review has not changed since that report, summarize the existing report instead of rerunning coverage when that is sufficient for the user's request.
- Share a short coverage summary with overall outcome, failing threshold if any, changed layer or package gaps, and report artifact path when available.
- Fix JaCoCo verification failures before considering Step 6 complete.

## Separation of Concerns

- Use `.github/skills/java-cli/SKILL.md` as the source of truth for exact Java command strings and execution timing.
- Use `.github/skills/archunit/SKILL.md` for Java architecture boundary tests.
- Use `.github/instructions/testing.instructions.md` for cross-language test authoring and maintainability rules.