---
description: "Use when the standard feature workflow implements or refactors code that must follow clean architecture boundaries, inward dependencies, and separation of business logic from frameworks."
---

# Clean Architecture Rules

- Organize code by architectural boundary: `domain`, `usecase`, `adapter`, and `gateway`.
- Keep business rules in `domain` and `usecase`; do not place business logic in controllers, routes, UI handlers, or persistence implementations.
- Keep dependency direction inward: outer layers may depend on inner layers, but inner layers must not depend on frameworks or delivery mechanisms.
- Define interfaces at the boundary owned by the business flow; implement infrastructure details in outer layers.
- For Java persistence/integration boundaries, use `Repository` for the business-facing interface in `usecase` and `Gateway` for the outer implementation in `gateway`; avoid `Impl` and technology-specific names such as `Jdbc`, `Jpa`, `Mongo`, `Rest`, or `Http`. Example: `PersonRepository` and `PersonGateway`.
- Keep controllers and route handlers focused on input/output mapping, validation at the boundary, and delegation to use cases.
- Keep gateways responsible for integration details only, such as databases, external APIs, queues, or file systems.
- Use DTOs or request/response models at layer boundaries instead of leaking framework-specific objects into domain logic.
- Prefer small, focused use cases with explicit inputs, outputs, and error handling.
- Keep entities and value objects framework-agnostic and independent from persistence annotations when possible.
- For Java domain entities/value objects/POJOs, Lombok annotations are allowed and expected per `.github/skills/lombok/SKILL.md`; Lombok usage does not count as framework leakage in this architecture.
- Reflect the architecture in tests: unit-test domain and use cases directly, and isolate adapters and gateways with mocks or integration tests as appropriate.

# Recommended Package Shape

- Prefer package names that mirror the clean architecture layers: `domain`, `usecase`, `adapter`, and `gateway`.
- For Java code, start packages with `com.adp` and keep Spring bean wiring in a dedicated global `configuration` package, not in `domain`, `usecase`, `adapter`, or `gateway`.
- Within a feature or bounded context, use `domain` for entities, value objects, enums, and domain exceptions; `usecase` for use cases, repository interfaces, commands, queries, responses, and business validation helpers; `adapter` for controllers, route handlers, and transport models; and `gateway` for repository implementations, external clients, persistence mappers, and gateway-specific records or entities.
- Prefer layer root packages with an entity- or feature-specific subpackage when the feature is substantial, for example `com.adp.domain.client`, `com.adp.usecase.client`, `com.adp.adapter.client`, and `com.adp.gateway.client`; when creating a new entity or feature, keep that entity or feature name in each layer path, for example `domain/client/Client.java` and `usecase/client/RegisterClientUseCase.java`.
- If the system is large, group by bounded context first and keep the same inner layer names inside each context.
- Keep shared packages minimal and intentional; do not create broad `common` or `util` packages that bypass the layer boundaries.

# Naming Conventions Across Layers

- Use business names in `domain`, not transport, framework, or persistence terminology.
- Name state-changing use case input models with the `Command` suffix.
- Name read-oriented use case input models with the `Query` suffix when a dedicated object is needed.
- Name use case output models with the `Response` suffix.
- Name transport-layer HTTP models with `Request` and `HttpResponse` suffixes to keep adapter ownership explicit.
- Keep names specific to the feature or entity instead of relying on generic type names.