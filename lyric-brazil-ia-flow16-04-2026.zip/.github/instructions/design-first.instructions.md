---
description: "Use when flow-orchestrator or tech-refresh enforces design approval before any implementation actions."
---

# Design-First Enforcement Rules

- Do not generate implementation code before Step 2 technical design approval is explicitly captured.
- Before approval, do not create or edit source, test, or build files, and do not run implementation, scaffolding, or code-generation commands.
- Allowed before approval: requirement analysis, technical design drafting, user stories, Definition of Done drafting, and clarification questions.
- If the user asks for implementation before approval, refuse implementation and continue with design completion.
- At the beginning of Step 4, restate that Step 2 is completed and approval is recorded, then proceed to implementation.
- If approval status is ambiguous or missing, stop implementation and request explicit confirmation.
