import * as vscode from 'vscode';

import { MysqlConfigStore } from './config';
import { SqlCopilotChatParticipant } from './chatParticipant';
import { MysqlService } from './mysqlService';

const INITIAL_SETUP_PROMPT_STATE_KEY = 'sqlCopilot.initialSetupPromptShown';

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  const output = vscode.window.createOutputChannel('SQL Copilot Assistant');
  output.appendLine('Activating SQL Copilot Assistant.');

  const configStore = new MysqlConfigStore(context);
  const mysqlService = new MysqlService();
  const participantController = new SqlCopilotChatParticipant(context, configStore, mysqlService);
  const participant = participantController.create();

  output.appendLine('Registered chat participant sqlCopilot.mysql with handle @mysqlca.');

  context.subscriptions.push(output);
  context.subscriptions.push(participant);
  context.subscriptions.push({ dispose: () => void mysqlService.dispose() });

  context.subscriptions.push(
    vscode.commands.registerCommand('sqlCopilot.configureConnection', async () => {
      const saved = await configStore.promptForConnectionSetup();
      if (saved) {
        output.appendLine('MySQL connection settings saved to extension storage.');
        const action = await vscode.window.showInformationMessage(
          'MySQL connection settings saved.',
          'Test Connection'
        );

        if (action === 'Test Connection') {
          await vscode.commands.executeCommand('sqlCopilot.testConnection');
        }
      }
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('sqlCopilot.setDatabase', async () => {
      const saved = await configStore.promptForDatabase();
      if (saved) {
        void vscode.window.showInformationMessage('Default MySQL database saved.');
      }
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('sqlCopilot.setPassword', async () => {
      const saved = await configStore.promptForPassword();
      if (saved) {
        void vscode.window.showInformationMessage('MySQL password saved to VS Code secret storage.');
      }
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('sqlCopilot.clearPassword', async () => {
      await configStore.clearPassword();
      void vscode.window.showInformationMessage('Stored MySQL password cleared.');
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('sqlCopilot.testConnection', async () => {
      const resolved = await configStore.resolveSettings();
      const settings = resolved.settings;
      if (!settings) {
        const action = await vscode.window.showWarningMessage(
          `Missing configuration: ${resolved.missing.join(', ')}`,
          'Configure Connection'
        );

        if (action === 'Configure Connection') {
          await vscode.commands.executeCommand('sqlCopilot.configureConnection');
        }

        return;
      }

      try {
        output.appendLine(`Testing MySQL connection to ${settings.user}@${settings.host}:${settings.port}/${settings.database}`);
        await vscode.window.withProgress(
          {
            location: vscode.ProgressLocation.Notification,
            title: `Testing MySQL connection to ${settings.database}`,
            cancellable: false
          },
          async () => mysqlService.ping(settings)
        );
        output.appendLine('MySQL connection succeeded.');
        void vscode.window.showInformationMessage('MySQL connection succeeded.');
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        output.appendLine(`MySQL connection failed: ${message}`);
        void vscode.window.showErrorMessage(`MySQL connection failed: ${message}`);
      }
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('sqlCopilot.applyPendingMutation', async () => {
      try {
        await participantController.applyPendingMutationWithNotification();
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        void vscode.window.showErrorMessage(`Failed to apply staged mutation: ${message}`);
      }
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('sqlCopilot.discardPendingMutation', async () => {
      try {
        await participantController.discardPendingMutationWithNotification();
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        void vscode.window.showErrorMessage(`Failed to discard staged mutation: ${message}`);
      }
    })
  );

  void promptForInitialSetup(context, configStore);
}

export async function deactivate(): Promise<void> {
  return undefined;
}

async function promptForInitialSetup(
  context: vscode.ExtensionContext,
  configStore: MysqlConfigStore
): Promise<void> {
  const resolved = await configStore.resolveSettings();
  if (resolved.settings) {
    return;
  }

  const hasPrompted = context.globalState.get<boolean>(INITIAL_SETUP_PROMPT_STATE_KEY, false);
  if (hasPrompted) {
    return;
  }

  await context.globalState.update(INITIAL_SETUP_PROMPT_STATE_KEY, true);
  const action = await vscode.window.showInformationMessage(
    'SQL Copilot Assistant needs a MySQL connection before it can run queries.',
    'Configure Connection'
  );

  if (action === 'Configure Connection') {
    await vscode.commands.executeCommand('sqlCopilot.configureConnection');
  }
}