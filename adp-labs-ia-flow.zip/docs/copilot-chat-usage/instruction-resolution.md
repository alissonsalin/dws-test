# Instruction Resolution

Copilot combines instruction sources in your repository to shape responses and code changes.

## Global Project Instructions

Source: .github/copilot-instructions.md

This file defines the main workflow and cross-project rules, including:

1. The Step 1 to Step 9 execution model.
2. Mandatory status checklist format with icons.
3. Design-first hard stop before implementation.
4. Command and validation gates.
5. Completion requirements for final handoff.

## Scoped Custom Instructions

Source: .github/instructions/

These files apply by file pattern using applyTo and provide focused guidance for specific work types.

Examples include:

1. Documentation rules
2. Java implementation rules
3. Java CLI rules
4. Spring rules
5. ArchUnit rules
6. Node.js implementation rules
7. Python implementation rules
8. Command resilience and retry rules
9. Testing rules
10. Workflow status rules

When you ask Copilot to work on a file that matches a scope, the corresponding instruction file is applied in addition to global instructions.

## Resolution Sequence

1. Always load global project instructions.
2. Detect the task context, for example docs, Java, tests, or Node.js.
3. Match relevant scoped instruction files by applyTo patterns.
4. Use combined guidance to generate answers and edits.

## Next

Continue to [Workflow Gates](workflow-gates.md).