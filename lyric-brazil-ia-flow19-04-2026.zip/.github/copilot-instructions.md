# Feature Workflow

- `flow-orchestrator` — standard feature delivery across Step 1 to Step 9 with design-first gating, checklist tracking, security validation, and deferred backlog carry-forward. File: `.github/agents/flow-orchestrator.agent.md`.
- `jira-feature-intake` — extracts, normalizes, and summarizes feature requirements from Jira issues and linked Jira artifacts before design or implementation. File: `.github/agents/jira-feature-intake.agent.md`.
- `tech-refresh` — migration and modernization analysis before Step 1 to Step 9 execution. File: `.github/agents/tech-refresh.agent.md`.
- `tech-refresh-orchestrator` — starts with `tech-refresh`, then hands off to `flow-orchestrator` for Step 1 to Step 9 delivery. File: `.github/agents/tech-refresh-orchestrator.agent.md`.

Start by selecting the agent in the picker or mentioning `@flow-orchestrator`, `@jira-feature-intake`, `@tech-refresh`, or `@tech-refresh-orchestrator` with the relevant source context.

---

## File-Scoped Instruction Files

These files load automatically for matching file types. Keep this list limited to file-specific guidance.

| Concern | File |
|---|---|
| Testing patterns & coverage | `.github/instructions/testing.instructions.md` |
| Documentation format | `.github/instructions/docs.instructions.md` |
| README authoring | `.github/instructions/readme.instructions.md` |
| Release notes authoring | `.github/instructions/release-notes.instructions.md` |
| Tech refresh workflow | `.github/instructions/tech-refresh.instructions.md` |

## Agent-Scoped Instructions

These instruction files are not always-on; load them through the owning agent when relevant.

| Concern | Owner |
|---|---|
| Clean architecture | `flow-orchestrator` workflow via `.github/instructions/clean-architecture.instructions.md` |
| Design-first gate | `flow-orchestrator` and `tech-refresh` workflows via `.github/instructions/design-first.instructions.md` |
| Workflow checklist format | `flow-orchestrator` and `tech-refresh` workflows via `.github/instructions/workflow-status.instructions.md` |
| Command resilience | `flow-orchestrator` and `tech-refresh` workflows via `.github/instructions/command-resilience.instructions.md` |

---

## On-Demand Skills

Use these for specialized workflows that stay unloaded by default.

| Concern | Skill |
|---|---|
| CLI retries and preflight remediation | `.github/skills/cli-resilience/SKILL.md` |
| Java architecture boundary tests (ArchUnit) | `.github/skills/archunit/SKILL.md` |
| Gradle build and Checkstyle configuration | `.github/skills/gradle/SKILL.md` |
| Java implementation baseline | `.github/skills/java/SKILL.md` |
| Node.js implementation baseline | `.github/skills/nodejs/SKILL.md` |
| Python implementation baseline | `.github/skills/python/SKILL.md` |
| Spring Boot conventions | `.github/skills/spring/SKILL.md` |
| Lombok model and builder rules | `.github/skills/lombok/SKILL.md` |
| Java CLI startup and validation flow | `.github/skills/java-cli/SKILL.md` |
| Security command selection and CVE validation | `.github/skills/security/SKILL.md` |
| JaCoCo coverage configuration and reporting | `.github/skills/jacoco/SKILL.md` |
| Lint compliance and validation workflow | `.github/skills/lint/SKILL.md` |
| Annotation-driven OpenAPI / Swagger | `.github/skills/openapi/SKILL.md` |
| Node/Python CLI resilience | `.github/skills/node-python-cli/SKILL.md` |

---

## Feature Deliverables

Every completed feature must produce:
- `documentation/<feature-id>/<feature-name>-design.md` (Step 2)
- `documentation/<feature-id>/<feature-name>-troubleshooting.md` (Step 8)
- `improvements/session-dd-mm-yyyy.md` (Step 9 output, today's date)
- Updated `README.md` (Step 4)

---

## Parameters

- Source type: `file | Jira | Confluence | user input`
- Language: `Java | NodeJS | Python | SQL`
