---
name: spring
description: "Implement or review Spring Boot Java features with controller, bean wiring, configuration-package, and YAML profile conventions. Use when Java work adds Spring controllers, configuration classes, filters, interceptors, or application.yml files."
argument-hint: "Describe the Spring Boot change, affected layer, and whether controller/configuration/resource files are involved"
---

# Spring Boot Implementation Rules

Use this skill for Spring-specific implementation details so they do not stay always-on in normal chat.

## When to Use

- A Java feature adds or changes Spring-managed components.
- You need controller, configuration, filter, interceptor, or bean registration guidance.
- You are creating or updating Spring Boot YAML configuration files.

## Structure and Annotations

- Use Spring Boot for new Java implementations in this project unless the user explicitly requests a different framework.
- Prefer Spring Boot starters for web, actuator, validation, and testing when those capabilities are needed.
- If the existing project is not yet configured for Spring Boot, stop and propose the required `build.gradle` or `build.gradle.kts` changes for confirmation before editing build files.
- If a Java request would be implemented without Spring Boot, explain the conflict and ask for explicit approval before proceeding.
- Use `@RestController` and explicit request mappings for controllers.
- Use the `Controller` suffix for API controller classes.
- Do not create `adapter/<feature>/http/filter`, `adapter/<feature>/http/interceptor`, or similar generic transport package trees unless the user or approved design explicitly requires a filter or interceptor.
- When a filter or interceptor is required, keep it feature-specific inside `adapter/<feature>/controller` or register it through the global `configuration` package instead of creating a default generic `http` subtree.
- Keep configuration classes in a dedicated `configuration` package and annotate them with `@Configuration`.
- Every class under a `configuration` package must be a Spring configuration class.
- Do not create `@Component`, `@Service`, `@Repository`, `@Controller`, or `@RestController` classes inside the `configuration` package.
- Place infrastructure beans outside `configuration` and register them through `@Bean` methods.
- Always use constructor-based dependency injection.
- Do not use `@Autowired` for bean injection.
- Name the main application class `Application` and keep it in the root package.
- Create only one `Application` class per project.

## Configuration Files

- Use YAML-based Spring configuration files exclusively.
- Never create `application.properties` or any `.properties` configuration file.
- Create `application.yml` for shared defaults.
- Create `application-development.yml` for development-specific configuration.
- Ensure both files exist in `src/main/resources` when the feature is complete.
- Create `application-test.yml` under `src/test/resources` for test-specific configuration.
- Add additional environment files only when the feature requires them.

## Persistence, API, and Security Notes

- Prefer JDBC access patterns unless another persistence approach is explicitly requested.
- Keep API contracts stable and document breaking changes.
- Add concise logs for request lifecycle and error scenarios.
- Validate and sanitize inputs at boundaries.
- Do not expose sensitive data in logs.
- Prefer resilient integration patterns for external dependencies.
