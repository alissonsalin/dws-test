# Example: Technical Design Document

This page shows what a completed Step 2 technical design document looks like.
The file is saved as `documentation/<feature-name>/<feature-name>-design.md`.

---

## Requirement Summary

**Feature:** Client Registration API  
**Source:** `documentation/client-registration/client-registration.md`  
**Identifier:** `LRA-1042`

Users need to register as clients via a REST endpoint. The system must persist the client record, return a unique client ID, and reject duplicate email addresses with a clear error response.

---

## Technical Design

### Architecture Overview

The feature follows clean architecture with four layers: `domain`, `usecase`, `adapter`, `gateway`.

**ASCII Component Diagram**

```
  HTTP Request
       |
       v
+------------------+
|    Controller    |  adapter layer — maps request to command, delegates to use case
+------------------+
       |
       v
+------------------+
|  RegisterClient  |  usecase layer — validates business rules, orchestrates flow
|    UseCase       |
+------------------+
       |
       v
+------------------+
|  Client (domain) |  domain layer — Client entity and ClientRepository interface
+------------------+
       |
       v
+------------------+
| ClientRepository |  gateway layer — JDBC implementation of ClientRepository
|  (JDBC impl)     |
+------------------+
       |
       v
   Database
```

**Mermaid Component Diagram**

```mermaid
graph TD
    A[HTTP Request] --> B[ClientController\nadapter]
    B --> C[RegisterClientUseCase\nusecase]
    C --> D[Client Entity\ndomain]
    C --> E[ClientRepository interface\ndomain]
    E --> F[ClientRepositoryJdbc\ngateway]
    F --> G[(Database)]
```

### Data Flow

1. `ClientController` receives `POST /clients`, maps body to `RegisterClientCommand`.
2. `RegisterClientUseCase` validates email uniqueness by calling `ClientRepository.existsByEmail()`.
3. If duplicate, throws `DuplicateEmailException`, controller maps it to HTTP 409.
4. If valid, creates `Client` domain entity, persists via `ClientRepository.save()`.
5. Returns `RegisterClientResponse` with the generated client ID and HTTP 201.

### Validation Rules

| Field      | Rule                          | Error           |
|------------|-------------------------------|-----------------|
| `name`     | Required, max 100 chars       | 400 Bad Request |
| `email`    | Required, valid email format  | 400 Bad Request |
| `email`    | Must be unique                | 409 Conflict    |

### Technologies

| Concern         | Choice                              |
|-----------------|-------------------------------------|
| Framework       | Spring Boot 3.x                     |
| Persistence     | Spring JDBC (`JdbcTemplate`)        |
| Validation      | Jakarta Bean Validation (`@Valid`)  |
| Testing         | JUnit 5, Mockito, ArchUnit          |
| Build           | Gradle Wrapper                      |

### Database Schema

```sql
CREATE TABLE clients (
    id        UUID         PRIMARY KEY,
    name      VARCHAR(100) NOT NULL,
    email     VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP   NOT NULL DEFAULT NOW()
);
```

---

## API Design

### POST /clients

**Request**

```json
{
  "name": "Alice Silva",
  "email": "alice@example.com"
}
```

**Response — 201 Created**

```json
{
  "clientId": "9f4e2b1a-3c5d-4e6f-a7b8-0c1d2e3f4a5b"
}
```

**Response — 400 Bad Request**

```json
{
  "error": "VALIDATION_ERROR",
  "details": [
    { "field": "email", "message": "must be a valid email address" }
  ]
}
```

**Response — 409 Conflict**

```json
{
  "error": "DUPLICATE_EMAIL",
  "message": "A client with this email already exists."
}
```

---

## Backward Compatibility Considerations

- This is a new endpoint with no prior version. No breaking changes.
- The `clients` table is new. Migration script must run before deployment.
- If `id` generation strategy changes in the future, existing UUIDs remain valid.

---

## Impact and Risk Assessment

### Performance Impact Analysis

- **Expected latency impact:** One extra `existsByEmail` database lookup before insert. Typical added latency is low for indexed email lookups.
- **Throughput considerations:** Registration throughput depends on database write capacity and unique index contention on `email`.
- **Resource usage:** Slight increase in database CPU and I/O from pre-insert uniqueness check.
- **Caching implications:** No response caching for write endpoint. Avoid caching uniqueness results to prevent stale acceptance.
- **Hotspots to monitor:** Duplicate-email bursts and insert contention on peak traffic.

### Internal Feature Impact Check

- **Potentially affected features:** Existing onboarding, account activation, and client profile workflows that consume `clients` data.
- **Regression checks required:**
  - Existing read APIs still return consistent client data after registration.
  - Existing onboarding flow works with newly created client IDs.
  - Duplicate email handling does not break global error response format.

### External Dependency Check

- **Dependencies used by this feature:**
  - Relational database service for `clients` persistence.
  - Optional outbound event bus (if registration event publishing is enabled).
- **Failure and timeout behavior:**
  - Database unavailable: return `503 Service Unavailable` with retryable error code.
  - Database timeout: fail fast with bounded timeout and structured error payload.
  - Event publishing failure (optional): persist client first, then retry publish asynchronously without blocking registration response.

### External Impact Check

- **Possible impacts on external projects/services:**
  - Increased write load on the shared database cluster.
  - New registration events consumed by downstream CRM/analytics services.
- **Mitigations:**
  - Add monitoring/alerts for registration error rate and dependency timeouts.
  - Version event contract before enabling new consumers.

---

**Related:** [Step 2 - Technical Design](../../flow/step-2.md)
