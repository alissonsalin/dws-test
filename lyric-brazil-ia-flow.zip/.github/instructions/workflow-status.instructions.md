---
description: "Use when the feature-flow or tech-refresh agents are presenting workflow progress and must enforce the Step 1 to Step 9 checklist with icon-based statuses."
---

# Workflow Status Checklist Rules

- At the start of each workflow step, print the full Step 1 to Step 9 checklist.
- At workflow startup, print the full Step 1 to Step 9 checklist as soon as the initial step state is known.
- Treat that checklist as mandatory user-visible output for every step transition.
- If a tool call happens first, the first assistant message shown after the tool call must begin with the full checklist before any other text.
- For the first visible workflow message, show Step 1 as `in-progress` and all later steps as `pending` unless a different status is already known.
- Print the startup checklist before any Step 1 source question, requirement summary, or design prompt.
- After the TODO list or internal step state changes to mark a new step as `in-progress`, print the checklist immediately in the next user-visible message.
- Render the checklist as a vertical list with exactly one workflow step per line.
- Never render the full checklist inline as a single paragraph or wrapped sentence.
- Keep one status per step line using this format:
  - <icon> Step N - <step name> [<status>]
- Use these status values only:
  - pending
  - in-progress
  - completed
  - failed
  - skipped
- Keep the status text and icon aligned at all times.
- Update statuses as the workflow advances and keep completed steps visible.
- Preserve line breaks exactly so the chat UI shows a readable list.
- Do not ask a question, summarize findings, or explain the next action before the checklist is printed.

# Icon Map

- `✅` -> completed
- `🔄` -> in-progress
- `⏳` -> pending
- `❌` -> failed
- `⏭` -> skipped

# Reference Checklist Template

- ⏳ Step 1 - Identify Feature Details [pending]
- ⏳ Step 2 - Create Technical Design [pending]
- ⏳ Step 3 - Create User Stories [pending]
- ⏳ Step 4 - Start Implementation [pending]
- ⏳ Step 5 - Security Validation [pending]
- ⏳ Step 6 - Create Unit Tests [pending]
- ⏳ Step 7 - Compare and Adjust [pending]
- ⏳ Step 8 - Troubleshooting and Debugging [pending]
- ⏳ Step 9 - Continuous Improvement [pending]
