# Agents

## Purpose

This page documents the custom agents used in this repository. Agents are responsible for workflow orchestration, tool usage rules, and role-specific execution behavior.

## When To Use Agents

Use an agent when you need:

- end-to-end workflow sequencing
- explicit tool expectations or restrictions
- autonomous execution behavior
- a focused role for a recurring workflow

## Agent File Structure

An agent file starts with YAML frontmatter between `---` markers. This header defines how VS Code discovers the agent, what it can call, and what handoff buttons are exposed before the instruction body begins.

### Example

```yaml
---
description: "Use to orchestrate tech refresh work through explicit handoffs."
tools: [read, agent, todo]
agents: [tech-refresh, flow-orchestrator]
argument-hint: "Describe the migration scope, current system/module, target stack, and source references."
handoffs:
	- label: Start Prerequisite Analysis
		agent: tech-refresh
		prompt: "Start prerequisite tech refresh analysis only."
		send: true
---
```

### Header Fields

| Field | Purpose | Notes |
|---|---|---|
| `description` | Discovery text for the agent picker and model routing. | Write this as the trigger surface: include "Use when..." language and the workflows or keywords that activate the agent. |
| `tools` | Declares which tool groups the agent is allowed to use. | Keep this minimal. Only include the capabilities the agent actually needs. |
| `agents` | Lists the other custom agents this agent can invoke directly through the agent tool. | This is for subagent-style delegation. It is separate from `handoffs:` and is not the button definition itself. |
| `argument-hint` | Short UI hint shown to the user when they are about to invoke the agent. | Use this to ask for the minimum context the workflow needs. |
| `handoffs` | Defines explicit handoff buttons shown in the agent UI. | Use this when the workflow moves the user into another agent intentionally and visibly. |

### Handoff Fields

| Field | Purpose | Notes |
|---|---|---|
| `label` | Text shown on the handoff button. | Keep it action-oriented and short. |
| `agent` | The target agent that receives the handoff. | This must match the target custom agent name exactly. |
| `prompt` | The instruction payload sent with the handoff. | Be explicit about scope, stop conditions, and required return fields when chaining workflows. |
| `send` | Controls whether current conversation context is sent with the handoff. | Use `true` when the next agent needs the current chat context; use `false` when the target relies on the prompt and already-captured context only. |

### Field Relationships

1. Use `description` to make the agent discoverable.
2. Use `tools` to constrain what the agent can do.
3. Use `agents` only when the agent may call other agents programmatically through the agent tool.
4. Use `handoffs` when you want explicit UI buttons for a visible workflow transition.
5. An agent can define both `agents` and `handoffs` when it needs both direct delegation and button-based transitions.

### Notes

1. Keep the frontmatter focused on capability and routing; keep detailed workflow rules in the body below the header.
2. Quote long `description`, `argument-hint`, and `prompt` values to avoid YAML parsing issues.
3. If the agent file exposes handoff buttons, document the approval rules and stop conditions in the body so the handoff semantics stay unambiguous.

## Agent in This Repository

Dedicated pages are available for each agent in this section:

- [Flow Orchestrator](agents/flow-orchestrator.md)
- [Planner](agents/planner.md)
- [Coder](agents/coder.md)
- [Verifier](agents/verifier.md)
- [Diagnostics](agents/diagnostics.md)
- [Tech Refresh](agents/tech-refresh.md)
- [Tech Refresh Orchestrator](agents/tech-refresh-orchestrator.md)

### `.github/agents/flow-orchestrator.agent.md`

- Primary feature delivery agent for the repository.
- Owns the Step 1 to Step 9 workflow through Planner and Coder delegation.
- Controls design-first behavior, checklist updates, gates, delegation sequencing, troubleshooting flow, and Step 9 follow-through.
- Keeps `planner` in Step 1, Step 2, and Step 3, with Step 2 and Step 3 allowed to run in parallel after Step 1.
- Requires `coder` starting in Step 4 and treats Step 4 as incomplete unless implementation was delegated to `coder`.
- Is invoked through the agent picker or with `@flow-orchestrator` in chat.

### `.github/agents/tech-refresh.agent.md`

- Migration-analysis agent for technology refresh initiatives.
- Owns prerequisite analysis, migration planning, validation planning, and approval readiness.
- Stops before normal feature delivery unless explicitly continued.

### `.github/agents/tech-refresh-orchestrator.agent.md`

- Handoff-based migration coordinator for this repository.
- Starts with `tech-refresh` for prerequisite analysis, then continues with `flow-orchestrator` after explicit approval.
- Is the preferred entry point when you want a single migration conversation that preserves the boundary between analysis and delivery.

### `.github/agents/planner.agent.md`

- Design and planning agent.
- Owns the creation of technical designs, user stories, and documentation drafting.
- Does not implement code.

### `.github/agents/coder.agent.md`

- Implementation specialist.
- Owns code changes, file persistence, and technical debt resolution.
- Executes implementation tasks delegated by the orchestrator.

### `.github/agents/verifier.agent.md`

- Specialized testing and security agent.
- Owns terminal-based test execution, coverage analysis, and security validation (Step 5 and Step 6).
- Strictly read-only for source code; cannot modify implementation.

### `.github/agents/diagnostics.agent.md`

- Specialized troubleshooting and observability agent.
- Owns root cause analysis (RCA), troubleshooting documentation, and code-based log queries (Step 8).
- Prioritizes technical design and troubleshooting guides for system context.

## What The Feature Agent Controls

- startup behavior and deferred backlog carry-forward
- mandatory Step 1 to Step 9 checklist output at startup and each step transition
- completion, decision, and validation gate handling
- implementation sequencing through delegated agents
- stack-resolution and skill-activation expectations during implementation phases
- command execution behavior through delegated agents
- validation, troubleshooting, and continuous improvement flow

## What The Tech Refresh Orchestrator Controls

- handoff sequencing between migration analysis and feature delivery
- explicit approval checkpoint between the two handoffs
- passing approved migration context into the standard feature workflow
- keeping tech refresh and feature workflow responsibilities separate instead of mixing them into one agent

## What Stays Out of Agents

- deep language-specific implementation rules
- file-pattern-specific guidance better expressed with `applyTo`
- narrow, opt-in remediation workflows better handled by skills

## Relationship To Other Customizations

1. `.github/copilot-instructions.md` points feature work to the feature agent.
2. `.github/instructions/*.instructions.md` provide technical detail when file scopes match.
3. `.github/skills/*/SKILL.md` provide specialized on-demand workflows that complement the agent.

For implementation work, the agent uses the user's explicit language choice when provided. Otherwise, it detects the target stack at the start of implementation, loads one primary implementation baseline skill, and adds supporting skills only when the feature needs them.

## Related References

- [Custom Instructions](custom-instructions.md)
- [Skills](skills.md)
- [Tech Refresh](tech-refresh.md)
- [Flow - Overview](../flow/flow.md)
- [Flow - Step 4](../flow/step-4.md)