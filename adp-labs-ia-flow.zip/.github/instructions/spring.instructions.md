---
applyTo: "**/*.{java,kt,gradle,kts,yml,yaml}"
description: "Use when implementing Java features with Spring Boot conventions, configuration files, and REST API structure for this project."
---

# Spring Boot Implementation Rules

- Use Spring Boot for all new Java implementations in this project unless the user explicitly requests a different framework.
- Prefer Spring Boot starters for web, actuator, validation, and testing when those capabilities are needed.
- Do not generate non-Spring Java project structures by default.
- If the existing project is not yet configured for Spring Boot, stop and propose the required `build.gradle` or `build.gradle.kts` changes for confirmation before editing build files.
- If a Java request would be implemented without Spring Boot, explain the conflict and ask for explicit approval before proceeding.

# Spring Structure and Annotations

- Use `@RestController` and explicit request mappings for controllers.
- When creating API controller classes, use the `Controller` suffix in the class name, for example `ClientController`.
- Keep configuration classes in a dedicated `configuration` package and always annotate them with `@Configuration`.
- Every class under a `configuration` package must be a Spring configuration class annotated with `@Configuration`.
- Do not create `@Component`, `@Service`, `@Repository`, `@Controller`, or `@RestController` classes inside the `configuration` package.
- For infrastructure beans such as interceptors, filters, and clients, place implementation classes outside `configuration` (for example in `adapter`, `infrastructure`, or `gateway`) and register them through `@Bean` methods in a `@Configuration` class.
- Always use constructor-based dependency injection for beans.
- Do not use `@Autowired` annotation for bean injection.
- Name the main application class `Application` (exactly). Do not use feature-specific prefixes like `Feature4Application`, `ClientApplication`, or similar.
- Place the `Application` class in the root package and annotate it with `@SpringBootApplication`.
- Create only one `Application` class per project.

# Configuration Files

- Use YAML-based Spring configuration files exclusively.
- Never create `application.properties` or any `.properties` configuration file. Use `.yml` files only.
- Create `application.yml` for shared defaults in Spring Boot features. Do not skip this file.
- Create `application-development.yml` for development-specific configuration in Spring Boot features. Do not skip this file.
- Both `application.yml` and `application-development.yml` must exist in `src/main/resources` after the feature is complete.
- Create `application-test.yml` for test-specific configuration under `src/test/resources`.
- Add additional environment files only when needed by the feature (for example test profile configuration).

# Persistence and API Conventions

- Prefer JDBC access patterns unless another persistence approach is explicitly requested.
- Keep API contracts stable and document breaking changes.
- Add concise logs for request lifecycle and error scenarios.

# Reliability and Security

- Validate and sanitize inputs at boundaries.
- Do not expose sensitive data in logs.
- Prefer resilient integration patterns for external dependencies.
- Enforce payload size limits for write endpoints.
- Implement request rate limiting for write endpoints only when the user explicitly requests it or the approved requirements/design call for it. When applied, document threshold values in API behavior notes.
- Implement payload and optional rate protections using reusable configuration components (for example shared filters, interceptors, and configuration classes) instead of duplicating endpoint-level logic.
