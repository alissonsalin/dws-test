import * as vscode from 'vscode';

import { SchemaSummary } from './mysqlService';

export interface SqlPlan {
  intent: 'schema' | 'read' | 'mutation' | 'ddl' | 'unsupported';
  title: string;
  explanation: string;
  sql: string | null;
  assumptions: string[];
  requiresConfirmation: boolean;
}

export async function buildPlan(
  model: vscode.LanguageModelChat,
  userPrompt: string,
  schema: SchemaSummary,
  maxRows: number,
  token: vscode.CancellationToken
): Promise<SqlPlan> {
  const directPlan = tryBuildDirectSqlPlan(userPrompt);
  if (directPlan) {
    return directPlan;
  }

  const messages = [
    vscode.LanguageModelChatMessage.User(buildPlannerPrompt(userPrompt, schema, maxRows))
  ];

  const response = await model.sendRequest(messages, {}, token);
  const text = await readResponseText(response);
  const plan = parsePlanResponse(text);

  if (plan.intent === 'ddl' && !isExplicitDdlRequest(userPrompt, plan.sql ?? '')) {
    return {
      intent: 'unsupported',
      title: 'Explicit DDL request required',
      explanation: 'DROP, ALTER, and TRUNCATE are only staged when you explicitly request that exact DDL operation.',
      sql: null,
      assumptions: [],
      requiresConfirmation: false
    };
  }

  return plan;
}

export async function summarizeSchema(
  model: vscode.LanguageModelChat,
  userPrompt: string,
  schema: SchemaSummary,
  token: vscode.CancellationToken
): Promise<string> {
  const prompt = [
    'You are helping inside a VS Code Copilot chat participant for MySQL.',
    'Summarize the schema below for a developer.',
    'Use concise markdown with a short overview, key tables, and notable relationships.',
    userPrompt.trim() ? `Focus request: ${userPrompt.trim()}` : 'Focus request: provide a general overview.',
    '',
    'Schema:',
    truncateForPrompt(schema.rawSummary, 14000)
  ].join('\n');

  const response = await model.sendRequest([
    vscode.LanguageModelChatMessage.User(prompt)
  ], {}, token);

  return readResponseText(response);
}

export async function summarizeQueryResult(
  model: vscode.LanguageModelChat,
  userPrompt: string,
  payload: { sql: string; rows: Record<string, unknown>[]; totalRowCount: number },
  token: vscode.CancellationToken
): Promise<string> {
  const prompt = [
    'You are summarizing a MySQL query result inside VS Code.',
    'Respond in concise markdown.',
    `Original user request: ${userPrompt}`,
    `Executed SQL: ${payload.sql}`,
    `Rows returned: ${payload.totalRowCount}`,
    'Sample rows as JSON:',
    truncateForPrompt(JSON.stringify(payload.rows, null, 2), 8000)
  ].join('\n');

  const response = await model.sendRequest([
    vscode.LanguageModelChatMessage.User(prompt)
  ], {}, token);

  return readResponseText(response);
}

function tryBuildDirectSqlPlan(userPrompt: string): SqlPlan | undefined {
  const trimmed = userPrompt.trim();
  if (!trimmed) {
    return undefined;
  }

  const normalized = trimmed.replace(/;+\s*$/, '');
  const lowered = normalized.toLowerCase();

  if (/^(select|show|describe|desc|explain)\b/.test(lowered) || (/^with\b/.test(lowered) && /\bselect\b/.test(lowered))) {
    return {
      intent: 'read',
      title: 'Direct SQL query',
      explanation: 'Running the SQL statement provided directly in chat.',
      sql: normalized,
      assumptions: [],
      requiresConfirmation: false
    };
  }

  if (/^(insert|update|delete)\b/.test(lowered)) {
    return {
      intent: 'mutation',
      title: 'Direct SQL mutation',
      explanation: 'The SQL statement was provided directly in chat and will be staged before execution.',
      sql: normalized,
      assumptions: [],
      requiresConfirmation: true
    };
  }

  if (/^(alter|drop|truncate)\b/.test(lowered)) {
    return {
      intent: 'ddl',
      title: 'Direct SQL DDL statement',
      explanation: 'The DDL statement was provided directly in chat and will be staged for explicit confirmation before execution.',
      sql: normalized,
      assumptions: [],
      requiresConfirmation: true
    };
  }

  return undefined;
}

function buildPlannerPrompt(userPrompt: string, schema: SchemaSummary, maxRows: number): string {
  return [
    'You are a SQL planning assistant for a VS Code Copilot chat participant connected to MySQL.',
    'Return JSON only. Do not wrap it in markdown or code fences.',
    'Allowed intents: schema, read, mutation, unsupported.',
    'Allowed intents: schema, read, mutation, ddl, unsupported.',
    'Return exactly these keys: intent, title, explanation, sql, assumptions, requiresConfirmation.',
    'Rules:',
    '- Emit at most one SQL statement.',
    '- For read intent, only use SELECT, SHOW, DESCRIBE, DESC, EXPLAIN, or a CTE that ends in SELECT.',
    '- For mutation intent, only use INSERT, UPDATE, or DELETE.',
    '- For ddl intent, only use ALTER, DROP, or TRUNCATE.',
    '- Only choose ddl when the user explicitly asks for a DDL change. Otherwise choose unsupported.',
    '- Never emit CREATE, GRANT, REVOKE, RENAME, or other administrative SQL.',
    `- For result-set queries, prefer LIMIT ${maxRows} unless the request is clearly aggregate-only.`,
    '- If the prompt is about understanding the schema, choose schema and set sql to null.',
    '- If the prompt is too ambiguous or unsafe, choose unsupported and explain why.',
    '',
    `User request: ${userPrompt}`,
    '',
    'Schema summary:',
    truncateForPrompt(schema.rawSummary, 16000)
  ].join('\n');
}

async function readResponseText(response: vscode.LanguageModelChatResponse): Promise<string> {
  let text = '';
  for await (const fragment of response.text) {
    text += fragment;
  }
  return text.trim();
}

function parsePlanResponse(text: string): SqlPlan {
  const jsonText = extractJsonObject(text);
  const parsed = JSON.parse(jsonText) as Partial<SqlPlan> & { assumptions?: unknown };
  const intent = normalizeIntent(parsed.intent);

  return {
    intent,
    title: typeof parsed.title === 'string' && parsed.title.trim() ? parsed.title.trim() : 'Planned database action',
    explanation: typeof parsed.explanation === 'string' && parsed.explanation.trim() ? parsed.explanation.trim() : 'No explanation provided.',
    sql: typeof parsed.sql === 'string' && parsed.sql.trim() ? parsed.sql.trim() : null,
    assumptions: Array.isArray(parsed.assumptions)
      ? parsed.assumptions.filter((value): value is string => typeof value === 'string' && value.trim().length > 0)
      : [],
    requiresConfirmation: Boolean(parsed.requiresConfirmation || intent === 'mutation')
  };
}

function normalizeIntent(value: unknown): SqlPlan['intent'] {
  switch (value) {
    case 'schema':
    case 'read':
    case 'mutation':
    case 'unsupported':
    case 'ddl':
      return value;
    default:
      return 'unsupported';
  }
}

function extractJsonObject(text: string): string {
  const trimmed = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/```$/, '').trim();
  const firstBrace = trimmed.indexOf('{');
  const lastBrace = trimmed.lastIndexOf('}');
  if (firstBrace === -1 || lastBrace === -1 || lastBrace < firstBrace) {
    throw new Error('The language model did not return valid JSON.');
  }
  return trimmed.slice(firstBrace, lastBrace + 1);
}

function truncateForPrompt(value: string, maxLength: number): string {
  if (value.length <= maxLength) {
    return value;
  }

  return `${value.slice(0, maxLength)}\n...[truncated]`;
}

function isExplicitDdlRequest(userPrompt: string, sql: string): boolean {
  const prompt = userPrompt.trim().toLowerCase();
  const normalizedSql = sql.trim().toLowerCase();

  if (/^(alter|drop|truncate)\b/.test(prompt)) {
    return true;
  }

  if (/\b(alter|drop|truncate)\b/.test(prompt) && /^(alter|drop|truncate)\b/.test(normalizedSql)) {
    return true;
  }

  return false;
}