# Step 4: Start Implementation

## Purpose

This is where design and stories become working code. Implementation must follow clean architecture principles, best practices, and project conventions to ensure the code is maintainable, testable, and performs well.

## Why This Step Matters

Poor implementation:
- Creates technical debt that slows future development
- Makes testing difficult and incomplete
- Introduces bugs and security vulnerabilities
- Causes performance problems in production

Good implementation:
- Follows project standards for consistency
- Is easy for other developers to understand and modify
- Can be thoroughly tested with high confidence
- Performs efficiently at scale

## What You'll Do

1. **Use Coder for This Step** — Step 4 is the implementation step:
   - Use `coder` for Step 4
   - Do not use `coder` before Step 4
   - Do not complete Step 4 directly through the orchestrator
   - Start only after Step 2 is complete and any Step 3 work started in parallel has been reconciled with the final design

2. **Follow Clean Architecture** — Organize code into layers:
   - **Domain Layer** (package: `domain`): Core business logic and entities
   - **Use Case Layer** (package: `usecase`): Application logic that orchestrates domain entities
   - **Adapter Layer** (package: `adapter`): Controllers and gateways that convert between use cases and external systems
   - **Gateway Layer** (package: `gateway`): Implementations for database, API calls, UI rendering, etc.
   - Keep business logic out of controllers; controllers only handle input/output mapping
   - Reuse the boundaries defined in the Step 2 technical design

3. **Load the Identified Language Skill**:
   - Use the skill files for the identified implementation language before coding
   - Apply the repository language baseline and any required supporting skills
   - For Java, follow the Java package structure and naming rules under `com.adp`

4. **Language and Framework Standards**:
   - For **Java**: Use version 21+, Spring Boot by default, Lombok, builder patterns
   - For **NodeJS**: Use appropriate package management and modern async patterns
   - For **Python**: Follow PEP 8, use type hints, appropriate frameworks
   - For new **Java** apps, APIs, and backend features, do not use plain Java, raw servlets, JAX-RS, Micronaut, Quarkus, or other frameworks unless explicitly requested
   - For **Java** model classes, Lombok is mandatory in this repository; if it is missing from `build.gradle` or `build.gradle.kts`, add it during Step 4 before implementing DTOs, entities, commands, responses, or value objects
   - Use JDBC for database access (not JPA/Hibernate) unless explicitly required

5. **Code Quality Practices**:
   - Write clean, self-documenting code with meaningful variable and method names
   - Use appropriate design patterns and avoid code duplication
   - Apply linting tools (Checkstyle for Java, ESLint for NodeJS, Pylint for Python)
   - Follow project naming conventions and file organization

6. **Logging and Debugging**:
   - Add logs at key points (entry/exit of important functions, state changes)
   - Log errors and exceptions with context (stack traces, input values)
   - Never log sensitive data (passwords, tokens, PII)
   - Use appropriate log levels (DEBUG, INFO, WARN, ERROR)

7. **Implementation and Output Rules**:
   - Read feature details and directly impacted files first
   - Avoid re-reading unchanged code unless debugging is needed
   - Generate or update files in the workspace
   - Do not print implementation code in chat
   - Return only short progress summaries
   - Update existing tests as behavior changes
   - Batch implementation work in one focused pass when possible
   - Run the required verification at the end of implementation unless you are blocked and need troubleshooting first

8. **Validation and Input Handling**:
   - Validate and sanitize all external inputs (forms, API calls, files)
   - Prevent common vulnerabilities like SQL injection and XSS
   - Handle invalid input gracefully with clear error messages

## Language-Specific Notes

### Java
- Use Spring Boot for new Java implementations by default
- If Spring Boot is not configured yet, propose the required `build.gradle` changes and get confirmation before editing build files
- For new Java projects, complete required `build.gradle` or `build.gradle.kts` dependency and plugin setup during Step 4 so the project is buildable before later validation and verification
- Inspect `build.gradle` or `build.gradle.kts` before implementing Java classes and add Lombok if it is missing
- Use Lombok for DTOs, entities, commands, responses, and value objects; do not use Java `record` classes for those model types
- Run `java -version` or `java --version` once after build bootstrap is in place and before final verification to inspect the installed JDK
- Annotate REST controllers with `@RestController` and `@RequestMapping`
- Name API controller classes with the `Controller` suffix, for example `ClientController`
- Annotate services with `@Service` and use constructor-based dependency injection
- Place `@Configuration` classes in a dedicated `configuration` package
- Annotate repositories with `@Repository` and use JDBC
- If a Java solution would not use Spring Boot, stop and get explicit approval before proceeding
- Main application class: name it `Application`, place in root package (e.g., `com.adp`), use `@SpringBootApplication`
- Create `application.yml` and `application-development.yml` for configuration

### Performance and Scalability
- For APIs: Consider caching with Redis if applicable
- For APIs: Consider circuit breakers with Resilience4j for external dependencies
- For APIs: Use async patterns where I/O-bound operations are common

## Output

Fully implemented feature code organized in clean architecture layers with:
- All business logic properly separated from presentation and infrastructure
- Comprehensive logging for debugging and monitoring
- Input validation and error handling
- Tests for all major code paths (will be validated in Step 6)

## When To Proceed

Before moving to Step 5:
- Step 4 was completed through `coder`
- All code follows clean architecture principles
- The identified language skill was applied during implementation
- Code passes linting and style checks
- Required Java framework bootstrap and dependency/plugin setup is complete for new Java projects
- Required Java Lombok setup is complete before model-class implementation
- Implementation is ready for Step 6 test execution and verification
- Implementation aligns with the technical design
- Non-critical follow-up ideas are noted without interrupting the implementation flow

---

**Previous Step:** [Step 3 - Create User Stories](step-3.md)  
**Next Step:** [Step 5 - Security Validation](step-5.md)
