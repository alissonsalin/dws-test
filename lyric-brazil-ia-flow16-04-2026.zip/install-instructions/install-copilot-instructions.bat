@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "SCRIPT_DIR=%~dp0"
for %%I in ("%SCRIPT_DIR%.") do set "SCRIPT_DIR=%%~fI"
for %%I in ("%SCRIPT_DIR%\..") do set "REPO_ROOT=%%~fI"
set "SOURCE_GITHUB=%REPO_ROOT%\.github"

echo Copilot instruction installer
echo.
if not exist "%SOURCE_GITHUB%" (
  echo [ERROR] Source folder not found: %SOURCE_GITHUB%
  exit /b 1
)

echo Source: %SOURCE_GITHUB%
set /p "TARGET_REPO=Enter target repository path: "

if "%TARGET_REPO%"=="" (
  echo [ERROR] Target repository path is required.
  exit /b 1
)

if not exist "%TARGET_REPO%" (
  echo [ERROR] Target repository does not exist: %TARGET_REPO%
  exit /b 1
)

set "TARGET_GITHUB=%TARGET_REPO%\.github"
if not exist "%TARGET_GITHUB%" mkdir "%TARGET_GITHUB%"

set /a TOTAL_FILES=0
set /a TOTAL_DIRS=0
set /a TARGET_FILES=0
set /a TARGET_DIRS=0

for /r "%SOURCE_GITHUB%" %%F in (*) do set /a TOTAL_FILES+=1
for /f "delims=" %%D in ('dir "%SOURCE_GITHUB%" /ad /b /s 2^>nul') do set /a TOTAL_DIRS+=1

echo [INFO] Copying full .github content (files and folders)...
where robocopy >nul 2>&1
if errorlevel 1 (
  echo [ERROR] robocopy is not available on this system.
  exit /b 1
)

robocopy "%SOURCE_GITHUB%" "%TARGET_GITHUB%" /E /R:2 /W:1 /COPY:DAT /DCOPY:DAT /XJ /NFL /NDL /NJH /NJS /NC /NS /NP >nul
set "ROBOCODE=%ERRORLEVEL%"

if %ROBOCODE% GEQ 8 (
  echo [ERROR] Copy failed with robocopy exit code: %ROBOCODE%
  echo.
  echo Install summary
  echo - Source: %SOURCE_GITHUB%
  echo - Target: %TARGET_GITHUB%
  echo - Source files: !TOTAL_FILES!
  echo - Source folders: !TOTAL_DIRS!
  echo Status: FAILURE
  exit /b 1
)

echo.
echo Install summary
echo - Source: %SOURCE_GITHUB%
echo - Target: %TARGET_GITHUB%
echo - Source files: !TOTAL_FILES!
echo - Source folders: !TOTAL_DIRS!

if !TOTAL_FILES! EQU 0 (
  echo Status: NO_FILES_TO_COPY
  echo [WARN] Source .github exists but has no files. Add instruction files and run again.
  exit /b 1
)

for /r "%TARGET_GITHUB%" %%F in (*) do set /a TARGET_FILES+=1
for /f "delims=" %%D in ('dir "%TARGET_GITHUB%" /ad /b /s 2^>nul') do set /a TARGET_DIRS+=1

echo - Target files: !TARGET_FILES!
echo - Target folders: !TARGET_DIRS!

if !TARGET_FILES! LSS !TOTAL_FILES! (
  echo [ERROR] Target has fewer files than source after copy.
  echo Status: FAILURE
  exit /b 1
)

if !TARGET_DIRS! LSS !TOTAL_DIRS! (
  echo [ERROR] Target has fewer folders than source after copy.
  echo Status: FAILURE
  exit /b 1
)

echo Status: SUCCESS
echo [SUCCESS] Copilot instruction files were copied successfully.
echo [SUCCESS] Project ready: %TARGET_REPO%
echo [SUCCESS] You can now use Copilot Chat with project instructions in this repository.
exit /b 0
