#!/usr/bin/env bash

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$REPO_ROOT"

echo "[INFO] Repository root: $REPO_ROOT"

install_python_linux() {
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo apt-get install -y python3 python3-pip python3-venv
    return
  fi

  if command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y python3 python3-pip
    return
  fi

  if command -v pacman >/dev/null 2>&1; then
    sudo pacman -S --noconfirm python python-pip
    return
  fi

  echo "[ERROR] Unsupported Linux package manager. Install python3, pip, and venv manually."
  exit 1
}

if ! command -v python3 >/dev/null 2>&1; then
  echo "[WARN] python3 not found. Attempting installation..."
  case "$(uname -s)" in
    Darwin)
      if command -v brew >/dev/null 2>&1; then
        brew install python
      else
        echo "[ERROR] Homebrew not found. Install Python from https://www.python.org/downloads/macos/"
        exit 1
      fi
      ;;
    Linux)
      install_python_linux
      ;;
    *)
      echo "[ERROR] Unsupported OS. Install Python manually and re-run."
      exit 1
      ;;
  esac
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[ERROR] python3 still not found after install attempt."
  exit 1
fi

if [ ! -d ".venv" ]; then
  echo "[INFO] Creating virtual environment..."
  python3 -m venv .venv
fi

# shellcheck disable=SC1091
source .venv/bin/activate

echo "[INFO] Installing Python dependencies..."
python -m pip install --upgrade pip
python -m pip install mkdocs mkdocs-material pymdown-extensions

echo "[INFO] Starting MkDocs with livereload..."
python -m mkdocs serve --livereload
