---
applyTo: "**/*{test,spec}*.{java,js,ts,py}"
description: "Use when creating or updating tests to ensure predictable, maintainable coverage of feature behavior."
---

# Test Authoring Rules

- Cover both happy path and error path for each behavior change.
- Keep test names behavior-focused and explicit.
- Follow Arrange, Act, Assert structure.
- Use mocks only at external boundaries.
- Avoid brittle assertions tied to implementation details.
- Keep fixtures minimal and local to the test when possible.
- For Java Spring tests, integrate Mockito with Spring test support:
	- use `@ExtendWith(MockitoExtension.class)` for pure unit tests
	- use `@MockBean` with Spring test slices when replacing Spring-managed dependencies
	- keep business-layer tests focused and independent from full context loading when possible

# Quality and Coverage

- Add tests for input validation and edge cases.
- Prefer deterministic tests without timing dependencies.
- Ensure failures are easy to diagnose from test output.
- Update existing tests when requirements or contracts change.
- For Java clean architecture changes, follow `.github/instructions/archunit.instructions.md` as the single source of truth for ArchUnit scope and timing.
- For critical validation logic, add mutation testing in CI to verify assertion strength.
- For public HTTP APIs, add controller contract tests generated from OpenAPI snapshots.
- If mutation or contract tests are skipped, document the reason and risk in test notes.

# Coverage Floors by Layer

- Apply coverage goals per clean architecture layer as a verification gate. Do not use a single 100% line coverage target.
- `domain` layer: 90%+ line coverage. This is core business logic and must be thoroughly tested.
- `usecase` layer: 90%+ line coverage. All orchestration flows, success paths, and failure paths must be covered.
- `adapter` layer: integration-tested via controller/slice tests. Unit coverage is secondary to contract correctness.
- `gateway` layer: 90%+ line coverage. Use integration tests and/or focused tests to ensure this floor is met.
- Do not write tests purely to satisfy a coverage number. Every test must verify a meaningful behavior or failure case.
- Do not mark Java test work complete if changed `domain`, `usecase`, or `gateway` code is below the coverage floor unless the gap is explicitly documented and approved.
- When package structure allows, configure JaCoCo verification rules to enforce minimum coverage for `domain`, `usecase`, and `gateway` packages.

# JaCoCo Coverage Reporting (Java)

- Run test and JaCoCo commands in non-interactive mode only (no prompts, no interactive menus, no input waiting).
- For Java features, ensure JaCoCo plugin/configuration exists in the build file (`build.gradle` or `build.gradle.kts`).
- If JaCoCo configuration is missing, add it before final verification.
- After unit test creation and execution, generate JaCoCo coverage reports in the same verification cycle.
- Preferred Gradle flow: run tests and report generation together (for example `test jacocoTestReport`).
- Ensure HTML reports are generated for review.
- When JaCoCo verification rules are configured, run coverage verification in the same cycle and fix failures before closing Step 6.
- Coverage summary must be shared from JaCoCo output (do not rely on assumptions without report artifacts).
- If a valid JaCoCo HTML report already exists for the current code state and the user asks for coverage, read and summarize the generated report instead of rerunning test/coverage commands.

# Maintainability

- Group tests by feature behavior, not by helper method.
- Remove dead or duplicate tests when replacing behavior.
- Keep helper utilities small and reusable.
