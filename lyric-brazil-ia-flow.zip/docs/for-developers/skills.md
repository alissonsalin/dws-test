# Skills

## Purpose

This page documents the on-demand skills used in this repository. Skills are loaded only for specialized tasks so they do not consume context in every session.

## When To Use Skills

Use a skill when you need:

- a focused workflow for a narrow task
- reusable guidance that should remain opt-in
- specialized remediation, validation, or test patterns
- support material that complements agents and instructions instead of replacing them

## Skills in This Repository

### `.github/skills/cli-resilience/SKILL.md`

- Covers command preflight checks.
- Enforces fix-driven retries instead of unchanged reruns.
- Captures concise failure details for later reuse.
- Fits command recovery and validation workflows.

### `.github/skills/archunit/SKILL.md`

- Covers Java architecture boundary tests.
- Focuses on ArchUnit structure, layer rules, and test placement.
- Fits Java feature changes that affect clean architecture boundaries.

### `.github/skills/java/SKILL.md`

- Covers the Java implementation baseline, including package structure, naming, repository and gateway placement, and Java-specific reliability rules.
- Fits Java feature work once implementation has explicitly started in Java.

### `.github/skills/nodejs/SKILL.md`

- Covers the Node.js implementation baseline, including layer structure, routing boundaries, and runtime quality expectations.
- Fits Node.js feature work once implementation has explicitly started in Node.js.

### `.github/skills/python/SKILL.md`

- Covers the Python implementation baseline, including clean architecture structure, validation boundaries, and testing expectations.
- Fits Python feature work once implementation has explicitly started in Python.

### `.github/skills/spring/SKILL.md`

- Covers Spring Boot controller, configuration, bean wiring, and YAML profile conventions.
- Fits Java feature work that adds or changes Spring-managed components.

### `.github/skills/lombok/SKILL.md`

- Covers Lombok-backed DTO, entity, command, and builder patterns.
- Fits Java class implementation in this repository and requires adding Lombok to Gradle if it is missing.

### `.github/skills/java-cli/SKILL.md`

- Covers Java version detection timing, Gradle Wrapper preference, and Java workflow command rules.
- Fits Step 4 setup, including Lombok and OWASP build checks, plus verification and Java security validation.

### `.github/skills/jacoco/SKILL.md`

- Covers JaCoCo setup, Gradle coverage verification wiring, and Java coverage-report expectations.
- Fits Java implementation and Step 6 test work that needs coverage policy without making JaCoCo always-on.

### `.github/skills/openapi/SKILL.md`

- Covers annotation-driven OpenAPI and Swagger contract guidance.
- Fits public HTTP API design, implementation, and validation tasks.

### `.github/skills/node-python-cli/SKILL.md`

- Covers Node.js and Python command preflight checks and fix-driven retries.
- Fits verification and security command execution for Node.js and Python workflows.

## Relationship To Other Customizations

1. Skills are not always-on; they are loaded only when the task calls for them.
2. Agents orchestrate workflows, while skills support specialized sub-workflows.
3. Instructions remain the source of truth for scoped, automatically applied rules.
4. This repository intentionally moves language-specific, framework-specific, and runtime-specific development guidance into skills to reduce default chat context.

## Selection Guidance

- Use instructions for broad, file-pattern-based rules.
- Use agents for multi-step workflow execution.
- Use skills for narrow, reusable expertise that should stay opt-in.
- Prefer a skill over an instruction when the guidance is only needed after implementation starts.

## Related References

- [Custom Instructions](custom-instructions.md)
- [Agents](agents.md)
- [Arch Unit](../technologies/arch-unit.md)
- [Unit test](unit-test.md)