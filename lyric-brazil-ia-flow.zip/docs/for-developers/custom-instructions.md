# Custom Instructions

## Purpose

This page documents the instruction files used by Copilot during feature workflows. It focuses on the workspace entrypoint and the scoped `.instructions.md` files that load automatically by file pattern.

This repository now keeps the automatic instruction surface intentionally small. Framework-specific and language-specific implementation guidance that is only needed during active development has been moved into on-demand skills.

## How Instruction Loading Works

- The workspace entrypoint is defined in `.github/copilot-instructions.md`.
- File-scoped instructions are defined in `.github/instructions/*.instructions.md`.
- Each instruction file has an `applyTo` pattern that determines when it is loaded.
- When more than one instruction applies, use the most specific file as source of truth for detailed behavior.

## Workspace Entrypoint

The workspace entrypoint is `.github/copilot-instructions.md`.

It is responsible for:

- pointing feature work to the `feature-flow` agent
- listing always-on instruction files
- listing on-demand skills
- defining shared feature deliverables and workspace-level expectations

## Instruction Files in This Repository

### `.github/instructions/workflow-status.instructions.md`

- Standardizes checklist format and status icons in workflow-facing documentation and agent definitions.
- Ensures every step (1 to 9) is shown with a clear current status.
- Prevents partial or inconsistent workflow status reporting.

### `.github/instructions/design-first.instructions.md`

- Blocks coding actions in workflow documentation contexts until Step 2 (technical design) is approved.
- Keeps requirement analysis and design separated from code generation.
- Works with the feature-flow agent instead of replacing it.

### `.github/instructions/command-resilience.instructions.md`

- Defines retry and remediation behavior for command failures.
- Requires fix-first retries instead of rerunning failing commands unchanged.
- Encourages preflight checks to reduce avoidable command errors.

### Specialized concerns moved to skills

- Java implementation baseline now lives in `.github/skills/java/SKILL.md`.
- Node.js implementation baseline now lives in `.github/skills/nodejs/SKILL.md`.
- Python implementation baseline now lives in `.github/skills/python/SKILL.md`.
- Spring Boot conventions now live in `.github/skills/spring/SKILL.md`.
- Lombok rules now live in `.github/skills/lombok/SKILL.md`.
- Java CLI startup and validation flow now lives in `.github/skills/java-cli/SKILL.md`.
- Annotation-driven OpenAPI guidance now lives in `.github/skills/openapi/SKILL.md`.
- Node/Python command remediation now lives in `.github/skills/node-python-cli/SKILL.md`.

## Detailed Instruction Reference

### `.github/copilot-instructions.md` (Workspace Entrypoint)

- Points feature work to the `feature-flow` agent.
- Lists always-on instruction files and on-demand skills.
- Defines feature deliverables and shared workspace-level guidance.

### `.github/instructions/workflow-status.instructions.md`

- Standardizes checklist format and status icons in workflow-facing documentation and agent definitions.
- Ensures every step (1 to 9) is shown with a clear current status.
- Prevents partial or inconsistent workflow status reporting.

### `.github/instructions/design-first.instructions.md`

- Blocks coding actions in workflow documentation contexts until Step 2 (technical design) is approved.
- Keeps requirement analysis and design separated from code generation.
- Works with the feature-flow agent instead of replacing it.

### `.github/agents/tech-refresh.agent.md`

- Executes the tech refresh workflow as a dedicated agent.
- Captures prerequisite analysis and approval before the normal feature workflow begins.
- Hands off to the standard feature workflow after approval while preserving repository rules.

### `.github/agents/tech-refresh-orchestrator.agent.md`

- Coordinates a two-agent handoff for migration work.
- Starts with `tech-refresh` for prerequisite analysis and approval handling.
- Continues with `feature-flow` only after explicit approval is captured.

### `.github/instructions/tech-refresh.instructions.md`

- Defines the required sections for tech refresh analysis documents.
- Prevents documenting or executing Step 1 to Step 9 before analysis approval.
- Standardizes migration planning, validation planning, and rollback coverage.

### `.github/instructions/command-resilience.instructions.md`

- Defines retry and remediation behavior for command failures.
- Requires fix-first retries instead of rerunning failing commands unchanged.
- Encourages preflight checks to reduce avoidable command errors.

### `.github/instructions/docs.instructions.md`

- Defines documentation writing quality, structure, and consistency.
- Enforces Step 2 diagrams (ASCII + Mermaid) when producing technical design docs.
- Adds required technical design sections, including impact/risk checks.

### `.github/instructions/clean-architecture.instructions.md`

- Defines architecture boundaries: `domain`, `usecase`, `adapter`, `gateway`.
- Enforces inward dependency direction.
- Clarifies boundary ownership for interfaces and infrastructure implementations.

### `.github/instructions/testing.instructions.md`

- Defines test authoring expectations (happy path, failure path, edge cases).
- Enforces cross-language coverage floors by layer and general completion gates.
- Routes stack-specific coverage tooling and exact execution behavior to the relevant skills.

### Related skills used during implementation

#### `.github/skills/java/SKILL.md`

- Defines Java implementation conventions, package structure, and naming rules.
- Keeps Java policy off the always-on instruction path until Java development explicitly starts.

#### `.github/skills/archunit/SKILL.md`

- Defines ArchUnit layer-boundary rules, placement, and timing for Java architecture tests.
- Keeps architecture-test policy off the always-on instruction path until Java architecture test work explicitly starts.

#### `.github/skills/nodejs/SKILL.md`

- Defines Node.js clean architecture conventions and implementation quality rules.
- Keeps Node.js policy off the always-on instruction path until Node.js development explicitly starts.

#### `.github/skills/python/SKILL.md`

- Defines Python clean architecture conventions and testing expectations.
- Keeps Python policy off the always-on instruction path until Python development explicitly starts.

#### `.github/skills/spring/SKILL.md`

- Enforces Spring-specific structure and annotation rules.
- Requires constructor injection and blocks `@Autowired` field injection.
- Enforces YAML-only configuration (`application.yml`, `application-development.yml`, and `application-test.yml`).
- Requires `Application` as the exact main class name.

#### `.github/skills/lombok/SKILL.md`

- Defines Lombok usage strategy for Java DTO/entity/command/response classes.
- Enforces `@Builder`-based object construction patterns.
- Requires Lombok to be added to `build.gradle` or `build.gradle.kts` before Java model-class implementation when it is missing.
- Blocks Java `record` usage for those model types.

#### `.github/skills/java-cli/SKILL.md`

- Defines Java command-line flow, including Java version detection timing.
- Enforces a single Java detection execution at Step 4 start.
- Aligns command usage with repository-approved verification flow.
- Requires Step 4 inspection of `build.gradle` or `build.gradle.kts` for mandatory Lombok and OWASP setup before later validation.

#### `.github/skills/jacoco/SKILL.md`

- Defines Java JaCoCo coverage setup, verification thresholds, and report expectations.
- Keeps Java coverage tooling and report policy off the always-on instruction path until Java implementation or verification work explicitly starts.

#### `.github/skills/openapi/SKILL.md`

- Enforces API documentation alignment with implementation and tests.
- Uses dependency/annotation-driven OpenAPI generation by default.
- Blocks creation of standalone Swagger/OpenAPI files unless explicitly requested.

#### `.github/skills/node-python-cli/SKILL.md`

- Applies command resilience behavior specifically for NodeJS and Python workflows.
- Reduces retry loops and enforces fix-driven command remediation.

## Precedence and Conflict Handling

1. Use `.github/copilot-instructions.md` as the workspace entrypoint.
2. Use the relevant file-level instruction as source of truth for technical detail.
3. If two file-level rules overlap, prioritize the more specific domain file:
   - testing details: `.github/instructions/testing.instructions.md`
   - architecture tests: `.github/skills/archunit/SKILL.md`
   - Spring config/annotations: `.github/skills/spring/SKILL.md`
   - API contract behavior: `.github/skills/openapi/SKILL.md`
4. Keep workspace entrypoints and workflow files concise and avoid duplicating deep technical rules.
5. Use the tech refresh agent and instruction only for migration-style work; keep default feature flow unchanged for ordinary delivery.

## Operational Rules You Should Expect

- Design approval is required before implementation actions.
- Tech refresh work requires prerequisite analysis approval before Step 1 starts.
- Interactive gates use numbered options with icons.
- Test commands run in non-interactive mode.
- Java JaCoCo behavior should come from the dedicated JaCoCo skill when Java coverage work is active.
- Java API implementations should use dependency-driven OpenAPI generation and controller annotations by default (no standalone OpenAPI files unless explicitly requested).
- Java, Node.js, Python, API, and CLI implementation specifics are loaded through skills during active development instead of being always-on.

## Related References

- [For Developers - Overview](overview.md)
- [Agents](agents.md)
- [Skills](skills.md)
- [Clean Architecture](clean-architecture.md)
- [Unit test](unit-test.md)
- [Flow - Step 2](../flow/step-2.md)
- [Flow - Step 6](../flow/step-6.md)
