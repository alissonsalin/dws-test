---
description: "Use when preparing or updating tech refresh analysis documents. Enforce prerequisite analysis and explicit approval before running Step 1 to Step 9."
---

# Tech Refresh Documentation Rules

- This instruction is for tech refresh documentation only.
- Keep default feature workflow instructions unchanged.
- Treat prerequisite analysis as mandatory before Step 1 to Step 9.

## Required Sections

- Requirement Summary
- Current State Analysis
- Target State Architecture
- Migration Plan by Waves
- Validation Plan
- Risks and Rollback
- Approval Decision and Date

## Prerequisite Gate Rule

- Do not run or document Step 1 to Step 9 execution until analysis and migration plan are approved.
- Approval must be explicit and recorded.

## Analysis Quality Requirements

- Include component inventory, risk matrix, dependency migration constraints with fallback options, and validation coverage for functional, contract, data, security, and performance checks.

## Writing Style

- Use concise, task-oriented language.
- Keep assumptions explicit.
- Prefer numbered procedures and acceptance checkpoints.
