# Installation

Use the installer scripts in the install-instructions folder to copy the .github instruction pack into your target repository.

## Option 1: Windows Script

The installer automatically uses this repository .github folder as the source.

1. Open a terminal in this repository root.
2. Run:

```powershell
.\install-instructions\install-copilot-instructions.bat
```

3. Enter the full path of the target repository when prompted.
4. Wait for the copy to complete.
5. Review the install summary output.

## Option 2: MacOS/Linux Script

The installer automatically uses this repository .github folder as the source.

1. Open a terminal in this repository root.
2. Make the script executable (first time only):

```bash
chmod +x ./install-instructions/install-copilot-instructions.sh
```

3. Run:

```bash
bash ./install-instructions/install-copilot-instructions.sh
```

4. Enter the full path of the target repository when prompted.
5. Review the install summary output.

## Status Codes

| Status | Meaning |
|---|---|
| SUCCESS | All files copied successfully. |
| FAILURE | Copy failed or target ended up with fewer files than source. Check terminal output for [ERROR] lines. |
| NO_FILES_TO_COPY | Source .github exists but contains no files. Add instruction files and re-run. |

## What Gets Installed

The installer copies the entire .github folder from this repository into the target repository, including:

1. Global workspace instructions from .github/copilot-instructions.md.
2. Scoped instruction files from .github/instructions/, applied by applyTo patterns.

## Next Step

Go to [IDE Setup](ide-setup.md).