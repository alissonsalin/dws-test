# IDE Setup

After installation, set up and verify your IDE environment.

## Visual Studio Code

1. Open the target repository in Visual Studio Code.
2. Confirm these paths exist:
   - .github/copilot-instructions.md
   - .github/instructions/
   - .github/agents/
   - .github/skills/
3. Ensure GitHub Copilot and Copilot Chat extensions are installed and authenticated.
4. Open Copilot Chat and start a new chat session.

## IntelliJ IDEA

1. Open the target repository in IntelliJ IDEA.
2. Confirm these paths exist:
   - .github/copilot-instructions.md
   - .github/instructions/
   - .github/agents/
   - .github/skills/
3. Ensure the GitHub Copilot plugin is installed and authenticated.
4. Open GitHub Copilot Chat and start a new chat session.
5. If you plan to run the feature workflow agent, open the chat tool configuration and enable the required built-in tools.
6. In the Configure Tools dialog, keep the built-in tools required for file editing, search, terminal execution, and task tracking enabled.
7. At minimum, verify these built-in tools are enabled before running the agent:
   - insert_edit_into_file
   - replace_string_in_file
   - create_file
   - apply_patch
   - read_file
   - file_search
   - grep_search
   - run_in_terminal
   - get_terminal_output
   - get_errors
   - run_subagent
8. If the agent starts explaining changes instead of editing files or running commands, re-open Configure Tools and confirm the built-in tools are still enabled.

## Next Step

Go to [Copilot Usage](copilot-usage.md).