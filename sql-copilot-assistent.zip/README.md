# SQL Copilot Assistant

SQL Copilot Assistant is a VS Code extension that contributes a Copilot Chat participant named `@mysqlca`. It connects to a MySQL database, inspects the schema, translates natural language into SQL with Copilot, executes read queries, and stages data-changing queries for explicit approval.

## What it does

- Analyzes the connected MySQL schema.
- Answers database questions in natural language.
- Runs `SELECT`, `SHOW`, `DESCRIBE`, and `EXPLAIN` queries.
- Stages `INSERT`, `UPDATE`, and `DELETE` statements and only executes them after explicit approval.
- Stores the database password in VS Code secret storage instead of plain settings.

## Configure the extension

After installing the extension, run `SQL Copilot: Configure MySQL Connection` from the Command Palette. The command stores the connection details inside the extension and saves the password in VS Code secret storage.

If you only need to switch schemas later, run `SQL Copilot: Set Database`.

You can still set these settings in VS Code if you want to override the stored connection:

- `sqlCopilot.host`
- `sqlCopilot.port`
- `sqlCopilot.user`
- `sqlCopilot.database`
- `sqlCopilot.connectionLimit`
- `sqlCopilot.maxRows`
- `sqlCopilot.useSsl`

You can test the saved connection at any time with `SQL Copilot: Test MySQL Connection`.

## Chat usage

Use the participant in Copilot Chat:

- `@mysqlca /schema`
- `@mysqlca show me the five most recent orders with customer names`
- `@mysqlca how many users signed up this week?`
- `@mysqlca update all inactive customers to archived = 1`
- `@mysqlca /apply`
- `@mysqlca /discard`

Mutations are never executed directly from the first natural-language request. The extension stages the generated SQL first, then waits for `/apply` or the command button.

`ALTER`, `DROP`, and `TRUNCATE` are also staged, but only when you explicitly request those commands. They always require an additional confirmation step before execution.

## Local development

1. Run `npm install`
2. Run `npm run compile`
3. Press `F5` in VS Code to launch the Extension Development Host
4. Open Copilot Chat in the Extension Development Host and use `@mysqlca`

## Package the extension

To generate an installable VSIX file from the project root, run:

```powershell
npx --yes @vscode/vsce package --allow-missing-repository --skip-license
```

This creates a file like `sql-copilot-assistant-0.0.1.vsix` in the project root.

## Limitations

- The quality of generated SQL depends on the schema summary and the selected Copilot model.
- `ALTER`, `DROP`, and `TRUNCATE` are only staged for explicit user requests and require confirmation before execution.
- Read query limiting is prompt-driven. The participant asks Copilot to generate bounded queries, but complex queries can still return large result sets depending on the server and schema.