# Lombok Annotations

Lombok is a Java library that reduces boilerplate code through annotation processing. It generates getters, setters, constructors, builders, and more at compile time.

---

## When to Use Lombok

- **Recommended:** Entity classes, DTOs, request/response payloads, and command objects
- **Required:** When using `@Builder` for object construction (see Builder Pattern section below)
- **Conditional:** Only if the project already includes Lombok as a dependency

If your project does not yet have Lombok, stop and confirm the dependency addition before using Lombok annotations.

---

## Builder Pattern for Object Creation

### Why Use `@Builder`?

The Builder pattern provides a clear, fluent API for constructing objects with multiple fields. Lombok's `@Builder` annotation generates the builder automatically.

### Usage

**Always use `@Builder` on:**
- Domain entities
- DTOs and response payloads
- Command objects in use cases
- Request objects for API endpoints

**Example:**

```java
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ClientRegistrationCommand {
    private String name;
    private String email;
    private String phone;
}
```

**Construction:**

```java
ClientRegistrationCommand cmd = ClientRegistrationCommand.builder()
    .name("Alice Silva")
    .email("alice@example.com")
    .phone("+1-555-0123")
    .build();
```

### Best Practices

- Place `@Builder` on the class level, not on constructors.
- Combine `@Builder` with `@Data` to get getters, setters, and equals/hashCode.
- Use builder pattern to avoid constructor parameter bloat and improve readability.
- For immutable objects, use `@Builder` with `@Value` instead of `@Data`.

---

## Common Lombok Annotations

| Annotation | Generates | Use Case |
|---|---|---|
| `@Data` | Getters, setters, toString, equals, hashCode, RequiredArgsConstructor | Simple entities and DTOs |
| `@Getter` / `@Setter` | Getters / setters | Fine-grained control |
| `@NoArgsConstructor` | No-arg constructor | JPA entities, serialization frameworks |
| `@AllArgsConstructor` | Constructor with all fields | Rarely used; use `@Builder` instead |
| `@RequiredArgsConstructor` | Constructor for final fields | Dependency injection in Spring beans |
| `@Builder` | Builder pattern | Object construction (mandatory for multi-field objects) |
| `@Slf4j` | Logger instance | Service and controller classes |
| `@EqualsAndHashCode` | equals and hashCode methods | Use with caution on JPA entities |

---

## Lombok in Clean Architecture

### Domain Layer (`domain`)

Use `@Builder` on entities for immutable object creation during persistence.

```java
@Data
@Builder
public class Client {
    private UUID id;
    private String name;
    private String email;
}
```

### Use Case Layer (`usecase`)

Use `@Builder` on command objects for clear request construction.

```java
@Data
@Builder
public class RegisterClientCommand {
    private String name;
    private String email;
}
```

### Adapter Layer (`adapter`)

Use `@Data` and `@Builder` on request/response DTOs for API endpoints.

```java
@Data
@Builder
public class RegisterClientResponse {
    private UUID clientId;
    private String status;
}
```

### Gateway Layer (`gateway`)

Use `@Slf4j` on repository implementations for consistent logging.

```java
@Slf4j
public class ClientRepositoryJdbc implements ClientRepository {
    // Implementation
}
```

---

## Verification

### IDE Setup

Ensure Lombok annotation processing is enabled:

- **IntelliJ IDEA:** Settings → Build, Execution, Deployment → Compiler → Annotation Processors → Enable annotation processing
- **Eclipse:** Window → Preferences → Java → Compiler → Annotation Processing → Enable project specific settings
- **VS Code:** Install Lombok Annotations Support extension (or configure lombok in `.code-workspace`)

### Build Configuration

Verify Gradle includes the annotation processor:

```gradle
dependencies {
    compileOnly 'org.projectlombok:lombok:1.18.30'
    annotationProcessor 'org.projectlombok:lombok:1.18.30'
}
```

---

## Key Constraints

- **Never use `@EqualsAndHashCode` on JPA entities** with relationships — causes circular comparison issues.
- **Combine `@Builder` with `@Data`** — builder alone does not generate accessors.
- **Use `@RequiredArgsConstructor` for Spring beans** — not `@Autowired` on fields.
- **Do not use `@EqualsAndHashCode` or `@ToString` on large collections** — can cause performance issues.

---

**Related:** [Spring Boot](languages/java.md) | [Clean Architecture](clean-architecture.md)
