# Workflow Gates

Copilot follows explicit workflow gates and sequencing rules in the orchestrator.

## Mandatory Gates

1. Step 0 pre-run log gate.
   - Before Step 1, `visual-log` must ensure `logs/logs.md` exists and is a valid JSON array.
2. Step 5 security-validation gate.
   - Step 5 is skipped by default unless explicitly re-enabled by workflow policy.
   - If re-enabled, validation runs through `verifier` using approved security commands.
3. Step 2 completion gate before implementation.
   - Copilot must not implement code before Step 2 technical design is complete.
4. Step 7 completion gate for parallel closing steps.
   - Step 8 and Step 9 can only start after Step 7 is marked successful.
   - Step 8 and Step 9 run in true parallel through separate delegations.
5. Destructive or ambiguous operations.
   - Copilot pauses for explicit confirmation before destructive or ambiguous actions.
6. Java version ambiguity gate.
   - If Java detection output is ambiguous, Copilot must ask for explicit version confirmation.

## Checklist Visibility

When a feature workflow starts, Copilot continuously shows a full checklist with one status per step.

Status icons:

1. ✅ completed
2. 🔄 in-progress
3. ⏳ pending
4. ❌ failed or blocker
5. ⏭ skipped

Copilot also provides short progress updates while it works, then summarizes what changed, what passed, and what remains.

## Next

Continue to [Command Behavior](command-behavior.md).