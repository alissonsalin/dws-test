---
applyTo: "{.github/copilot-instructions.md,.github/agents/*.agent.md,docs/flow/**/*.md,documentation/**/*.md}"
description: "Use when presenting feature workflow progress to enforce a full Step 1 to Step 9 checklist with icon-based statuses."
---

# Workflow Status Checklist Rules

- At the start of each workflow step, print the full Step 1 to Step 9 checklist.
- Keep one status per step line using this format:
  - <icon> Step N - <step name> [<status>]
- Use these status values only:
  - pending
  - in-progress
  - completed
  - failed
  - skipped
- Use this icon mapping:
  - completed -> ✅
  - in-progress -> 🔄
  - pending -> ⏳
  - failed -> ❌
  - skipped -> ⏭
- Keep the status text and icon aligned at all times.
- Update statuses as the workflow advances and keep completed steps visible.

# Reference Checklist Template

- ⏳ Step 1 - Identify Feature Details [pending]
- ⏳ Step 2 - Create Technical Design [pending]
- ⏳ Step 3 - Create User Stories [pending]
- ⏳ Step 4 - Start Implementation [pending]
- ⏳ Step 5 - Security Validation [pending]
- ⏳ Step 6 - Create Unit Tests [pending]
- ⏳ Step 7 - Compare and Adjust [pending]
- ⏳ Step 8 - Troubleshooting and Debugging [pending]
- ⏳ Step 9 - Continuous Improvement [pending]
