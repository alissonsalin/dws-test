---
applyTo: "{docs,documentation}/**/*.md"
description: "Use when editing documentation pages to keep content clear, structured, and consistent."
---

# Documentation Authoring Rules

- Write in clear, direct English using short paragraphs.
- Prefer task-oriented sections: Purpose, Steps, Example, Notes.
- Keep headings concise and consistent across pages.
- When listing procedures, use numbered lists with actionable verbs.
- Keep examples runnable and realistic.
- Avoid vague wording; state assumptions and constraints explicitly.
- Update navigation references when pages are added, moved, or renamed.
- Preserve existing terminology and naming used in the project.

# Markdown and Diagram Rules

- Use fenced code blocks with language tags.
- When producing a technical design document as part of the Step 2 workflow, always include both diagrams — this is mandatory, not optional:
  - ASCII component diagram inside a fenced Markdown code block, boxes labeled by module or layer, arrows showing data flow direction.
  - Mermaid component diagram inside a fenced `mermaid` code block representing the same architecture.
- For all other documentation pages, use Mermaid only when the user explicitly asks for it or when an applicable workflow instruction explicitly requires it.
- Keep diagrams simple and readable; avoid unnecessary nodes.
- Keep line lengths reasonable for source readability.

# Technical Design Template Rules

- Use a template for the technical design document that includes:
	- Requirement Summary
	- Technical Design (architecture, data flow, validation rules, database schema)
	- Impact and Risk Assessment:
	  - Performance impact analysis (latency, throughput, resource usage, caching impact, bottlenecks)
	  - Internal feature impact check (which existing features may be affected and regression checks)
	  - External dependency check (external projects/services this feature depends on and failure behavior)
	  - External impact check (how this feature can impact external projects/services, limits, and mitigations)
- Use ASCIIDOC or Markdown for structured documentation.
- For architecture/data flow diagrams, use ASCII boxes and arrows by default.
- Label each box with the module or layer name.
- Use arrows to indicate direction of data flow between modules or layers.

# Quality Checks Before Finalizing

- Confirm links and file names are correct.
- Ensure there are no contradictory instructions on the same page.
- For Java clean architecture docs, verify repository/gateway placement is consistent with implementation: `Repository` interface in `usecase`, implementation in `gateway`.
- Verify the page can be understood by a new team member.
