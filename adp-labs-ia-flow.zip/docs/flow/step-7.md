# Step 7: Compare & Adjust

## Purpose

Before declaring the feature complete, you must validate that the implementation actually solves the original problem and matches the design decisions. This step catches misalignments early and ensures the feature is ready for production.

## Why This Step Matters

Implementation drift happens when:
- Requirements change mid-development but aren't communicated
- Design decisions are interpreted differently than intended
- Edge cases discovered during implementation aren't reflected in design
- Performance or scalability assumptions prove incorrect

Comparing and adjusting:
- Ensures the feature meets all original requirements
- Catches design flaws before they're deployed
- Gives stakeholders confidence the feature is what they asked for
- Identifies improvements or simplifications

## What You'll Do

1. **Compare Against Original Requirements**:
   - Review the requirements summary from Step 1
   - Verify every requirement is implemented
   - Check that no features were added beyond scope
   - Confirm success criteria will be met

2. **Compare Against Technical Design**:
   - Verify the architecture matches the design (layers, separation of concerns)
   - Check that components interact as designed
   - Confirm data flows follow the architecture diagram
   - Verify performance and scalability assumptions hold

3. **Identify Gaps**:
   - Are there missing features or acceptance criteria not yet implemented?
   - Are there design decisions that don't match the implementation?
   - Are there untested edge cases or error scenarios?
   - Are there performance concerns or scalability issues?

4. **Suggest Adjustments**:
   - For missing features: prioritize and add to implementation
   - For design mismatches: either adjust implementation or update design (with stakeholder approval)
   - For performance issues: optimize code or reconsider approach
   - For testability gaps: add or improve tests

5. **Get Sign-Off**:
   - Present findings to stakeholders
   - Describe any gaps or adjustments made
   - Confirm stakeholder agreement before proceeding

## Example Comparison Checklist

```markdown
## Requirement vs. Implementation Comparison

### From Step 1: Originally Required
- [ ] Users can login with email and password
- [ ] Invalid credentials show error message
- [ ] User session persists for 24 hours
- [ ] Failed login attempts are rate-limited

### From Step 2: Technical Design
- [ ] Authentication module receives credentials via REST API
- [ ] Credentials validated against User entity in domain layer
- [ ] Session tokens generated and stored securely
- [ ] Rate limiting enforced at adapter layer

### From Step 4: Implementation Verification
- [x] REST endpoint implemented at /api/login
- [x] Validation logic in LoginUseCase
- [x] Session stored in database with expiration
- [ ] Rate limiting not yet implemented (ISSUE: requires Redis)
- [x] Error messages display properly in tests
- [x] All paths have >95% test coverage

### Gaps and Adjustments Needed
- Rate limiting requires Redis dependency (not in original estimate)
- Scope decision: Is rate limiting critical for MVP?
- If yes: Add to implementation and update timeline
- If no: Document as future enhancement
```

## Output

A comparison report showing:
- All requirements are implemented or explicitly deferred
- Implementation matches technical design
- Any gaps or adjustments made and justified
- Stakeholder sign-off on findings

## When To Proceed

Before moving to Step 8:
- All original requirements are met
- Implementation aligns with design
- Any gaps are understood and either fixed or formally deferred
- Stakeholders confirm the feature is ready for production

---

**Previous Step:** [Step 6 - Create Unit Tests](step-6.md)  
**Next Step:** [Step 8 - Troubleshooting & Debugging](step-8.md)
