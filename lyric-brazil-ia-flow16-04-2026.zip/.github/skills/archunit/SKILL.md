---
name: archunit
description: "Create or update ArchUnit tests for clean architecture boundaries in Java projects. Use when Java feature changes affect domain, usecase, adapter, or gateway dependencies."
argument-hint: "Provide package root and changed layer(s), or point to existing architecture test file"
---

# ArchUnit Layer Boundaries

## When to Use

- Java feature changes affect clean architecture layer boundaries.
- Architecture tests are missing or outdated.
- You need explicit `@ArchTest` rules for dependency constraints.

## Required Layer Rules

- `domain` must not depend on `usecase`, `adapter`, or `gateway`.
- `usecase` must not depend on `adapter` or `gateway`.
- `adapter` must not depend on `gateway`.
- `gateway` is outermost and may depend inward.

## Procedure

1. Locate or create architecture test class in `src/test/java/<root>/architecture/`.
2. Use a clear class name (for example `CleanArchitectureArchUnitTest`).
3. Add at least one `@ArchTest` rule per boundary.
4. Keep rule names explicit and aligned with the corresponding architecture constraint.
5. Ensure tests run in standard test execution.

## Minimal Rule Pattern

```java
@AnalyzeClasses(packages = "org.example", importOptions = ImportOption.DoNotIncludeTests.class)
class CleanArchitectureArchUnitTest {

    @ArchTest
    static final ArchRule domainShouldNotDependOnOuterLayers = noClasses()
            .that().resideInAPackage("..domain..")
            .should().dependOnClassesThat().resideInAnyPackage("..usecase..", "..adapter..", "..gateway..");
}
```

Adapt package names and add remaining boundary rules for full coverage.

## Edge Cases

- If a target layer does not exist yet, enforce existing boundaries and document missing-layer rationale.
- If a rule must be temporarily relaxed, document reason and remediation plan.
