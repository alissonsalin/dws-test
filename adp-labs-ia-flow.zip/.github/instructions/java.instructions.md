---
applyTo: "**/*.{java,kt,gradle,kts,yml,yaml}"
description: "Use when implementing Java features with clean architecture and Spring Boot conventions for this project."
---

# Java Implementation Rules

- Follow clean architecture boundaries: domain, usecase, adapter, gateway.
- Keep business logic in use cases and domain, not controllers.
- Keep controllers focused on input/output mapping and delegation.
- Use the feature entity name as a class-name prefix for Java classes in `gateway`, controller/adapter, and `usecase` layers.
  - Examples for entity `Client`: `ClientController`, `ClientRepository`, `ClientGateway`, `RegisterClientUseCase`, `ClientCommand`, `ClientResponse`.
  - Use `Repository` for the business-facing interface and `Gateway` for the concrete outer-layer implementation.
  - Keep `Repository` interfaces in `usecase` boundary packages.
  - Keep `Gateway` implementations in `gateway` packages.
  - Do not create generic names like `Controller`, `Repository`, `Gateway`, `UseCase`, or names ending with `Impl` without the entity prefix.
  - Do not use implementation names with technology-specific prefixes or suffixes such as `JdbcClientGateway`, `ClientGatewayJdbc`, `JpaClientGateway`, or `RestClientGateway`.
- Standardize a reusable command-response mapping pattern for controller-to-usecase boundaries to reduce duplicate mapping code.
- Introduce shared validation helpers in the `usecase` package for common API field checks and consistent validation errors.
- Use constructor-based dependency injection.
- Use Java 21 or superior language level.
- For Java entity and DTO classes, follow `.github/instructions/lombok.instructions.md` for Lombok annotations. Lombok is mandatory for all DTOs, entities, commands, and responses if Lombok is present in the project. Do not use Java `record` classes for these types.
- For Java domain POJOs/value objects, also apply Lombok conventions from `.github/instructions/lombok.instructions.md` when Lombok is present in the project.
- Follow `.github/instructions/spring.instructions.md` for Spring Boot framework conventions, REST structure, and required Spring YAML configuration files.
- Follow `.github/instructions/archunit.instructions.md` for Java architecture test requirements that enforce `domain`, `usecase`, `adapter`, and `gateway` boundaries.
- Follow the repository command-line instruction file for Java environment inspection and command timing.
  - Run the OS-specific Java detection command exactly once at the start of Step 4 implementation for each Java feature implementation workflow.
  - Do not run the Java detection command again later in the same workflow unless the user explicitly requests it.
  - Parse the detected Java major version from the environment inspection command output.
  - If the detected major version is 21 or higher, configure the project Java version to that detected major version.
  - If the detected major version is lower than 21, update the `sourceCompatibility` and `targetCompatibility` in `build.gradle` to 21 after confirmation.
  - If output parsing fails or is ambiguous, ask for explicit version confirmation instead of assuming a value.
  - If the Java version is updated, also ensure that relevant dependencies and plugins remain compatible.
  - Use the same Java version for both compilation and runtime to avoid compatibility issues.
- Prefer immutable domain models and builder patterns where helpful.

# Reliability and Security

- Validate and sanitize inputs at boundaries.
- Do not expose sensitive data in logs.
- Prefer resilient integration patterns for external dependencies.
- Enforce payload size limits for write endpoints.
- Implement request rate limiting for write endpoints only when the user explicitly requests it or the approved requirements/design call for it. When applied, document threshold values in API behavior notes.
- Implement payload and optional rate protections using reusable configuration components (for example, shared filters/interceptors/configuration classes) instead of duplicating endpoint-level logic.
- Add or update tests for success and failure paths when behavior changes.
