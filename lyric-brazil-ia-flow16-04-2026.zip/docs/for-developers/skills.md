# Skills

## Purpose

This page documents the on-demand skills used in this repository. Skills are loaded only for specialized tasks so they do not consume context in every session.

## When To Use Skills

Use a skill when you need:

- a focused workflow for a narrow task
- reusable guidance that stays opt-in
- specialized remediation, validation, or test patterns
- support material that complements agents and instructions instead of replacing them

## Skills in This Repository

### `.github/skills/cli-resilience/SKILL.md`

- Preflight checks, fix-driven retries, and concise failure capture for command recovery workflows.

### `.github/skills/archunit/SKILL.md`

- ArchUnit layer-boundary rules, test placement, and timing for Java architecture tests.

### `.github/skills/java/SKILL.md`

- Java implementation baseline: package structure, naming, repository and gateway placement, Java 21+ conventions.

### `.github/skills/nodejs/SKILL.md`

- Node.js clean architecture structure, routing boundaries, and runtime quality rules.

### `.github/skills/python/SKILL.md`

- Python clean architecture structure, validation boundaries, and testing expectations.

### `.github/skills/spring/SKILL.md`

- Spring Boot controller, configuration, bean wiring, and YAML profile conventions.

### `.github/skills/lombok/SKILL.md`

- Lombok DTO, entity, command, and `@Builder` patterns. Requires adding Lombok to Gradle if missing.

### `.github/skills/java-cli/SKILL.md`

- Java version detection, Gradle Wrapper preference, and Step 4 Lombok/OWASP build checks.

### `.github/skills/jacoco/SKILL.md`

- JaCoCo coverage setup, Gradle verification wiring, and report expectations for Java projects.

### `.github/skills/openapi/SKILL.md`

- Annotation-driven OpenAPI/Swagger contract guidance for public HTTP APIs.

### `.github/skills/node-python-cli/SKILL.md`

- Node.js and Python command preflight checks and fix-driven retries.

## Relationship To Other Customizations

1. Skills are not always-on; they are loaded only when the task calls for them.
2. Agents orchestrate workflows, while skills support specialized sub-workflows.
3. Instructions remain the source of truth for scoped, automatically applied rules.
4. This repository intentionally moves language-specific, framework-specific, and runtime-specific development guidance into skills to reduce default chat context.

## Selection Guidance

- Use instructions for broad, file-pattern-based rules.
- Use agents for multi-step workflow execution.
- Use skills for narrow, reusable expertise that stays opt-in.
- Prefer a skill over an instruction when the guidance is only needed after implementation starts.

## Related References

- [Custom Instructions](custom-instructions.md)
- [Agents](agents.md)
- [Arch Unit](../technologies/arch-unit.md)
- [Unit test](unit-test.md)