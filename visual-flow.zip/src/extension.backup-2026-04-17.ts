import * as vscode from "vscode";
import { randomUUID } from "node:crypto";
import * as path from "node:path";
import { exec } from "node:child_process";
import { promisify } from "node:util";
import { access } from "node:fs/promises";

const execAsync = promisify(exec);

const STEP_TITLES: Record<number, string> = {
  1: "Identify Feature Details",
  2: "Technical Design",
  3: "Create User Stories",
  4: "Implementation",
  5: "Security Validation",
  6: "Lint, Test Verification and Coverage",
  7: "Compare and Adjust",
  8: "Troubleshooting and Debugging",
  9: "Continuous Improvement"
};

const STEP_OWNERS: Record<number, string> = {
  1: "planner",
  2: "planner",
  3: "planner",
  4: "coder",
  5: "verifier",
  6: "verifier",
  7: "planner",
  8: "planner",
  9: "planner"
};

const AVAILABLE_AGENTS = [
  "flow-orchestrator",
  "jira-feature-intake",
  "planner",
  "coder",
  "verifier",
  "diagnostics",
  "tech-refresh",
  "tech-refresh-orchestrator"
];

const JIRA_FEATURE_AGENT = "jira-feature-intake";
const JIRA_FIXED_FEATURE_ID = "LRA-1234";
const JIRA_SAMPLE_REQUEST =
  "Return exactly 10 Jira samples as JSON only with id, title, and description fields.";
interface FeatureOption {
  value: string;
  label: string;
  description: string;
}

const DEFAULT_FEATURE_OPTIONS: FeatureOption[] = [
  {
    value: JIRA_FIXED_FEATURE_ID,
    label: `${JIRA_FIXED_FEATURE_ID} - Save Person Data Endpoint`,
    description:
      "Create a endpoint to server users to save person data like name, age, and email. The endpoint should accept POST requests with a JSON body containing the person's information. The server should validate the input data and return a success message if the data is valid, or an error message if the data is invalid. Additionally, the server should store the person data in a database for future retrieval."
  }
];

const CLI_COMMAND_TEMPLATE_SETTING = "copilotCli.commandTemplate";
const CLI_TERMINAL_NAME_SETTING = "copilotCli.terminalName";

type RunStatus = "running" | "completed" | "failed";
type StepStatus = "pending" | "running" | "completed" | "failed" | "skipped";

type VisualFlowEventType =
  | "run.started"
  | "run.completed"
  | "step.started"
  | "step.completed"
  | "step.failed"
  | "step.fix_applied"
  | "step.skipped"
  | "delegation.sent"
  | "compare.gap_found";

interface VisualFlowEvent {
  type: VisualFlowEventType;
  runId?: string;
  step?: number;
  owner?: string;
  message?: string;
  timestamp: string;
  payload?: Record<string, unknown>;
}

interface StepState {
  step: number;
  title: string;
  owner: string;
  status: StepStatus;
  details: string;
  updatedAt: string;
}

interface RunState {
  runId: string;
  featureName: string;
  instruction: string;
  selectedAgent: string;
  destinationPath: string;
  status: RunStatus;
  startedAt: string;
  completedAt?: string;
  steps: StepState[];
  events: VisualFlowEvent[];
  source?: string;
}

function isTerminalStepStatus(status: StepStatus): boolean {
  return status === "completed" || status === "failed" || status === "skipped";
}

interface StartRunRequest {
  featureName: string;
  selectedAgent: string;
  instruction: string;
}

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function toJsonLine(event: VisualFlowEvent): string {
  return JSON.stringify(event) + "\n";
}

function formatFeatureDescription(feature: FeatureOption | undefined): string {
  if (!feature) {
    return "";
  }

  return feature.description ? `${feature.label}\n\n${feature.description}` : feature.label;
}

class FlowStore implements vscode.Disposable {
  private runState: RunState | undefined;
  private readonly emitter = new vscode.EventEmitter<RunState | undefined>();
  private eventFileWatcher: vscode.FileSystemWatcher | undefined;

  public readonly onDidChange = this.emitter.event;

  public getState(): RunState | undefined {
    return this.runState;
  }

  public startRun(
    featureName: string,
    instruction: string,
    selectedAgent: string,
    destinationPath: string,
    runId?: string
  ): RunState {
    const now = new Date().toISOString();
    const resolvedRunId = runId ?? randomUUID();

    this.runState = {
      runId: resolvedRunId,
      featureName,
      instruction,
      selectedAgent,
      destinationPath,
      status: "running",
      startedAt: now,
      steps: this.createDefaultSteps(),
      events: []
    };

    this.appendEvent({
      type: "run.started",
      runId: resolvedRunId,
      message: "Run started",
      timestamp: now,
      payload: {
        featureName,
        instruction,
        selectedAgent,
        destinationPath
      }
    });

    return this.runState;
  }

  public appendEvent(event: VisualFlowEvent): void {
    this.ensureRun(event);
    if (!this.runState) {
      return;
    }

    const normalizedEvent: VisualFlowEvent = {
      ...event,
      runId: event.runId ?? this.runState.runId,
      timestamp: event.timestamp ?? new Date().toISOString()
    };

    this.runState.events.push(normalizedEvent);
    this.applyEventToState(normalizedEvent);
    this.emitter.fire(this.runState);
  }

  public loadEventStream(events: VisualFlowEvent[], source?: string): void {
    if (events.length === 0) {
      const state = this.getState();
      if (state && source) {
        state.source = source;
        this.emitter.fire(state);
      }
      return;
    }

    this.runState = undefined;

    for (const event of events) {
      this.appendEvent(event);
    }

    const state = this.getState();
    if (state && source) {
      state.source = source;
      this.emitter.fire(state);
    }
  }

  public async attachEventFile(uri: vscode.Uri): Promise<void> {
    const workspaceFolder = vscode.workspace.getWorkspaceFolder(uri);
    if (!workspaceFolder) {
      throw new Error("Event file must be inside an open workspace folder.");
    }

    const relativePath = path.relative(workspaceFolder.uri.fsPath, uri.fsPath).replace(/\\/g, "/");

    this.eventFileWatcher?.dispose();
    this.eventFileWatcher = vscode.workspace.createFileSystemWatcher(
      new vscode.RelativePattern(workspaceFolder, relativePath)
    );

    const reload = async (): Promise<void> => {
      const events = await this.readEventsFromFile(uri);
      this.loadEventStream(events, relativePath);
    };

    this.eventFileWatcher.onDidChange(() => {
      void reload();
    });

    this.eventFileWatcher.onDidCreate(() => {
      void reload();
    });

    await reload();
  }

  public dispose(): void {
    this.eventFileWatcher?.dispose();
    this.emitter.dispose();
  }

  private ensureRun(event: VisualFlowEvent): void {
    if (this.runState) {
      return;
    }

    const now = event.timestamp ?? new Date().toISOString();
    const fallbackFeatureName = String(event.payload?.featureName ?? "Imported Run");
    const fallbackInstruction = String(event.payload?.instruction ?? "");
    const fallbackSelectedAgent = String(event.payload?.selectedAgent ?? "flow-orchestrator");
    const fallbackDestinationPath = String(event.payload?.destinationPath ?? "");

    this.runState = {
      runId: event.runId ?? randomUUID(),
      featureName: fallbackFeatureName,
      instruction: fallbackInstruction,
      selectedAgent: fallbackSelectedAgent,
      destinationPath: fallbackDestinationPath,
      status: "running",
      startedAt: now,
      steps: this.createDefaultSteps(),
      events: []
    };
  }

  private createDefaultSteps(): StepState[] {
    return Object.keys(STEP_TITLES).map((key) => {
      const step = Number(key);
      return {
        step,
        title: STEP_TITLES[step],
        owner: STEP_OWNERS[step],
        status: step === 1 ? "running" : "pending",
        details: step === 1 ? "Automatically moved to in progress" : "",
        updatedAt: step === 1 ? new Date().toISOString() : ""
      };
    });
  }

  private getStep(stepNumber: number): StepState | undefined {
    return this.runState?.steps.find((value) => value.step === stepNumber);
  }

  private canStartStep(stepNumber: number): boolean {
    if (!this.runState) {
      return false;
    }

    const step1 = this.getStep(1);
    const step2 = this.getStep(2);
    const step3 = this.getStep(3);
    const step4 = this.getStep(4);
    const step5 = this.getStep(5);
    const step6 = this.getStep(6);
    const step7 = this.getStep(7);

    switch (stepNumber) {
      case 1:
        return true;
      case 2:
      case 3:
        return step1?.status === "completed";
      case 4:
        return step2?.status === "completed" && step3?.status === "completed";
      case 5:
        return step4?.status === "completed";
      case 6:
        return step4?.status === "completed" && !!step5 && isTerminalStepStatus(step5.status);
      case 7:
        return step6?.status === "completed";
      case 8:
      case 9:
        return step7?.status === "completed";
      default:
        return false;
    }
  }

  private canCompleteRun(): boolean {
    if (!this.runState) {
      return false;
    }

    return this.runState.steps.every((step) => isTerminalStepStatus(step.status));
  }

  private applyEventToState(event: VisualFlowEvent): void {
    if (!this.runState) {
      return;
    }

    switch (event.type) {
      case "run.started": {
        this.runState.status = "running";
        this.runState.startedAt = event.timestamp;
        if (typeof event.payload?.featureName === "string") {
          this.runState.featureName = event.payload.featureName;
        }
        if (typeof event.payload?.instruction === "string") {
          this.runState.instruction = event.payload.instruction;
        }
        if (typeof event.payload?.selectedAgent === "string") {
          this.runState.selectedAgent = event.payload.selectedAgent;
        }
        if (typeof event.payload?.destinationPath === "string") {
          this.runState.destinationPath = event.payload.destinationPath;
        }
        break;
      }
      case "run.completed": {
        if (!this.canCompleteRun()) {
          break;
        }

        this.runState.status = "completed";
        this.runState.completedAt = event.timestamp;
        break;
      }
      case "step.started":
      case "step.completed":
      case "step.failed":
      case "step.fix_applied":
      case "step.skipped": {
        if (!event.step || event.step < 1 || event.step > 9) {
          break;
        }

        const step = this.runState.steps.find((value) => value.step === event.step);
        if (!step) {
          break;
        }

        if ((event.type === "step.started" || event.type === "step.fix_applied") && !this.canStartStep(event.step)) {
          break;
        }

        if (event.owner && STEP_OWNERS[event.step] && event.owner !== STEP_OWNERS[event.step]) {
          break;
        }

        if (event.type === "step.skipped" && event.step !== 5 && !this.canStartStep(event.step)) {
          break;
        }

        if (event.type === "step.completed" && step.status === "pending" && !this.canStartStep(event.step)) {
          break;
        }

        if (event.type === "step.failed" && step.status === "pending" && !this.canStartStep(event.step)) {
          break;
        }

        if (event.type === "step.started") {
          step.status = "running";
        } else if (event.type === "step.completed") {
          step.status = "completed";
        } else if (event.type === "step.failed") {
          step.status = "failed";
          this.runState.status = "failed";
        } else if (event.type === "step.fix_applied") {
          step.status = "running";
          this.runState.status = "running";
        } else {
          step.status = "skipped";
        }

        step.owner = event.owner ?? step.owner;
        step.details = event.message ?? step.details;
        step.updatedAt = event.timestamp;
        break;
      }
      case "delegation.sent": {
        if (!event.step || event.step < 1 || event.step > 9) {
          break;
        }

        const step = this.runState.steps.find((value) => value.step === event.step);
        if (!step) {
          break;
        }

        if (!this.canStartStep(event.step)) {
          break;
        }

        if (event.owner && STEP_OWNERS[event.step] && event.owner !== STEP_OWNERS[event.step]) {
          break;
        }

        step.status = "running";
        step.owner = event.owner ?? step.owner;
        step.details = event.message ?? "Delegated";
        step.updatedAt = event.timestamp;
        break;
      }
      case "compare.gap_found": {
        const step = this.runState.steps.find((value) => value.step === 7);
        if (!step) {
          break;
        }

        step.status = "failed";
        step.details = event.message ?? "Gap found, returning to implementation";
        step.updatedAt = event.timestamp;
        this.runState.status = "failed";
        break;
      }
      default:
        break;
    }
  }

  private async readEventsFromFile(uri: vscode.Uri): Promise<VisualFlowEvent[]> {
    const bytes = await vscode.workspace.fs.readFile(uri);
    const content = Buffer.from(bytes).toString("utf8");
    const lines = content
      .split(/\r?\n/g)
      .map((line) => line.trim())
      .filter((line) => line.length > 0);

    const events: VisualFlowEvent[] = [];

    for (const line of lines) {
      try {
        const candidate = JSON.parse(line) as Partial<VisualFlowEvent>;
        if (typeof candidate.type !== "string") {
          continue;
        }

        const event: VisualFlowEvent = {
          type: candidate.type as VisualFlowEventType,
          runId: candidate.runId,
          step: candidate.step,
          owner: candidate.owner,
          message: candidate.message,
          timestamp: candidate.timestamp ?? new Date().toISOString(),
          payload: candidate.payload
        };

        events.push(event);
      } catch {
        // Ignore malformed lines to keep live tracking resilient.
      }
    }

    return events;
  }
}

class DashboardController implements vscode.Disposable {
  private panel: vscode.WebviewPanel | undefined;
  private readonly subscriptions: vscode.Disposable[] = [];
  private featureOptions: FeatureOption[] = [...DEFAULT_FEATURE_OPTIONS];
  private featureLoadMessage = "Loading Jira sample features...";
  private featureLoading = true;
  private webviewReady = false;

  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly store: FlowStore,
    private readonly onStartRunRequest: (request: StartRunRequest) => Promise<void>,
    private readonly onLoadJiraFeaturesRequest: () => Promise<void>,
    private readonly log: (message: string, details?: unknown) => void
  ) {
    this.subscriptions.push(
      this.store.onDidChange((state) => {
        this.postState(state);
      })
    );
  }

  public open(): void {
    this.log("Dashboard open requested", {
      hasPanel: !!this.panel,
      featureOptionsCount: this.featureOptions.length,
      featureLoading: this.featureLoading
    });

    if (this.panel) {
      this.panel.reveal(vscode.ViewColumn.One);
      this.syncWebview();
      void this.onLoadJiraFeaturesRequest();
      return;
    }

    this.panel = vscode.window.createWebviewPanel(
      "visualFlowDashboard",
      "Visual Flow Dashboard",
      vscode.ViewColumn.One,
      {
        enableScripts: true,
        retainContextWhenHidden: true
      }
    );

    this.panel.onDidDispose(() => {
      this.panel = undefined;
      this.webviewReady = false;
    });

    this.panel.webview.onDidReceiveMessage(async (message) => {
      if (!message || typeof message.type !== "string") {
        return;
      }

      if (message.type === "startRunFromUi") {
        const payload = message.payload as Partial<StartRunRequest>;
        const request: StartRunRequest = {
          featureName: String(payload.featureName ?? "").trim(),
          selectedAgent: String(payload.selectedAgent ?? "").trim(),
          instruction: String(payload.instruction ?? "").trim()
        };

        this.log("Received startRunFromUi message", request);
        await this.onStartRunRequest(request);
        return;
      }

      if (message.type === "webviewReady") {
        this.webviewReady = true;
        this.log("Webview ready message received");
        this.syncWebview();
        return;
      }

      if (message.type === "debugLog") {
        this.log("Webview debug", message.payload);
        return;
      }

    });

    this.webviewReady = false;
    this.panel.webview.html = this.getHtml(this.panel.webview);
    void this.onLoadJiraFeaturesRequest();
  }

  public dispose(): void {
    for (const subscription of this.subscriptions) {
      subscription.dispose();
    }

    this.panel?.dispose();
  }

  private postState(state: RunState | undefined): void {
    if (!this.panel || !this.webviewReady) {
      return;
    }

    void this.panel.webview.postMessage({
      type: "state",
      state
    });
  }

  public setFeatureOptions(featureOptions: FeatureOption[]): void {
    this.featureOptions = featureOptions.length > 0 ? featureOptions : [...DEFAULT_FEATURE_OPTIONS];

    this.log("Setting feature options", {
      count: this.featureOptions.length,
      firstFeature: this.featureOptions[0]?.label ?? ""
    });

    this.postFeatureOptions();
    this.postFeatureLoadingState();
    this.postState(this.store.getState());
  }

  public setFeatureLoadingState(loading: boolean, message: string): void {
    this.featureLoading = loading;
    this.featureLoadMessage = message;
    this.log("Updating feature loading state", { loading, message });
    this.postFeatureLoadingState();
  }

  private postFeatureOptions(): void {
    if (!this.panel || !this.webviewReady) {
      return;
    }

    void this.panel.webview.postMessage({
      type: "featureOptions",
      featureOptions: this.featureOptions
    });
  }

  private postFeatureLoadingState(): void {
    if (!this.panel || !this.webviewReady) {
      return;
    }

    void this.panel.webview.postMessage({
      type: "featureLoadingState",
      loading: this.featureLoading,
      message: this.featureLoadMessage
    });
  }

  private syncWebview(): void {
    this.postFeatureLoadingState();
    this.postFeatureOptions();
    this.postState(this.store.getState());
  }

  private getHtml(webview: vscode.Webview): string {
    const nonce = randomUUID();
    const featureFieldLabel = this.featureLoading ? "Loading features" : "Feature name";
    const featureStatusClass = this.featureLoading
      ? "loading"
      : this.featureLoadMessage && this.featureLoadMessage.startsWith("Failed")
        ? "error"
        : "ready";
    const initialFeatureLoading = JSON.stringify(this.featureLoading);
    const featureOptionsPayload = JSON.stringify(this.featureOptions);
    const agentOptionsHtml = AVAILABLE_AGENTS.map((agent) => {
      const selected = agent === AVAILABLE_AGENTS[0] ? ' selected="selected"' : "";
      return `<option value="${agent}"${selected}>${agent}</option>`;
    }).join("");
    const selectedFeatureDescription = formatFeatureDescription(this.featureOptions[0]);
    const featureOptionsHtml = this.featureOptions.map((feature, index) => {
      const selected = index === 0 ? ' selected="selected"' : "";
      return `<option value="${escapeHtml(feature.value)}" data-label="${escapeHtml(feature.label)}" data-description="${escapeHtml(feature.description)}"${selected}>${escapeHtml(feature.label)}</option>`;
    }).join("");

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}';" />
  <title>Visual Flow Dashboard</title>
  <style>
    :root {
      color-scheme: light dark;
      --bg: #101724;
      --panel: #162234;
      --border: #2a3b56;
      --text: #eaf1ff;
      --subtle: #a5b3cc;
      --ok: #3ccf91;
      --warn: #ffb84d;
      --err: #ff7070;
      --run: #59b0ff;
      --skip: #8d9db7;
    }

    body {
      margin: 0;
      padding: 16px;
      font-family: "Segoe UI", sans-serif;
      background: radial-gradient(circle at top right, #1f3a67, #101724 42%);
      color: var(--text);
    }

    .header {
      margin-bottom: 12px;
    }

    .title {
      font-size: 20px;
      font-weight: 600;
    }

    .subtitle {
      margin-top: 6px;
      color: var(--subtle);
      font-size: 12px;
    }

    .grid {
      display: grid;
      grid-template-columns: 1.1fr 1.4fr;
      gap: 12px;
    }

    .panel {
      border: 1px solid var(--border);
      border-radius: 12px;
      background: color-mix(in srgb, var(--panel) 92%, black 8%);
      padding: 12px;
      min-height: 180px;
    }

    .panel h2 {
      margin: 0 0 8px 0;
      font-size: 14px;
      font-weight: 600;
      letter-spacing: 0.02em;
      color: var(--subtle);
      text-transform: uppercase;
    }

    .form-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
      margin-bottom: 8px;
    }

    .form-field {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .form-field-full {
      grid-column: 1 / -1;
    }

    .label {
      font-size: 12px;
      color: var(--subtle);
    }

    .label-row {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .status-icon {
      width: 10px;
      height: 10px;
      border-radius: 999px;
      display: inline-block;
      flex: 0 0 auto;
      background: var(--subtle);
      box-shadow: 0 0 0 0 transparent;
    }

    .status-icon.loading {
      background: var(--warn);
      animation: pulse-status 1.2s ease-in-out infinite;
    }

    .status-icon.ready {
      background: var(--ok);
      box-shadow: 0 0 10px color-mix(in srgb, var(--ok) 55%, transparent);
    }

    .status-icon.error {
      background: var(--err);
      box-shadow: 0 0 10px color-mix(in srgb, var(--err) 45%, transparent);
    }

    @keyframes pulse-status {
      0% {
        transform: scale(0.9);
        box-shadow: 0 0 0 0 color-mix(in srgb, var(--warn) 45%, transparent);
      }

      70% {
        transform: scale(1);
        box-shadow: 0 0 0 8px color-mix(in srgb, var(--warn) 0%, transparent);
      }

      100% {
        transform: scale(0.9);
        box-shadow: 0 0 0 0 color-mix(in srgb, var(--warn) 0%, transparent);
      }
    }

    .input,
    .select,
    .textarea {
      width: 100%;
      box-sizing: border-box;
      border: 1px solid var(--border);
      border-radius: 8px;
      background: rgba(8, 14, 24, 0.6);
      color: var(--text);
      padding: 8px 10px;
      font: inherit;
      font-size: 12px;
    }

    .textarea {
      min-height: 90px;
      resize: vertical;
      line-height: 1.4;
    }

    .actions {
      display: flex;
      gap: 8px;
      margin-top: 8px;
      flex-wrap: wrap;
    }

    .helper-text {
      margin-top: 8px;
      color: var(--subtle);
      font-size: 12px;
      line-height: 1.4;
    }

    .status-row {
      margin-top: 8px;
      min-height: 18px;
      color: var(--subtle);
      font-size: 12px;
      line-height: 1.4;
    }

    .status-row.loading {
      color: var(--warn);
    }

    .status-row.ready {
      color: var(--ok);
    }

    .status-row.error {
      color: var(--err);
    }

    .select.loading {
      opacity: 0.65;
      cursor: wait;
    }

    .button {
      border: 1px solid var(--border);
      border-radius: 999px;
      padding: 7px 12px;
      background: rgba(89, 176, 255, 0.14);
      color: var(--text);
      cursor: pointer;
      font-size: 12px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }

    th,
    td {
      padding: 6px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      text-align: left;
      vertical-align: top;
    }

    .badge {
      border-radius: 999px;
      display: inline-block;
      min-width: 78px;
      text-align: center;
      padding: 3px 8px;
      font-size: 11px;
      text-transform: capitalize;
      border: 1px solid transparent;
    }

    .running {
      color: var(--run);
      border-color: color-mix(in srgb, var(--run) 60%, transparent);
      background: color-mix(in srgb, var(--run) 15%, transparent);
    }

    .completed {
      color: var(--ok);
      border-color: color-mix(in srgb, var(--ok) 65%, transparent);
      background: color-mix(in srgb, var(--ok) 15%, transparent);
    }

    .failed {
      color: var(--err);
      border-color: color-mix(in srgb, var(--err) 65%, transparent);
      background: color-mix(in srgb, var(--err) 15%, transparent);
    }

    .skipped {
      color: var(--skip);
      border-color: color-mix(in srgb, var(--skip) 65%, transparent);
      background: color-mix(in srgb, var(--skip) 15%, transparent);
    }

    .pending {
      color: var(--warn);
      border-color: color-mix(in srgb, var(--warn) 65%, transparent);
      background: color-mix(in srgb, var(--warn) 15%, transparent);
    }

    .timeline-item {
      border-left: 2px solid var(--border);
      padding-left: 10px;
      margin: 8px 0;
    }

    .timeline-meta {
      color: var(--subtle);
      font-size: 11px;
    }

    .empty {
      color: var(--subtle);
      font-size: 13px;
      margin-top: 18px;
    }

    @media (max-width: 950px) {
      .grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="title">Visual Flow Dashboard</div>
    <div class="subtitle" id="runMeta">No active run</div>
  </div>

  <section class="panel">
    <h2>Start Run</h2>
    <div class="form-grid">
      <div class="form-field">
        <div class="label-row">
          <span class="status-icon ${featureStatusClass}" id="featureLoadingIcon" aria-hidden="true"></span>
          <label class="label" id="featureNameLabel" for="featureNameSelect">${featureFieldLabel}</label>
        </div>
        <select id="featureNameSelect" class="select">${featureOptionsHtml}</select>
        <div class="status-row ${featureStatusClass}" id="featureLoadingStatus">${this.featureLoadMessage}</div>
      </div>

      <div class="form-field">
        <label class="label" for="agentSelect">Agent</label>
        <select id="agentSelect" class="select">${agentOptionsHtml}</select>
      </div>

      <div class="form-field form-field-full">
        <label class="label" for="featureDescriptionInput">Feature description</label>
        <textarea id="featureDescriptionInput" class="textarea" readonly>${escapeHtml(selectedFeatureDescription)}</textarea>
      </div>

      <div class="form-field form-field-full">
        <label class="label" for="instructionInput">Instruction (optional, auto-generated if empty)</label>
        <textarea id="instructionInput" class="textarea" placeholder="Use agent @flow-orchestrator ..."></textarea>
      </div>
    </div>

    <div class="actions">
      <button id="startRunBtn" class="button">Start Run</button>
    </div>

    <div class="helper-text" id="agentHelperText">Select an agent to prepare the feature input and prompt.</div>
  </section>

  <div class="grid">
    <section class="panel">
      <h2>Step Status</h2>
      <div id="steps"></div>
    </section>

    <section class="panel">
      <h2>Timeline</h2>
      <div id="timeline"></div>
    </section>
  </div>

  <script nonce="${nonce}">
    const vscodeApi = acquireVsCodeApi();
    const availableAgents = ${JSON.stringify(AVAILABLE_AGENTS)};
    const jiraFeatureAgent = ${JSON.stringify(JIRA_FEATURE_AGENT)};
    const jiraFixedFeatureId = ${JSON.stringify(JIRA_FIXED_FEATURE_ID)};
    let currentFeatureOptions = ${featureOptionsPayload};

    const runMeta = document.getElementById("runMeta");
    const steps = document.getElementById("steps");
    const timeline = document.getElementById("timeline");
    const featureNameLabel = document.getElementById("featureNameLabel");
    const featureNameSelect = document.getElementById("featureNameSelect");
    const featureDescriptionInput = document.getElementById("featureDescriptionInput");
    const agentSelect = document.getElementById("agentSelect");
    const instructionInput = document.getElementById("instructionInput");
    const startRunBtn = document.getElementById("startRunBtn");
    const agentHelperText = document.getElementById("agentHelperText");
    const featureLoadingStatus = document.getElementById("featureLoadingStatus");
    const featureLoadingIcon = document.getElementById("featureLoadingIcon");
    let isFeatureLoading = ${initialFeatureLoading};

    function debugLog(message, data) {
      vscodeApi.postMessage({
        type: "debugLog",
        payload: {
          message,
          data
        }
      });
    }

    vscodeApi.postMessage({
      type: "webviewReady"
    });

    window.addEventListener("error", (event) => {
      debugLog("webview error", {
        message: event.message || "",
        filename: event.filename || "",
        lineno: event.lineno || 0,
        colno: event.colno || 0
      });
    });

    window.addEventListener("unhandledrejection", (event) => {
      debugLog("webview unhandled rejection", {
        reason: String(event.reason || "")
      });
    });

    debugLog("webview booted", {
      initialOptionCount: featureNameSelect.options.length,
      initialSelectedValue: featureNameSelect.value,
      initialLoading: isFeatureLoading
    });

    if (availableAgents.length > 0) {
      agentSelect.value = availableAgents[0];
    }

    function getSelectedFeatureName() {
      return featureNameSelect.value;
    }

    function getSelectedFeatureOption() {
      const selectedOption = featureNameSelect.options[featureNameSelect.selectedIndex];
      if (selectedOption) {
        return {
          value: selectedOption.value,
          label: selectedOption.dataset.label || selectedOption.textContent || selectedOption.value,
          description: selectedOption.dataset.description || ""
        };
      }

      return (currentFeatureOptions || []).find((feature) => feature.value === featureNameSelect.value);
    }

    function updateFeatureDescriptionFromSelection() {
      const selectedFeature = getSelectedFeatureOption();
      featureDescriptionInput.value = selectedFeature
        ? (selectedFeature.description ? selectedFeature.label + "\n\n" + selectedFeature.description : selectedFeature.label)
        : "";
    }

    function syncFeatureDescriptionFromSelection() {
      updateFeatureDescriptionFromSelection();
    }

    function syncSelectedFeatureUi() {
      const selectedFeature = getSelectedFeatureOption();
      updateFeatureDescriptionFromSelection();
      agentHelperText.textContent = "Selected agent: " + agentSelect.value + " | feature: " + featureNameSelect.value;
      debugLog("syncSelectedFeatureUi", {
        selectedValue: featureNameSelect.value,
        selectedIndex: featureNameSelect.selectedIndex,
        selectedLabel: selectedFeature ? selectedFeature.label : "",
        descriptionPreview: selectedFeature ? selectedFeature.description.slice(0, 80) : "",
        optionCount: featureNameSelect.options.length,
        loading: isFeatureLoading
      });
    }

    function scheduleSelectedFeatureUiSync() {
      window.requestAnimationFrame(() => {
        syncSelectedFeatureUi();
      });
    }

    function applyFeatureOptions(featureOptions) {
      const selectedValue = featureNameSelect.value;
      currentFeatureOptions = Array.isArray(featureOptions) ? featureOptions : [];
      featureNameSelect.innerHTML = "";

      currentFeatureOptions.forEach((feature, index) => {
        const option = document.createElement("option");
        option.value = feature.value;
        option.textContent = feature.label;
        option.dataset.label = feature.label;
        option.dataset.description = feature.description || "";
        option.selected = feature.value === selectedValue || (index === 0 && !selectedValue);
        featureNameSelect.appendChild(option);
      });

      if (selectedValue && [...featureNameSelect.options].some((option) => option.value === selectedValue)) {
        featureNameSelect.value = selectedValue;
      } else if (featureNameSelect.options.length > 0) {
        featureNameSelect.selectedIndex = 0;
      }

      syncSelectedFeatureUi();
      debugLog("applyFeatureOptions", {
        selectedValue: featureNameSelect.value,
        optionCount: currentFeatureOptions.length,
        labels: currentFeatureOptions.map((feature) => feature.label)
      });
    }

    function setFeatureLoadingState(loading, message) {
      isFeatureLoading = !!loading;
      featureNameSelect.disabled = !!loading;
      if (!loading) {
        featureNameSelect.disabled = false;
      }
      featureNameSelect.classList.toggle("loading", !!loading);
      featureLoadingStatus.textContent = message || "";
      const statusClass = loading ? "loading" : (message && /^failed/i.test(message) ? "error" : "ready");
      featureNameLabel.textContent = loading ? "Loading features" : (statusClass === "error" ? "Feature load failed" : "Feature name");
      featureLoadingStatus.className = "status-row " + statusClass;
      featureLoadingIcon.className = "status-icon " + statusClass;
      debugLog("setFeatureLoadingState", { loading: !!loading, message, statusClass });
    }

    function syncAgentDefaults() {
      if (agentSelect.value !== jiraFeatureAgent) {
        agentHelperText.textContent = "Selected agent: " + agentSelect.value + " | feature: " + featureNameSelect.value;
        return;
      }

      syncSelectedFeatureUi();

      if (!instructionInput.value.trim()) {
        instructionInput.value =
          "Use agent @" + jiraFeatureAgent + " and ask for exactly 10 Jira samples as a JSON array with id, title, and description.";
      }
    }

    agentSelect.addEventListener("change", () => {
      debugLog("agent change", { selectedAgent: agentSelect.value });
      syncAgentDefaults();
    });

    featureNameSelect.addEventListener("change", () => {
      debugLog("feature change event", {
        selectedValue: featureNameSelect.value,
        selectedIndex: featureNameSelect.selectedIndex
      });
      scheduleSelectedFeatureUiSync();
    });

    syncAgentDefaults();

    startRunBtn.addEventListener("click", () => {
      vscodeApi.postMessage({
        type: "startRunFromUi",
        payload: {
          featureName: getSelectedFeatureName(),
          selectedAgent: agentSelect.value,
          instruction: instructionInput.value
        }
      });
    });

    function renderEmpty() {
      steps.innerHTML = '<div class="empty">Start a run or attach an event file.</div>';
      timeline.innerHTML = '<div class="empty">No events yet.</div>';
    }

    function formatStepStatusLabel(status) {
      if (status === "running") {
        return "in progress";
      }

      return String(status || "").replace("_", " ");
    }

    function formatAmericanDateTime(value) {
      if (!value) {
        return "-";
      }

      const date = new Date(value);
      if (Number.isNaN(date.getTime())) {
        return value;
      }

      return date
        .toLocaleString("en-US", {
          month: "2-digit",
          day: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: true
        })
        .replace(",", "");
    }

    function renderState(state) {
      if (!state) {
        runMeta.textContent = "No active run";
        renderEmpty();
        debugLog("renderState empty", {});
        return;
      }

      const sourcePart = state.source ? " | source: " + state.source : "";
      const agentPart = " | agent: " + (state.selectedAgent || "-");
      const destinationPart = state.destinationPath ? " | destination: " + state.destinationPath : "";
      runMeta.textContent =
        state.featureName + " | run " + state.runId + " | " + state.status + agentPart + destinationPart + sourcePart;

      if (state.selectedAgent) {
        agentSelect.value = state.selectedAgent;
      }

      if (state.featureName && !featureNameSelect.value) {
        if ([...featureNameSelect.options].some((option) => option.value === state.featureName)) {
          featureNameSelect.value = state.featureName;
        }
      }

      syncSelectedFeatureUi();
      debugLog("renderState", {
        stateFeatureName: state.featureName,
        selectedValue: featureNameSelect.value,
        selectedIndex: featureNameSelect.selectedIndex,
        selectedAgent: state.selectedAgent,
        status: state.status
      });

      instructionInput.value = state.instruction || instructionInput.value;
      syncAgentDefaults();

      const stepRows = state.steps
        .map((step) => {
          return (
            '<tr>' +
            '<td>' + step.step + '. ' + step.title + '</td>' +
            '<td><span class="badge ' + step.status + '">' + formatStepStatusLabel(step.status) + '</span></td>' +
            '<td>' + step.owner + '</td>' +
            '<td>' + (step.details || '-') + '</td>' +
            '</tr>'
          );
        })
        .join("");

      steps.innerHTML =
        '<table>' +
        '<thead>' +
        '<tr>' +
        '<th>Step</th>' +
        '<th>Status</th>' +
        '<th>Owner</th>' +
        '<th>Details</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        stepRows +
        '</tbody>' +
        '</table>';

      const lastEvents = [...state.events].reverse().slice(0, 30);
      timeline.innerHTML = lastEvents
        .map((event) => {
          const message = event.message || "";
          const step = event.step ? "step " + event.step : "run";
          const ownerPart = event.owner ? " | " + event.owner : "";
          return (
            '<div class="timeline-item">' +
            '<div><strong>' + event.type + '</strong> (' + step + ')</div>' +
            '<div>' + (message || "No detail") + '</div>' +
            '<div class="timeline-meta">' + formatAmericanDateTime(event.timestamp) + ownerPart + '</div>' +
            '</div>'
          );
        })
        .join("");

      if (!timeline.innerHTML) {
        timeline.innerHTML = '<div class="empty">No events yet.</div>';
      }
    }

    window.addEventListener("message", (message) => {
      if (message.data && message.data.type === "state") {
        debugLog("window message state", {
          featureName: message.data.state?.featureName || "",
          selectedAgent: message.data.state?.selectedAgent || ""
        });
        renderState(message.data.state);
        return;
      }

      if (message.data && message.data.type === "featureOptions") {
        debugLog("window message featureOptions", {
          count: Array.isArray(message.data.featureOptions) ? message.data.featureOptions.length : 0
        });
        applyFeatureOptions(message.data.featureOptions || []);
        syncAgentDefaults();
        return;
      }

      if (message.data && message.data.type === "featureLoadingState") {
        debugLog("window message featureLoadingState", {
          loading: !!message.data.loading,
          message: message.data.message || ""
        });
        setFeatureLoadingState(!!message.data.loading, message.data.message || "");
        return;
      }
    });

    renderEmpty();
  </script>
</body>
</html>`;
  }
}

export function activate(context: vscode.ExtensionContext): void {
  const store = new FlowStore();
  const outputChannel = vscode.window.createOutputChannel("Visual Flow");
  let dashboard: DashboardController;
  let activeEventFileUri: vscode.Uri | undefined;
  let debugLogFileUri: vscode.Uri | undefined;
  let debugLogWriteChain = Promise.resolve();

  const appendDebugLogToFile = (line: string): void => {
    if (!debugLogFileUri) {
      return;
    }

    debugLogWriteChain = debugLogWriteChain
      .catch(() => {
        // Ignore previous write failures to keep the chain alive.
      })
      .then(async () => {
        const debugDirUri = vscode.Uri.file(path.dirname(debugLogFileUri!.fsPath));
        await vscode.workspace.fs.createDirectory(debugDirUri);

        let existing = "";
        try {
          const bytes = await vscode.workspace.fs.readFile(debugLogFileUri!);
          existing = Buffer.from(bytes).toString("utf8");
        } catch {
          // File may not exist yet.
        }

        const nextContent = existing + line + "\n";
        await vscode.workspace.fs.writeFile(debugLogFileUri!, Buffer.from(nextContent, "utf8"));
      });
  };

  const logDebug = (message: string, details?: unknown): void => {
    const timestamp = new Date().toISOString();
    const suffix = details === undefined ? "" : ` ${JSON.stringify(details)}`;
    const line = `[${timestamp}] ${message}${suffix}`;
    outputChannel.appendLine(line);
    appendDebugLogToFile(line);
  };

  const workspaceUri = vscode.workspace.workspaceFolders?.[0]?.uri;
  if (workspaceUri) {
    debugLogFileUri = vscode.Uri.joinPath(workspaceUri, ".visual-flow", "extension-debug.log");
  }

  logDebug("Visual Flow extension activated");

  const toDisplayPath = (uri: vscode.Uri): string => {
    const workspaceFolder = vscode.workspace.getWorkspaceFolder(uri);
    if (!workspaceFolder) {
      return uri.fsPath;
    }

    const relativePath = path.relative(workspaceFolder.uri.fsPath, uri.fsPath).replace(/\\/g, "/");
    return relativePath.length > 0 ? relativePath : ".";
  };

  const buildInstruction = (
    selectedAgent: string,
    featureName: string,
    destinationPath: string,
    eventFilePath: string,
    runId: string
  ): string => {
    if (selectedAgent === JIRA_FEATURE_AGENT) {
      return "Use agent @" + selectedAgent + " and ask for exactly 10 Jira samples as a JSON array with id, title, and description.";
    }

    const trackingLines = [
      "Real-time tracking requirement:",
      "Append one NDJSON line to '" + eventFilePath + "' after each run or step transition.",
      "Each line must be one valid JSON object with these fields:",
      "type = run.completed | step.started | step.completed | step.failed | step.fix_applied | step.skipped | delegation.sent | compare.gap_found",
      "runId = " + runId,
      "step = 1..9",
      "owner = planner | coder | verifier",
      "message = short status",
      "timestamp = ISO-8601",
      "Use these owners by step: 1 planner, 2 planner, 3 planner, 4 coder, 5 verifier, 6 verifier, 7 planner, 8 planner, 9 planner.",
      "Respect these prerequisites:",
      "- Step 2 and Step 3 can start only after Step 1 completes.",
      "- Step 4 can start only after Step 2 and Step 3 both complete.",
      "- Step 5 can start only if explicitly re-enabled after Step 4 completes.",
      "- If Step 5 stays disabled, append step.skipped for Step 5 before Step 6 starts.",
      "- Step 6 can start only after Step 4 completes and Step 5 is completed or skipped.",
      "- Step 7 can start only after Step 6 completes.",
      "- Step 8 and Step 9 can start only after Step 7 completes.",
      "- For Step 8 and Step 9, append separate delegation.sent lines in the same phase before their step.started lines.",
      "If a step fails, append step.failed first, then step.fix_applied when remediation starts, then step.completed when fixed.",
      "If Step 7 finds a gap, append compare.gap_found for Step 7 before restarting the fix loop.",
      "Do not emit events out of order or skip prerequisite events.",
      "",
      "Also append run completion with:",
      "type = run.completed",
      "runId = " + runId,
      "message = Run completed",
      "timestamp = ISO-8601"
    ];

    const instructionLines = [
      "Use agent @" + selectedAgent + " to implement feature '" + featureName + "' in destination folder '" + destinationPath + "'.",
      "",
      ...trackingLines
    ];

    return instructionLines.join("\n");
  };

  const emitEvent = async (event: VisualFlowEvent): Promise<void> => {
    if (!activeEventFileUri) {
      store.appendEvent(event);
      return;
    }

    try {
      const existingBytes = await vscode.workspace.fs.readFile(activeEventFileUri);
      const existingText = Buffer.from(existingBytes).toString("utf8");
      const nextText = existingText + toJsonLine(event);
      await vscode.workspace.fs.writeFile(activeEventFileUri, Buffer.from(nextText, "utf8"));
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to append event to tracking file.";
      void vscode.window.showWarningMessage(message);
      store.appendEvent(event);
    }
  };

  const quoteForDoubleQuotedShellArg = (value: string): string => {
    return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r?\n/g, "\\n");
  };

  const quoteForPowerShellSingleQuotedArg = (value: string): string => {
    return value.replace(/'/g, "''");
  };

  const getFirstToken = (command: string): string => {
    const trimmed = command.trim();
    if (!trimmed) {
      return "";
    }

    const firstSpace = trimmed.indexOf(" ");
    return firstSpace === -1 ? trimmed : trimmed.slice(0, firstSpace);
  };

  const isCommandAvailable = async (commandName: string): Promise<boolean> => {
    if (!commandName) {
      return false;
    }

    const lookupCommand =
      process.platform === "win32"
        ? `powershell -NoProfile -Command "if (Get-Command '${commandName}' -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"`
        : `command -v ${commandName}`;
    try {
      await execAsync(lookupCommand);
      return true;
    } catch {
      return false;
    }
  };

  const resolveCopilotExecutable = async (): Promise<string | undefined> => {
    if (await isCommandAvailable("copilot")) {
      return "copilot";
    }

    if (process.platform === "win32") {
      const appData = process.env.APPDATA;
      if (appData) {
        const fallbackPs1Path = path.join(
          appData,
          "Code",
          "User",
          "globalStorage",
          "github.copilot-chat",
          "copilotCli",
          "copilot.ps1"
        );

        try {
          await access(fallbackPs1Path);
          return `powershell -NoProfile -ExecutionPolicy Bypass -File \"${quoteForDoubleQuotedShellArg(fallbackPs1Path)}\"`;
        } catch {
          // Ignore fallback path check errors.
        }
      }
    }

    return undefined;
  };

  const parseFeatureOptionsFromCopilotOutput = (stdout: string): FeatureOption[] => {
    const tryParse = (value: string): FeatureOption[] => {
      const parsed = JSON.parse(value) as Array<{ id?: unknown; title?: unknown }>;
      if (!Array.isArray(parsed)) {
        throw new Error("Expected a JSON array of Jira features.");
      }

      return parsed
        .map((feature) => {
          const id = typeof feature.id === "string" ? feature.id.trim() : "";
          const title = typeof feature.title === "string" ? feature.title.trim() : "";
          const description =
            typeof (feature as { description?: unknown }).description === "string"
              ? (feature as { description: string }).description.trim()
              : "";
          if (!id || !title) {
            return undefined;
          }

          return {
            value: id,
            label: `${id} - ${title}`,
            description
          };
        })
        .filter((feature): feature is FeatureOption => !!feature);
    };

    const parseFromLines = (value: string): FeatureOption[] => {
      const features: FeatureOption[] = [];

      for (const rawLine of value.split(/\r?\n/g)) {
        const line = rawLine.trim();
        if (!line) {
          continue;
        }

        const cleanedLine = line.replace(/^\d+\.\s*/, "");
        const pipeMatch = cleanedLine.match(/^([A-Z][A-Z0-9]+-\d+)\s*\|\s*([^|]+?)\s*\|\s*(.+)$/i);
        if (pipeMatch) {
          features.push({
            value: pipeMatch[1].trim(),
            label: `${pipeMatch[1].trim()} - ${pipeMatch[2].trim()}`,
            description: pipeMatch[3].trim()
          });
          continue;
        }

        const dashMatch = cleanedLine.match(/^([A-Z][A-Z0-9]+-\d+)\s*-\s*(.+)$/i);
        if (dashMatch) {
          features.push({
            value: dashMatch[1].trim(),
            label: `${dashMatch[1].trim()} - ${dashMatch[2].trim()}`,
            description: ""
          });
        }
      }

      return features;
    };

    const parseFromInlinePairs = (value: string): FeatureOption[] => {
      const features: FeatureOption[] = [];
      const normalized = value.replace(/[•●]/g, " ").replace(/\s+/g, " ").trim();
      const pairPattern = /([A-Z][A-Z0-9]+-\d+)\s*\|\s*([^|]+?)\s*\|\s*(.*?)(?=\s+[A-Z][A-Z0-9]+-\d+\s*\||$)/g;

      for (const match of normalized.matchAll(pairPattern)) {
        const id = (match[1] || "").trim();
        const title = (match[2] || "").trim();
        const description = (match[3] || "").trim();
        if (!id || !title) {
          continue;
        }

        features.push({
          value: id,
          label: `${id} - ${title}`,
          description
        });
      }

      return features;
    };

    const parseFromMockSections = (value: string): FeatureOption[] => {
      const features: FeatureOption[] = [];
      const sectionPattern = /(?:^|\n)\s*(?:\d+\.\s+)?([A-Z][A-Z0-9]+-\d+)\s+[—-]\s+([^\n]+)([\s\S]*?)(?=(?:\n\s*(?:\d+\.\s+)?[A-Z][A-Z0-9]+-\d+\s+[—-]\s+)|$)/g;

      for (const match of value.matchAll(sectionPattern)) {
        const id = (match[1] || "").trim();
        const title = (match[2] || "").trim();
        const block = match[3] || "";
        if (!id || !title) {
          continue;
        }

        const descriptionMatch = block.match(/Description:\s*([\s\S]*?)(?=\n\s*(?:Business Objective:|Acceptance Criteria:|Recommended next step|$))/i);
        const description = (descriptionMatch?.[1] || "").replace(/\s+/g, " ").trim();

        features.push({
          value: id,
          label: `${id} - ${title}`,
          description
        });
      }

      return features;
    };

    const parseFromLabeledBlocks = (value: string): FeatureOption[] => {
      const features: FeatureOption[] = [];
      const blockPattern = /(?:^|\n)\s*(?:\d+\.\s+)?Id:\s*([A-Z][A-Z0-9]+-\d+)\s*\n\s*Title:\s*([^\n]+)\s*\n\s*Description:\s*([\s\S]*?)(?=(?:\n\s*(?:\d+\.\s+)?Id:\s*[A-Z][A-Z0-9]+-\d+)|$)/gi;

      for (const match of value.matchAll(blockPattern)) {
        const id = (match[1] || "").trim();
        const title = (match[2] || "").trim();
        const description = (match[3] || "").replace(/\s+/g, " ").trim();
        if (!id || !title) {
          continue;
        }

        features.push({
          value: id,
          label: `${id} - ${title}`,
          description
        });
      }

      return features;
    };

    const parseFromJsonLikeObjects = (value: string): FeatureOption[] => {
      const features: FeatureOption[] = [];
      const objectPattern = /"id"\s*:\s*"([^"]+)"[\s\S]*?"title"\s*:\s*"([^"]+)"[\s\S]*?"description"\s*:\s*"([\s\S]*?)"(?=\s*\}|\s*,\s*\{)/g;

      for (const match of value.matchAll(objectPattern)) {
        const id = (match[1] || "").trim();
        const title = (match[2] || "").trim();
        const description = (match[3] || "")
          .replace(/\\n/g, " ")
          .replace(/\s+/g, " ")
          .trim();

        if (!id || !title) {
          continue;
        }

        features.push({
          value: id,
          label: `${id} - ${title}`,
          description
        });
      }

      return features;
    };

    const trimmed = stdout.trim();
    if (!trimmed) {
      throw new Error("Copilot CLI returned an empty response.");
    }

    logDebug("Parsing Copilot CLI output", {
      outputLength: trimmed.length,
      preview: trimmed.slice(0, 300)
    });

    try {
      return tryParse(trimmed);
    } catch {
      try {
        const arrayStart = trimmed.indexOf("[");
        const arrayEnd = trimmed.lastIndexOf("]");
        if (arrayStart !== -1 && arrayEnd !== -1 && arrayEnd >= arrayStart) {
          return tryParse(trimmed.slice(arrayStart, arrayEnd + 1));
        }
      } catch {
        // Fall through to tolerant line parsing.
      }

      const inlineFeatures = parseFromInlinePairs(trimmed);
      if (inlineFeatures.length > 0) {
        return inlineFeatures;
      }

      const mockSectionFeatures = parseFromMockSections(trimmed);
      if (mockSectionFeatures.length > 0) {
        return mockSectionFeatures;
      }

      const labeledBlockFeatures = parseFromLabeledBlocks(trimmed);
      if (labeledBlockFeatures.length > 0) {
        return labeledBlockFeatures;
      }

      const jsonLikeFeatures = parseFromJsonLikeObjects(trimmed);
      if (jsonLikeFeatures.length > 0) {
        return jsonLikeFeatures;
      }

      const lineFeatures = parseFromLines(trimmed);
      if (lineFeatures.length > 0) {
        return lineFeatures;
      }

      throw new Error("Could not parse Jira features from the Copilot CLI response.");
    }
  };

  let cachedJiraFeatureOptions: FeatureOption[] | undefined;

  const loadJiraFeatureOptions = async (): Promise<FeatureOption[]> => {
    const currentWorkspaceUri = vscode.workspace.workspaceFolders?.[0]?.uri;
    if (!currentWorkspaceUri) {
      throw new Error("Open a workspace folder before loading Jira features.");
    }

    const copilotExecutable = await resolveCopilotExecutable();
    if (!copilotExecutable) {
      throw new Error("Copilot CLI is not available.");
    }

    const prompt = JIRA_SAMPLE_REQUEST;

    const command =
      `${copilotExecutable} --agent ${JIRA_FEATURE_AGENT} -p \"${quoteForDoubleQuotedShellArg(prompt)}\" ` +
      `--add-dir \"${quoteForDoubleQuotedShellArg(currentWorkspaceUri.fsPath)}\" --allow-all-tools --silent --no-color --stream off`;

    logDebug("Loading Jira features", {
      workspace: currentWorkspaceUri.fsPath,
      agent: JIRA_FEATURE_AGENT,
      prompt
    });

    try {
      const { stdout } = await execAsync(command, {
        cwd: currentWorkspaceUri.fsPath,
        maxBuffer: 1024 * 1024
      });

      const featureOptions = parseFeatureOptionsFromCopilotOutput(stdout);
      if (featureOptions.length === 0) {
        throw new Error("No Jira features were returned by Copilot CLI.");
      }

      logDebug("Loaded Jira features", {
        count: featureOptions.length,
        firstFeature: featureOptions[0]?.label ?? ""
      });

      cachedJiraFeatureOptions = featureOptions;
      return featureOptions;
    } catch (error) {
      if (cachedJiraFeatureOptions && cachedJiraFeatureOptions.length > 0) {
        logDebug("Using cached Jira features after refresh failure", {
          count: cachedJiraFeatureOptions.length,
          reason: error instanceof Error ? error.message : "Unknown error"
        });
        return cachedJiraFeatureOptions;
      }

      throw error;
    }
  };

  const runCopilotCli = async (
    agent: string,
    instruction: string,
    promptFileUri: vscode.Uri,
    workspaceRootUri: vscode.Uri,
    runId: string
  ): Promise<void> => {
    const config = vscode.workspace.getConfiguration("visualFlow");
    let template = config.get<string>(
      CLI_COMMAND_TEMPLATE_SETTING,
      "{copilotExecutable} -p \"{prompt}\" --add-dir \"{workspace}\" --allow-all-tools"
    );
    const terminalName = config.get<string>(CLI_TERMINAL_NAME_SETTING, "Visual Flow CLI");

    const normalizeTemplate = (rawTemplate: string): string => {
      let normalized = rawTemplate;

      // Support older templates from previous extension versions.
      normalized = normalized.replace(/\bagent\s+run\b/g, "");
      normalized = normalized.replace(/--prompt-file\s+\"\{promptFile\}\"/g, '-p "{prompt}"');
      normalized = normalized.replace(/--prompt-file\s+\{promptFile\}/g, '-p "{prompt}"');
      normalized = normalized.replace(/\{promptFile\}/g, "{prompt}");
      normalized = normalized.replace(/--agent\s+\"\{agent\}\"/g, "");
      normalized = normalized.replace(/--agent\s+\{agent\}/g, "");

      if (!/(^|\s)-p\s+\"?\{prompt\}\"?|--prompt\s+\"?\{prompt\}\"?/.test(normalized)) {
        normalized += ' -p "{prompt}"';
      }

      if (!normalized.includes("{workspace}")) {
        normalized += ' --add-dir "{workspace}"';
      }

      if (!normalized.includes("--allow-all-tools") && !normalized.includes("--allow-all") && !normalized.includes("--yolo")) {
        normalized += " --allow-all-tools";
      }

      return normalized.replace(/\s+/g, " ").trim();
    };

    template = normalizeTemplate(template);

    const copilotExecutable = await resolveCopilotExecutable();
    if (!copilotExecutable) {
      void vscode.window.showErrorMessage(
        "Copilot CLI is not available. Ensure Copilot Chat is installed and update visualFlow.copilotCli.commandTemplate if needed."
      );
      return;
    }

    if (!template.includes("{copilotExecutable}")) {
      if (template.trimStart().startsWith("copilot ")) {
        template = template.replace(/^\s*copilot\b/, "{copilotExecutable}");
      } else {
        template = "{copilotExecutable} " + template;
      }
    }

    const resolvedCommand = template
      .replaceAll("{copilotExecutable}", copilotExecutable)
      .replaceAll("{agent}", quoteForDoubleQuotedShellArg(agent))
      .replaceAll("{prompt}", process.platform === "win32" ? "$vfPrompt" : quoteForDoubleQuotedShellArg(instruction))
      .replaceAll("{promptFile}", quoteForDoubleQuotedShellArg(promptFileUri.fsPath))
      .replaceAll("{workspace}", quoteForDoubleQuotedShellArg(workspaceRootUri.fsPath))
      .replaceAll("{runId}", quoteForDoubleQuotedShellArg(runId));

    const terminal = vscode.window.createTerminal({ name: terminalName });
    terminal.show();

    if (process.platform === "win32") {
      terminal.sendText(`Set-Location \"${quoteForDoubleQuotedShellArg(workspaceRootUri.fsPath)}\"`);
      terminal.sendText(`$vfPrompt = Get-Content -Raw -LiteralPath '${quoteForPowerShellSingleQuotedArg(promptFileUri.fsPath)}'`);
    } else {
      terminal.sendText(`cd \"${quoteForDoubleQuotedShellArg(workspaceRootUri.fsPath)}\"`);
    }

    terminal.sendText(resolvedCommand);
  };

  const runFromRequest = async (request: StartRunRequest): Promise<void> => {
    const selectedAgent = request.selectedAgent.trim();
    const featureName =
      selectedAgent === JIRA_FEATURE_AGENT
        ? (request.featureName.trim() || JIRA_FIXED_FEATURE_ID)
        : request.featureName.trim();
    const customInstruction = request.instruction.trim();

    if (!featureName) {
      void vscode.window.showErrorMessage("Feature name is required.");
      return;
    }

    if (!selectedAgent) {
      void vscode.window.showErrorMessage("Agent selection is required.");
      return;
    }

    const workspaceUri = vscode.workspace.workspaceFolders?.[0]?.uri;
    if (!workspaceUri) {
      void vscode.window.showErrorMessage("Open a workspace folder before starting a run.");
      return;
    }

    const projectUri = workspaceUri;
    const destinationPath = toDisplayPath(projectUri);
    const plannedRunId = randomUUID();
    const eventFileUri = vscode.Uri.joinPath(projectUri, ".visual-flow", `run-${plannedRunId}.jsonl`);
    const promptFileUri = vscode.Uri.joinPath(projectUri, ".visual-flow", `prompt-${plannedRunId}.txt`);
    const eventFilePath = toDisplayPath(eventFileUri);

    const defaultInstruction = buildInstruction(
      selectedAgent,
      featureName,
      destinationPath,
      eventFilePath,
      plannedRunId
    );

    const trackingBlockStart = "Real-time tracking requirement:";
    const trackingBlock = defaultInstruction.split(trackingBlockStart).slice(1).join(trackingBlockStart);
    const instruction =
      customInstruction.length > 0
        ? selectedAgent === JIRA_FEATURE_AGENT || trackingBlock.length === 0
          ? customInstruction
          : customInstruction + "\n\n" + trackingBlockStart + trackingBlock
        : defaultInstruction;

    const run = store.startRun(featureName, instruction, selectedAgent, destinationPath, plannedRunId);

    try {
      const eventDirUri = vscode.Uri.joinPath(projectUri, ".visual-flow");
      await vscode.workspace.fs.createDirectory(eventDirUri);
      await vscode.workspace.fs.writeFile(promptFileUri, Buffer.from(instruction, "utf8"));
      if (run.events.length > 0) {
        await vscode.workspace.fs.writeFile(eventFileUri, Buffer.from(toJsonLine(run.events[0]), "utf8"));
      } else {
        await vscode.workspace.fs.writeFile(eventFileUri, Buffer.from("", "utf8"));
      }

      await store.attachEventFile(eventFileUri);
      activeEventFileUri = eventFileUri;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to initialize event tracking file.";
      void vscode.window.showWarningMessage(message);
    }

    await vscode.env.clipboard.writeText(instruction);
    dashboard.open();

    await runCopilotCli(selectedAgent, instruction, promptFileUri, workspaceUri, run.runId);

    void vscode.window.showInformationMessage(
      `Run ${run.runId} started with agent ${selectedAgent}. Copilot CLI launched. Tracking file: ${eventFilePath}.`
    );
  };

  const promptForStartRunRequest = async (): Promise<StartRunRequest | undefined> => {
    const selectedAgent = await vscode.window.showQuickPick(AVAILABLE_AGENTS, {
      title: "Visual Flow",
      placeHolder: "Select agent"
    });

    if (!selectedAgent) {
      return undefined;
    }

    const featureName =
      selectedAgent === JIRA_FEATURE_AGENT
        ? JIRA_FIXED_FEATURE_ID
        : await vscode.window.showInputBox({
            title: "Visual Flow",
            prompt: "Enter feature name",
            placeHolder: "feature-name",
            ignoreFocusOut: true
          });

    if (featureName === undefined) {
      return undefined;
    }

    const defaultInstruction =
      selectedAgent === JIRA_FEATURE_AGENT
        ? "Use agent @" + JIRA_FEATURE_AGENT + " and ask for exactly 10 Jira samples as a JSON array with id, title, and description."
        : "";

    const instruction = await vscode.window.showInputBox({
      title: "Visual Flow",
      prompt: "Optional instruction override",
      value: defaultInstruction,
      ignoreFocusOut: true
    });

    if (instruction === undefined) {
      return undefined;
    }

    return {
      featureName: featureName.trim(),
      selectedAgent,
      instruction: instruction.trim()
    };
  };

  const loadJiraFeaturesIntoDashboard = async (): Promise<void> => {
    logDebug("Dashboard requested Jira feature load");
    dashboard.setFeatureLoadingState(true, "Loading Jira sample features...");

    try {
      const featureOptions = await loadJiraFeatureOptions();
      dashboard.setFeatureLoadingState(false, `Loaded ${featureOptions.length} Jira sample features.`);
      dashboard.setFeatureOptions(featureOptions);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to load Jira feature options.";
      logDebug("Failed to load Jira features", { message });
      void vscode.window.showWarningMessage(message);
      dashboard.setFeatureLoadingState(false, `Failed to load Jira features: ${message}`);
      dashboard.setFeatureOptions([...DEFAULT_FEATURE_OPTIONS]);
    }
  };

  dashboard = new DashboardController(context, store, runFromRequest, loadJiraFeaturesIntoDashboard, logDebug);

  context.subscriptions.push(store, dashboard, outputChannel);

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.openDashboard", () => {
      outputChannel.show(true);
      dashboard.open();
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.startRun", async () => {
      dashboard.open();
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.startRunWithPrompts", async () => {
      const request = await promptForStartRunRequest();
      if (!request) {
        return;
      }

      await runFromRequest(request);
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.recordEvent", async () => {
      const state = store.getState();
      if (!state) {
        void vscode.window.showWarningMessage("No active run. Start a run first or attach an event file.");
        return;
      }

      const eventType = await vscode.window.showQuickPick(
        [
          "step.started",
          "step.completed",
          "step.failed",
          "step.fix_applied",
          "step.skipped",
          "delegation.sent",
          "compare.gap_found"
        ],
        {
          title: "Visual Flow",
          placeHolder: "Select event type"
        }
      );

      if (!eventType) {
        return;
      }

      const stepSelection = await vscode.window.showQuickPick(
        Object.keys(STEP_TITLES).map((key) => ({
          label: `${key}. ${STEP_TITLES[Number(key)]}`,
          step: Number(key)
        })),
        {
          title: "Visual Flow",
          placeHolder: "Choose step"
        }
      );

      if (!stepSelection) {
        return;
      }

      const ownerSelection = await vscode.window.showQuickPick(["planner", "coder", "verifier"], {
        title: "Visual Flow",
        placeHolder: "Choose owner"
      });

      if (!ownerSelection) {
        return;
      }

      const message = await vscode.window.showInputBox({
        title: "Visual Flow",
        prompt: "Optional detail for this event",
        ignoreFocusOut: true
      });

      await emitEvent({
        type: eventType as VisualFlowEventType,
        runId: state.runId,
        step: stepSelection.step,
        owner: ownerSelection,
        message: message?.trim() ?? "",
        timestamp: new Date().toISOString()
      });
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.completeRun", async () => {
      const state = store.getState();
      if (!state) {
        void vscode.window.showWarningMessage("No active run.");
        return;
      }

      await emitEvent({
        type: "run.completed",
        runId: state.runId,
        message: "Run completed",
        timestamp: new Date().toISOString()
      });

      void vscode.window.showInformationMessage(`Run ${state.runId} marked as completed.`);
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.attachEventFile", async () => {
      const files = await vscode.window.showOpenDialog({
        title: "Attach Visual Flow event file",
        canSelectMany: false,
        canSelectFolders: false,
        filters: {
          "Event files": ["json", "jsonl"]
        }
      });

      if (!files || files.length === 0) {
        return;
      }

      try {
        await store.attachEventFile(files[0]);
        activeEventFileUri = files[0];
        dashboard.open();
        void vscode.window.showInformationMessage("Event file attached. Dashboard now updates on file changes.");
      } catch (error) {
        const message = error instanceof Error ? error.message : "Failed to attach event file.";
        void vscode.window.showErrorMessage(message);
      }
    })
  );
}

export function deactivate(): void {
  // VS Code disposes subscriptions on deactivation.
}
