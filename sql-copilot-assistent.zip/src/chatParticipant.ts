import * as vscode from 'vscode';

import { MysqlConfigStore, ResolvedMysqlConnectionSettings } from './config';
import { MysqlService, QueryExecutionResult, QueryResultRows, SchemaSummary } from './mysqlService';
import { buildPlan, SqlPlan, summarizeQueryResult, summarizeSchema } from './sqlPlanner';

const CHAT_PARTICIPANT_ID = 'sqlCopilot.mysql';
const PENDING_MUTATION_STATE_KEY = 'sqlCopilot.pendingMutation';

interface PendingMutation {
  sql: string;
  explanation: string;
  database: string;
  createdAt: string;
  kind: 'mutation' | 'ddl';
}

export class SqlCopilotChatParticipant {
  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly configStore: MysqlConfigStore,
    private readonly mysqlService: MysqlService
  ) {}

  public create(): vscode.ChatParticipant {
    const participant = vscode.chat.createChatParticipant(CHAT_PARTICIPANT_ID, this.handleRequest);
    participant.iconPath = new vscode.ThemeIcon('database');
    return participant;
  }

  public async applyPendingMutationWithNotification(): Promise<void> {
    const settings = await this.requireResolvedSettings();
    if (!settings) {
      return;
    }

    const pending = this.getPendingMutation();
    if (!pending) {
      void vscode.window.showInformationMessage('There is no staged mutation to apply.');
      return;
    }

    if (pending.database !== settings.database) {
      void vscode.window.showWarningMessage(
        `The staged mutation targets database "${pending.database}", but the current configuration points to "${settings.database}".`
      );
      return;
    }

    const confirmed = await vscode.window.showWarningMessage(
      buildApplyConfirmationMessage(settings.database, pending.kind),
      { modal: true, detail: pending.sql },
      getApplyConfirmationLabel(pending.kind)
    );

    if (confirmed !== getApplyConfirmationLabel(pending.kind)) {
      return;
    }

    const result = await vscode.window.withProgress(
      {
        location: vscode.ProgressLocation.Notification,
        title: pending.kind === 'ddl' ? 'Applying staged DDL statement' : 'Applying staged SQL mutation',
        cancellable: false
      },
      async () => this.mysqlService.runMutation(settings, pending.sql)
    );

    await this.clearPendingMutation();
    void vscode.window.showInformationMessage(
      `${pending.kind === 'ddl' ? 'DDL statement applied' : 'Mutation applied'}. Affected rows: ${result.affectedRows}${result.insertId > 0 ? `, insert id: ${result.insertId}` : ''}.`
    );
  }

  public async discardPendingMutationWithNotification(): Promise<void> {
    const pending = this.getPendingMutation();
    if (!pending) {
      void vscode.window.showInformationMessage('There is no staged mutation to discard.');
      return;
    }

    await this.clearPendingMutation();
    void vscode.window.showInformationMessage('Staged mutation discarded.');
  }

  private readonly handleRequest: vscode.ChatRequestHandler = async (request, _context, stream, token) => {
    const command = request.command?.trim().toLowerCase();

    if (command === 'apply') {
      await this.handleApplyCommand(stream);
      return { metadata: { command: 'apply' } };
    }

    if (command === 'discard') {
      await this.handleDiscardCommand(stream);
      return { metadata: { command: 'discard' } };
    }

    const settings = await this.requireResolvedSettings(stream);
    if (!settings) {
      return { metadata: { command: 'configure' } };
    }

    stream.progress(`Connected configuration loaded for ${settings.database}.`);

    let schema: SchemaSummary;
    try {
      schema = await this.mysqlService.getSchemaSummary(settings);
    } catch (error) {
      stream.markdown(renderErrorMessage(error, 'Failed to inspect the MySQL schema.'));
      stream.button({ command: 'sqlCopilot.testConnection', title: 'Test connection' });
      return { metadata: { command: 'schema-error' } };
    }

    if (command === 'schema') {
      await this.handleSchemaRequest(request, settings, schema, stream, token);
      return { metadata: { command: 'schema' } };
    }

    let plan: SqlPlan;
    try {
      plan = await buildPlan(request.model, request.prompt, schema, settings.maxRows, token);
    } catch (error) {
      stream.markdown(renderErrorMessage(error, 'Failed to plan a SQL action from the prompt.'));
      return { metadata: { command: 'plan-error' } };
    }

    await this.handlePlan(request, settings, schema, plan, stream, token);
    return { metadata: { command: plan.intent, sql: plan.sql } };
  };

  private async handleSchemaRequest(
    request: vscode.ChatRequest,
    settings: ResolvedMysqlConnectionSettings,
    schema: SchemaSummary,
    stream: vscode.ChatResponseStream,
    token: vscode.CancellationToken
  ): Promise<void> {
    stream.progress(`Summarizing schema for ${settings.database}.`);

    try {
      const summary = await summarizeSchema(request.model, request.prompt, schema, token);
      stream.markdown(summary);
      stream.markdown(`\n\n${renderSchemaFacts(schema)}`);
    } catch (error) {
      stream.markdown(renderErrorMessage(error, 'Failed to summarize the schema with Copilot.'));
      stream.markdown(`\n\n${renderSchemaFacts(schema)}`);
    }
  }

  private async handlePlan(
    request: vscode.ChatRequest,
    settings: ResolvedMysqlConnectionSettings,
    _schema: SchemaSummary,
    plan: SqlPlan,
    stream: vscode.ChatResponseStream,
    token: vscode.CancellationToken
  ): Promise<void> {
    if (plan.intent === 'schema') {
      await this.handleSchemaRequest(request, settings, await this.mysqlService.getSchemaSummary(settings), stream, token);
      return;
    }

    if (plan.intent === 'unsupported' || !plan.sql) {
      stream.markdown(`### ${escapeMarkdown(plan.title)}\n\n${escapeMarkdown(plan.explanation)}`);
      if (plan.assumptions.length > 0) {
        stream.markdown(renderAssumptions(plan.assumptions));
      }
      return;
    }

    if (plan.intent === 'mutation' || plan.intent === 'ddl') {
      if (plan.intent === 'mutation' && !settings.allowModelGeneratedMutations) {
        stream.markdown('Model-generated mutations are disabled by the `sqlCopilot.allowModelGeneratedMutations` setting.');
        return;
      }

      await this.context.workspaceState.update(PENDING_MUTATION_STATE_KEY, {
        sql: plan.sql,
        explanation: plan.explanation,
        database: settings.database,
        createdAt: new Date().toISOString(),
        kind: plan.intent === 'ddl' ? 'ddl' : 'mutation'
      } satisfies PendingMutation);

      stream.markdown(renderMutationProposal(plan, settings.database));
      stream.button({ command: 'sqlCopilot.applyPendingMutation', title: plan.intent === 'ddl' ? 'Apply pending DDL' : 'Apply pending mutation' });
      stream.button({ command: 'sqlCopilot.discardPendingMutation', title: 'Discard pending statement' });
      return;
    }

    stream.progress('Running read-only SQL.');

    let result: QueryExecutionResult;
    try {
      result = await this.mysqlService.runReadOnlyQuery(settings, plan.sql);
    } catch (error) {
      stream.markdown(renderErrorMessage(error, 'The generated SQL could not be executed.'));
      stream.markdown(renderSqlBlock(plan.sql));
      return;
    }

    await this.renderReadResult(request, plan, result as QueryResultRows, stream, token);
  }

  private async renderReadResult(
    request: vscode.ChatRequest,
    plan: SqlPlan,
    result: QueryResultRows,
    stream: vscode.ChatResponseStream,
    token: vscode.CancellationToken
  ): Promise<void> {
    stream.markdown(`### ${escapeMarkdown(plan.title)}\n\n${escapeMarkdown(plan.explanation)}`);

    try {
      const summary = await summarizeQueryResult(
        request.model,
        request.prompt,
        {
          sql: result.sql,
          rows: result.rows,
          totalRowCount: result.totalRowCount
        },
        token
      );
      stream.markdown(`\n\n${summary}`);
    } catch {
      // Keep the raw result even if the summary model call fails.
    }

    stream.markdown(`\n\n${renderSqlBlock(result.sql)}`);
    stream.markdown(`\n\n${renderRowsTable(result)}`);
    if (plan.assumptions.length > 0) {
      stream.markdown(renderAssumptions(plan.assumptions));
    }
  }

  private async handleApplyCommand(stream: vscode.ChatResponseStream): Promise<void> {
    const settings = await this.requireResolvedSettings(stream);
    if (!settings) {
      return;
    }

    const pending = this.getPendingMutation();
    if (!pending) {
      stream.markdown('There is no staged mutation to apply.');
      return;
    }

    if (pending.database !== settings.database) {
      stream.markdown(
        `The staged mutation targets database **${escapeMarkdown(pending.database)}**, but the current configuration points to **${escapeMarkdown(settings.database)}**.`
      );
      return;
    }

    const confirmed = await vscode.window.showWarningMessage(
      buildApplyConfirmationMessage(settings.database, pending.kind),
      { modal: true, detail: pending.sql },
      getApplyConfirmationLabel(pending.kind)
    );

    if (confirmed !== getApplyConfirmationLabel(pending.kind)) {
      stream.markdown('The staged statement was not applied.');
      return;
    }

    stream.progress(pending.kind === 'ddl' ? 'Applying staged DDL statement.' : 'Applying staged mutation.');

    try {
      const result = await this.mysqlService.runMutation(settings, pending.sql);
      await this.clearPendingMutation();
      stream.markdown(renderMutationApplied(result, pending.kind));
    } catch (error) {
      stream.markdown(renderErrorMessage(error, pending.kind === 'ddl' ? 'Failed to apply the staged DDL statement.' : 'Failed to apply the staged mutation.'));
      stream.markdown(renderSqlBlock(pending.sql));
    }
  }

  private async handleDiscardCommand(stream: vscode.ChatResponseStream): Promise<void> {
    const pending = this.getPendingMutation();
    if (!pending) {
      stream.markdown('There is no staged mutation to discard.');
      return;
    }

    await this.clearPendingMutation();
    stream.markdown('The staged statement has been discarded.');
  }

  private async requireResolvedSettings(stream?: vscode.ChatResponseStream): Promise<ResolvedMysqlConnectionSettings | undefined> {
    const resolved = await this.configStore.resolveSettings();
    if (resolved.settings) {
      return resolved.settings;
    }

    if (stream) {
      stream.markdown([
        'The MySQL connection is not fully configured.',
        '',
        `Missing: ${resolved.missing.map((item) => `**${escapeMarkdown(item)}**`).join(', ')}`,
        '',
        'Run the connection setup command or provide VS Code settings manually.'
      ].join('\n'));
      stream.button({ command: 'sqlCopilot.configureConnection', title: 'Configure connection' });
      stream.button({ command: 'sqlCopilot.setPassword', title: 'Set MySQL password' });
      stream.button({ command: 'sqlCopilot.testConnection', title: 'Test connection' });
    }

    return undefined;
  }

  private getPendingMutation(): PendingMutation | undefined {
    return this.context.workspaceState.get<PendingMutation>(PENDING_MUTATION_STATE_KEY);
  }

  private async clearPendingMutation(): Promise<void> {
    await this.context.workspaceState.update(PENDING_MUTATION_STATE_KEY, undefined);
  }
}

function renderMutationProposal(plan: SqlPlan, database: string): string {
  return [
    `### ${escapeMarkdown(plan.title)}`,
    '',
    escapeMarkdown(plan.explanation),
    '',
    `Target database: **${escapeMarkdown(database)}**`,
    '',
    plan.intent === 'ddl'
      ? 'This DDL statement has been staged and will only run after you explicitly confirm `/apply` or the command button.'
      : 'The mutation has been staged and will not run until you use `/apply` or the command button.',
    '',
    renderSqlBlock(plan.sql ?? '')
  ].join('\n');
}

function renderMutationApplied(
  result: { affectedRows: number; insertId: number; sql: string; warningStatus: number },
  kind: PendingMutation['kind']
): string {
  return [
    kind === 'ddl' ? '### DDL applied' : '### Mutation applied',
    '',
    `Affected rows: **${result.affectedRows}**`,
    result.insertId > 0 ? `Insert id: **${result.insertId}**` : 'Insert id: **0**',
    `Warnings: **${result.warningStatus}**`,
    '',
    renderSqlBlock(result.sql)
  ].join('\n');
}

function renderRowsTable(result: QueryResultRows): string {
  if (result.rows.length === 0) {
    return 'No rows returned.';
  }

  const columns = result.columns.length > 0 ? result.columns : Object.keys(result.rows[0]);
  const header = `| ${columns.join(' | ')} |`;
  const divider = `| ${columns.map(() => '---').join(' | ')} |`;
  const body = result.rows.map((row) => `| ${columns.map((column) => escapeTableCell(row[column])).join(' | ')} |`);
  const suffix = result.totalRowCount > result.displayedRowCount
    ? `\nShowing ${result.displayedRowCount} of ${result.totalRowCount} rows.`
    : `\nReturned ${result.totalRowCount} rows.`;

  return [header, divider, ...body].join('\n') + suffix;
}

function renderSchemaFacts(schema: SchemaSummary): string {
  const lines = [
    '### Schema facts',
    '',
    `- Database: ${escapeMarkdown(schema.database)}`,
    `- Tables: ${schema.tables.length}`,
    `- Foreign keys: ${schema.foreignKeys.length}`
  ];

  return lines.join('\n');
}

function buildApplyConfirmationMessage(database: string, kind: PendingMutation['kind']): string {
  return kind === 'ddl'
    ? `Execute staged DDL against ${database}? This can change or remove schema objects.`
    : `Apply staged SQL to ${database}?`;
}

function getApplyConfirmationLabel(kind: PendingMutation['kind']): string {
  return kind === 'ddl' ? 'Execute DDL' : 'Apply';
}

function renderAssumptions(assumptions: string[]): string {
  return ['\n\nAssumptions:', ...assumptions.map((assumption) => `- ${escapeMarkdown(assumption)}`)].join('\n');
}

function renderSqlBlock(sql: string): string {
  return ['```sql', sql, '```'].join('\n');
}

function renderErrorMessage(error: unknown, prefix: string): string {
  const message = error instanceof Error ? error.message : String(error);
  return `**${escapeMarkdown(prefix)}**\n\n${escapeMarkdown(message)}`;
}

function escapeMarkdown(value: string): string {
  return value.replace(/[\\`*_{}[\]()#+\-.!|]/g, '\\$&');
}

function escapeTableCell(value: unknown): string {
  if (value === null || value === undefined) {
    return '';
  }

  if (typeof value === 'object') {
    return JSON.stringify(value).replace(/\|/g, '\\|');
  }

  return String(value).replace(/\|/g, '\\|').replace(/\r?\n/g, ' ');
}