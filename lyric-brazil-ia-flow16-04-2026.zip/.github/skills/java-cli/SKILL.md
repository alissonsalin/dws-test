---
name: java-cli
description: "Run Java workflow commands with repository-approved Java version detection, Gradle Wrapper preference, and Step 4 timing rules. Use when starting Java implementation, build verification, or Java security validation."
argument-hint: "Describe the Java workflow phase, command goal, and any current command failure"
---

# Java Command Execution Rules

## When to Use

- Step 4 Java implementation is starting.
- You need to choose or run a Java build, test, or security command.
- You need the repository-approved Java version detection flow.

## Command Selection Rules

- Prefer Gradle Wrapper over system Gradle, run from the project root unless another path is required, keep commands minimal, avoid destructive actions unless requested, and prefer non-interactive variants.

## Commands by Phase

- For new Java projects, or when the project is not yet buildable, add or update required `build.gradle` or `build.gradle.kts` dependencies and plugins during Step 4.
- Complete framework bootstrap and required dependency setup before running validation or verification commands.
- If missing dependencies or plugins are the reason a command would fail, fix the build configuration first instead of discovering the gap later.
- Treat Step 4 dependency or plugin changes as the trigger for later dependency-security validation.
- During Step 4, inspect `build.gradle` or `build.gradle.kts` for Lombok configuration before implementing Java classes. If Lombok is missing, add it immediately so DTOs, entities, commands, responses, and value objects use the Lombok conventions required by this repository.
- When Step 5 requires Java CVE validation, inspect `build.gradle` or `build.gradle.kts` during Step 4 and add or repair the OWASP Dependency Check plugin and `dependencyCheckAnalyze` task if they are not already present before running the security command.
- For new Java projects, or when Java coverage setup changes, follow `.github/skills/jacoco/SKILL.md` for required JaCoCo plugin, task, verification, and lifecycle expectations.

## Approved Java Test Commands

- Use Gradle Wrapper as the default Java test runner for this repository.
- Run Java test commands from the project root.
- Approved Java test-and-coverage command:
	- Windows: `.\\gradlew test jacocoTestReport jacocoTestCoverageVerification`
	- macOS and Linux: `./gradlew test jacocoTestReport jacocoTestCoverageVerification`
- Use `.github/skills/jacoco/SKILL.md` for JaCoCo expectations, and do not replace this single approved verification command with Maven, IDE-only, direct JUnit, or other alternate Java test commands unless the repository or user explicitly requires it.

## Approved Java Security Commands

- Use Gradle Wrapper as the default Java security-validation runner for this repository.
- Run Java security commands from the project root.
- Use dependency-security validation when the build changed because dependencies or plugins were added or updated, or when the user explicitly asks for security or CVE validation.
- Approved Java dedicated CVE scan command:
	- Windows: `.\\gradlew dependencyCheckAnalyze`
	- macOS and Linux: `./gradlew dependencyCheckAnalyze`
- `dependencyCheckAnalyze` is the repository-approved dedicated Java CVE scan task for Step 5.
- If the task is missing because the OWASP Dependency Check plugin is not configured yet, inspect `build.gradle` or `build.gradle.kts` and add or repair that plugin during Step 4 before retrying Step 5.
- `dependencyUpdates` may be used separately for dependency update analysis when that hygiene check is explicitly needed, but it does not satisfy Step 5 CVE validation by itself.
- Do not replace the approved wrapper command with Maven, IDE, ad-hoc scanners, or multiple overlapping Step 5 security commands unless the repository explicitly defines them.

## Java Environment Inspection

- Windows: `java -version`
- macOS and Linux: `java --version`
- Run this inspection exactly once at the start of Step 4 for each Java feature workflow.
- Do not run the inspection again later unless the user explicitly requests it.
- Parse the first version token into a major Java version.
- If the detected major version is 21 or higher, use that detected major version for project Java configuration.
- If the detected major version is lower than 21, configure the project to Java 21 and note that local JDK upgrade is required for runtime execution.
- If parsing fails or output is ambiguous, ask for explicit version confirmation before changing Java version settings.

## Retry and Reporting

- Follow `.github/instructions/command-resilience.instructions.md` for shared preflight checks, retry behavior, and failure reporting.
- Summarize results in plain language after execution.
- Highlight only the relevant lines: pass/fail status, errors, warnings, and artifact paths.