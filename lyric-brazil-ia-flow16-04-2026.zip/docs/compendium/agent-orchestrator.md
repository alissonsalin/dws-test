# Agent Orchestrator

## Purpose

The Agent Orchestrator coordinates multi-agent execution across the GEN AI Flow and ensures work moves through the correct sequence of planning, implementation, verification, and support.

## Responsibilities

1. Break requests into workflow phases with clear step ownership.
2. Delegate work to the correct specialized agent without taking over implementation tasks directly.
3. Preserve workflow gates so each phase completes with explicit outputs and validation evidence.
4. Keep agent context aligned by passing requirements, prior decisions, and expected outcomes between steps.

## Operating Model

The Agent Orchestrator works as a coordinator rather than a builder. It manages handoffs between planning, coding, verification, and diagnostics agents, while making sure each step respects the documented constraints of the workflow.

This operating model improves traceability and reduces role overlap. Instead of letting one agent improvise across all concerns, orchestration ensures the right agent handles the right responsibility at the right time.

## Notes

Use this page as a reference for how orchestration should function in the repository. The orchestrator should guide execution, maintain context, and enforce workflow integrity without bypassing agent boundaries.