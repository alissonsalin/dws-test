# Python

## Purpose

Define Python implementation expectations aligned with clean architecture and maintainable testing.

## Core Technical Stack

1. Clean architecture package separation.
2. Boundary validation and explicit contracts.
3. Deterministic unit tests with isolated external dependencies.
4. Resilient command execution policy for validation and verification.

## Key Expectations

- Clean architecture boundaries (`domain`, `usecase`, `adapter`, `gateway`).
- Boundary validation and delegation from adapters.
- Secure handling of inputs and secrets.
- Focused modules and clear naming.
- Updated tests whenever behavior changes.

## Recommended Structure

```text
src/
	domain/
	usecase/
	adapter/
	gateway/
```

## Validation And Error Strategy

- Validate external inputs at adapter boundaries.
- Convert framework-level errors to stable business/application errors.
- Keep error contract mapping in adapters, not in domain logic.

## Integration Strategy

- Gateway layer contains HTTP/DB integration clients.
- Define timeout, retry, and error translation behavior in gateway modules.
- Keep use cases independent of transport libraries.

## Command And Validation Guidance

- Follow Node/Python resilience and shared command-resilience instructions.
- Run policy-approved commands with preflight checks.
- Use material-fix retries; avoid repeating unchanged failures.

## Testing Model

- Test domain and usecase behavior directly.
- Mock only external boundaries.
- Cover success, failure, and edge cases for changed logic.
- Keep fixtures explicit and local to each test module where practical.

## Related Technical References

- [Clean Architecture](../for-developers/clean-architecture.md)
- [Unit test](../for-developers/unit-test.md)

## Related Flow Steps

- [Step 4 - Start Implementation](../flow/step-4.md)
- [Step 5 - Security Validation](../flow/step-5.md)
- [Step 6 - Create Unit Tests](../flow/step-6.md)
