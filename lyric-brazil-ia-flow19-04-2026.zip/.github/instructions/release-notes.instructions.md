---
applyTo: "**/{CHANGELOG.md,RELEASE_NOTES.md,release-notes/**/*.md}"
description: "Use when creating or updating release notes to keep versioning, feature summaries, and documentation links consistent."
---

# Release Notes Rules

- Keep release notes clear, chronological, and easy to scan.
- Include the release identifier for each entry.
- Use these release formats:
  - `xx.xx` for a normal release
  - `xx.xx.xx` for a hotfix release
- Group changes under the matching release entry instead of mixing multiple releases in one flat list.
- Include a feature summary for each release.
- When useful, organize the feature summary as `Features by release` so readers can scan changes version by version.
- Add links to relevant repository documentation pages when a release introduces or changes documented behavior.
- Prefer repository-relative links to docs that already exist instead of duplicating detailed explanations in the release notes.

# Recommended Structure

- Release
- Features by release
- Documentation links

# Quality Checks Before Finalizing

- Confirm each release version matches the required format.
- Ensure documentation links point to files that exist in the repository.
- Keep each release entry concise and focused on user-visible changes, fixes, or operational notes.