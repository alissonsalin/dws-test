# Agents

## Purpose

This page documents the custom agents used in this repository. Agents are responsible for workflow orchestration, tool usage rules, and role-specific execution behavior.

## When To Use Agents

Use an agent when you need:

- end-to-end workflow sequencing
- explicit tool expectations or restrictions
- autonomous execution behavior
- a focused role for a recurring workflow

## Agent in This Repository

### `.github/agents/feature-flow.agent.md`

- Primary feature delivery agent for the repository.
- Owns the Step 1 to Step 9 workflow.
- Controls design-first behavior, checklist updates, gates, tool usage, troubleshooting flow, and Step 9 follow-through.
- Is invoked through the agent picker or with `@feature-flow` in chat.

## What The Feature Agent Controls

- startup behavior and deferred backlog carry-forward
- TODO list initialization and updates
- design approval and gate handling
- implementation sequencing
- command execution behavior
- validation, troubleshooting, and continuous improvement flow

## What Should Stay Out of Agents

- deep language-specific implementation rules
- file-pattern-specific guidance better expressed with `applyTo`
- narrow, opt-in remediation workflows better handled by skills

## Relationship To Other Customizations

1. `.github/copilot-instructions.md` points feature work to the feature agent.
2. `.github/instructions/*.instructions.md` provide technical detail when file scopes match.
3. `.github/skills/*/SKILL.md` provide specialized on-demand workflows that complement the agent.

## Related References

- [Custom Instructions](custom-instructions.md)
- [Skills](skills.md)
- [Flow - Overview](../flow/flow.md)
- [Flow - Step 4](../flow/step-4.md)