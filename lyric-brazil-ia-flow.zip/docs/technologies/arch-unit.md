# Arch Unit

## Purpose

ArchUnit tests enforce clean architecture boundaries so structural violations are caught automatically.

Primary runtime source: `.github/skills/archunit/SKILL.md`.

## What To Enforce

1. Layer package boundaries for `domain`, `usecase`, `adapter`, `gateway`.
2. Allowed and forbidden dependency directions.
3. Prohibited framework leakage into business layers.
4. Optional naming and package-placement conventions.

## Required Layer Coverage

Architecture tests should validate boundaries for:

1. `domain`
2. `usecase`
3. `adapter`
4. `gateway`

## Required Dependency Rules

- `usecase` may depend on `domain`.
- `adapter` may depend on `usecase` and `domain`.
- `gateway` may depend on `usecase` and `domain`.
- `domain` must not depend on `usecase`, `adapter`, or `gateway`.

## Example Rule Set (Conceptual)

```java
// Example intent only; adapt package names to your project
noClasses().that().resideInAPackage("..domain..")
	.should().dependOnClassesThat().resideInAnyPackage("..adapter..", "..gateway..", "..usecase..");

classes().that().resideInAPackage("..adapter..")
	.should().onlyDependOnClassesThat().resideInAnyPackage(
			"..adapter..", "..usecase..", "..domain..", "java..", "org.slf4j..", "org.springframework..");
```

## Recommended Failure Handling

- Treat rule failures as design regressions.
- Fix dependency direction first, not test assertions.
- If a temporary exception is unavoidable, document rationale and planned removal.

## Test Placement And Naming

- Place architecture tests under `src/test`.
- Use explicit test names, for example `CleanArchitectureArchUnitTest`.
- Keep rule names readable and tied to architecture constraints.

## Related Technical References

- [Clean Architecture](../for-developers/clean-architecture.md)
- [Java](java.md)

## Related Flow Steps

- [Step 4 - Start Implementation](../flow/step-4.md)
- [Step 6 - Create Unit Tests](../flow/step-6.md)
- [Step 7 - Compare & Adjust](../flow/step-7.md)
