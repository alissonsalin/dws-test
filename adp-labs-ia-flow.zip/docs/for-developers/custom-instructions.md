# Custom Instructions

## Purpose

This page documents the instruction files used by Copilot during feature workflows. It focuses on the workspace entrypoint and the scoped `.instructions.md` files that load automatically by file pattern.

## How Instruction Loading Works

- The workspace entrypoint is defined in `.github/copilot-instructions.md`.
- File-scoped instructions are defined in `.github/instructions/*.instructions.md`.
- Each instruction file has an `applyTo` pattern that determines when it is loaded.
- When more than one instruction applies, use the most specific file as source of truth for detailed behavior.

## Workspace Entrypoint

The workspace entrypoint is `.github/copilot-instructions.md`.

It is responsible for:

- pointing feature work to the `feature-flow` agent
- listing always-on instruction files
- listing on-demand skills
- defining shared feature deliverables and workspace-level expectations

## Instruction Files in This Repository

### `.github/instructions/workflow-status.instructions.md`

- Standardizes checklist format and status icons in workflow-facing documentation and agent definitions.
- Ensures every step (1 to 9) is shown with a clear current status.
- Prevents partial or inconsistent workflow status reporting.

### `.github/instructions/design-first.instructions.md`

- Blocks coding actions in workflow documentation contexts until Step 2 (technical design) is approved.
- Keeps requirement analysis and design separated from code generation.
- Works with the feature-flow agent instead of replacing it.

### `.github/instructions/command-resilience.instructions.md`

- Defines retry and remediation behavior for command failures.
- Requires fix-first retries instead of rerunning failing commands unchanged.
- Encourages preflight checks to reduce avoidable command errors.

### `.github/instructions/java-cli.instructions.md`

- Defines Java command-line flow, including Java version detection timing.
- Enforces a single Java detection execution at Step 4 start.
- Aligns command usage with repository-approved verification flow.

## Detailed Instruction Reference

### `.github/copilot-instructions.md` (Workspace Entrypoint)

- Points feature work to the `feature-flow` agent.
- Lists always-on instruction files and on-demand skills.
- Defines feature deliverables and shared workspace-level guidance.

### `.github/instructions/workflow-status.instructions.md`

- Standardizes checklist format and status icons in workflow-facing documentation and agent definitions.
- Ensures every step (1 to 9) is shown with a clear current status.
- Prevents partial or inconsistent workflow status reporting.

### `.github/instructions/design-first.instructions.md`

- Blocks coding actions in workflow documentation contexts until Step 2 (technical design) is approved.
- Keeps requirement analysis and design separated from code generation.
- Works with the feature-flow agent instead of replacing it.

### `.github/agents/tech-refresh.agent.md`

- Executes the tech refresh workflow as a dedicated agent.
- Captures prerequisite analysis and approval before the normal feature workflow begins.
- Hands off to the standard feature workflow after approval while preserving repository rules.

### `.github/instructions/tech-refresh.instructions.md`

- Defines the required sections for tech refresh analysis documents.
- Prevents documenting or executing Step 1 to Step 9 before analysis approval.
- Standardizes migration planning, validation planning, and rollback coverage.

### `.github/instructions/command-resilience.instructions.md`

- Defines retry and remediation behavior for command failures.
- Requires fix-first retries instead of rerunning failing commands unchanged.
- Encourages preflight checks to reduce avoidable command errors.

### `.github/instructions/java-cli.instructions.md`

- Defines Java command-line flow, including Java version detection timing.
- Enforces a single Java detection execution at Step 4 start.
- Aligns command usage with repository-approved verification flow.

### `.github/instructions/docs.instructions.md`

- Defines documentation writing quality, structure, and consistency.
- Enforces Step 2 diagrams (ASCII + Mermaid) when producing technical design docs.
- Adds required technical design sections, including impact/risk checks.

### `.github/instructions/clean-architecture.instructions.md`

- Defines architecture boundaries: `domain`, `usecase`, `adapter`, `gateway`.
- Enforces inward dependency direction.
- Clarifies boundary ownership for interfaces and infrastructure implementations.

### `.github/instructions/java.instructions.md`

- Defines Java implementation conventions and naming patterns.
- Enforces entity-prefixed class names across controller/usecase/gateway areas.
- Aligns Java behavior with Spring, ArchUnit, Lombok, and CLI command policies.

### `.github/instructions/spring.instructions.md`

- Enforces Spring-specific structure and annotation rules.
- Requires constructor injection and blocks `@Autowired` field injection.
- Enforces YAML-only configuration (`application.yml`, `application-development.yml`, and `application-test.yml`).
- Requires `Application` as the exact main class name.

### `.github/instructions/lombok.instructions.md`

- Defines Lombok usage strategy for Java DTO/entity/command/response classes.
- Enforces `@Builder`-based object construction patterns.
- Blocks Java `record` usage for those model types when Lombok is present.

### `.github/instructions/archunit.instructions.md`

- Enforces architecture test creation/update for Java features.
- Defines mandatory layer-boundary rules for `domain`, `usecase`, `adapter`, and `gateway`.
- Clarifies naming and placement for architecture test classes.

### `.github/instructions/testing.instructions.md`

- Defines test authoring expectations (happy path, failure path, edge cases).
- Enforces coverage floors by layer and Java completion gates.
- Defines JaCoCo generation, report reuse behavior, and non-interactive command rules.

### `.github/instructions/openapi.instructions.md`

- Enforces API documentation alignment with implementation and tests.
- Uses dependency/annotation-driven OpenAPI generation by default.
- Blocks creation of standalone Swagger/OpenAPI files unless explicitly requested.

### `.github/instructions/nodejs.instructions.md`

- Defines NodeJS clean architecture conventions and implementation quality rules.
- Guides controller/service/repository separation for JavaScript/TypeScript features.

### `.github/instructions/python.instructions.md`

- Defines Python clean architecture conventions and validation/testing expectations.
- Guides boundary design, error handling, and maintainable Python test strategy.

### `.github/instructions/node-python-cli-resilience.instructions.md`

- Applies command resilience behavior specifically for NodeJS and Python workflows.
- Reduces retry loops and enforces fix-driven command remediation.

## Precedence and Conflict Handling

1. Use `.github/copilot-instructions.md` as the workspace entrypoint.
2. Use the relevant file-level instruction as source of truth for technical detail.
3. If two file-level rules overlap, prioritize the more specific domain file:
   - testing details: `.github/instructions/testing.instructions.md`
   - architecture tests: `.github/instructions/archunit.instructions.md`
   - Spring config/annotations: `.github/instructions/spring.instructions.md`
   - API contract behavior: `.github/instructions/openapi.instructions.md`
4. Keep workspace entrypoints and workflow files concise and avoid duplicating deep technical rules.
5. Use the tech refresh agent and instruction only for migration-style work; keep default feature flow unchanged for ordinary delivery.

## Operational Rules You Should Expect

- Design approval is required before implementation actions.
- Tech refresh work requires prerequisite analysis approval before Step 1 starts.
- Interactive gates use numbered options with icons.
- Test and JaCoCo commands run in non-interactive mode.
- Coverage requests should reuse an existing JaCoCo HTML report when valid for current code state.
- Java API implementations should use dependency-driven OpenAPI generation and controller annotations by default (no standalone OpenAPI files unless explicitly requested).

## Related References

- [For Developers - Overview](overview.md)
- [Agents](agents.md)
- [Skills](skills.md)
- [Clean Architecture](clean-architecture.md)
- [Unit test](unit-test.md)
- [Flow - Step 2](../flow/step-2.md)
- [Flow - Step 6](../flow/step-6.md)
