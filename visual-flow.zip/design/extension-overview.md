# Extension Design Overview

## Purpose
The extension provides a Visual Flow dashboard inside VS Code to orchestrate and track feature delivery runs. It coordinates user input, agent selection, Jira sample loading, Copilot CLI execution, and live step/event visualization.

## Main Responsibilities
1. Open and manage a webview dashboard UI.
2. Load Jira feature samples through the Copilot CLI using the jira-feature-intake agent.
3. Parse Jira responses into selectable feature options.
4. Start a run with selected feature, agent, and instruction.
5. Build run instructions including step tracking requirements.
6. Launch Copilot CLI in a terminal with workspace-scoped context.
7. Track run and step events in memory and optional NDJSON event files.
8. Render run status, step states, and timeline updates in the webview.
9. Write debug logs to both output channel and workspace log file.

## Key Components
- FlowStore
Maintains run state, applies events, validates step transitions, and supports attaching to event stream files.

- DashboardController
Owns webview lifecycle, message exchange, feature loading state, option synchronization, and UI rendering.

- CLI Integration
Resolves Copilot executable, composes command arguments, executes Jira sample queries, and starts run commands in terminal.

- Parsing Layer
Converts Copilot output (JSON and tolerant text formats) into normalized feature options.

- Logging Layer
Emits timestamped debug logs to Visual Flow output channel and .visual-flow/extension-debug.log.

## Inputs and Outputs
### Inputs
- User selections from dashboard (feature, agent, instruction).
- Copilot CLI output for Jira samples.
- Event stream updates from run JSONL files.

### Outputs
- Webview UI updates for steps, timeline, and feature description.
- Terminal command execution for Copilot runs.
- Event tracking files under .visual-flow.
- Debug logs in output channel and file.

## Run Flow Summary
1. User opens dashboard.
2. Extension requests Jira feature samples.
3. User selects feature and agent.
4. User clicks the **Start Run** button.
5. Extension starts Copilot CLI using the selected feature and instruction, targeting the selected agent (including `flow-orchestrator`).
6. Extension creates prompt/event files and starts Copilot CLI.
7. Event stream updates are applied to run state.
8. Dashboard reflects current status and timeline.

## Constraints and Behavior Notes
- Jira feature loading prefers fresh CLI fetch and falls back to cache only when refresh fails.
- During Jira feature loading, the feature selection control must be blocked in the UI (disabled) until loading completes.
- During Jira feature loading, the user must receive clear visual feedback, including an animated loading status indicator and loading message text in the dashboard.
- After Jira features are loaded and parsed, the feature selection control must be unblocked (re-enabled), and the UI must be updated with the parsed feature options.
- When the selected agent is `flow-orchestrator`, the dashboard must display all workflow steps (Step 1 through Step 9) with their current status during the run.
- Step transitions are guarded by prerequisite checks.
- Dashboard state sync is gated by a webview-ready handshake to avoid message race conditions.
- The extension supports attaching to existing event files for post-hoc run inspection.
- When a feature is selected, the feature description textarea must render the selected feature in this order and structure:
  - id
  - title
  - description
