---
applyTo: "**/*.{java,kt,js,ts,py}"
description: "Use when implementing features with clean architecture boundaries, dependency direction, and separation of business logic from frameworks."
---

# Clean Architecture Rules

- Organize code by architectural boundary: `domain`, `usecase`, `adapter`, and `gateway`.
- Keep business rules in `domain` and `usecase`; do not place business logic in controllers, routes, UI handlers, or persistence implementations.
- Keep dependency direction inward: outer layers may depend on inner layers, but inner layers must not depend on frameworks or delivery mechanisms.
- Define interfaces at the boundary owned by the business flow; implement infrastructure details in outer layers.
- For Java persistence/integration boundaries, name the business-facing interface with the `Repository` suffix and the outer implementation with the `Gateway` suffix.
	- Example: `PersonRepository` for the interface, `PersonGateway` for the implementation.
	- Do not use implementation names ending with `Impl` or technology-specific prefixes/suffixes such as `Jdbc`, `Jpa`, `Mongo`, `Rest`, or `Http`.
	- Place `Repository` interfaces in the business boundary package (typically `usecase`), never in `gateway`.
	- Place `Gateway` implementations only in the outer `gateway` layer.
- Keep controllers and route handlers focused on input/output mapping, validation at the boundary, and delegation to use cases.
- Keep gateways responsible for integration details only, such as databases, external APIs, queues, or file systems.
- Use DTOs or request/response models at layer boundaries instead of leaking framework-specific objects into domain logic.
- Prefer small, focused use cases with explicit inputs, outputs, and error handling.
- Keep entities and value objects framework-agnostic and independent from persistence annotations when possible.
- For Java domain entities/value objects/POJOs, Lombok annotations are allowed and expected per `.github/skills/lombok/SKILL.md`; Lombok usage does not count as framework leakage in this architecture.
- Reflect the architecture in tests: unit-test domain and use cases directly, and isolate adapters and gateways with mocks or integration tests as appropriate.

# Recommended Package Shape

- Prefer package names that mirror the clean architecture layers: `domain`, `usecase`, `adapter`, and `gateway`.
- For Java code, start all packages with `com.adp`.
- Keep Spring bean wiring in a dedicated global `configuration` package; do not mix configuration classes into `domain`, `usecase`, `adapter`, or `gateway`.
- Within a feature or bounded context, prefer this layer ownership:
	- `domain`: entities, value objects, enums, domain exceptions
	- `usecase`: use cases, repository interfaces, commands, queries, responses, business validation helpers
	- `adapter`: controllers, route handlers, transport request models, transport response models
	- `gateway`: repository implementations, external client integrations, persistence mappers, gateway-specific records/entities
- Prefer layer root packages with an entity- or feature-specific subpackage when the feature is substantial, for example `com.adp.domain.client`, `com.adp.usecase.client`, `com.adp.adapter.client`, and `com.adp.gateway.client`.
- When creating a new entity or feature, ensure each layer root package explicitly contains that entity or feature name before the classes for that layer, for example `domain/client/Client.java` and `usecase/client/RegisterClientUseCase.java`.
- If the system is large, group by bounded context first and keep the same inner layer names inside each context.
- Keep shared packages minimal and intentional; do not create broad `common` or `util` packages that bypass the layer boundaries.

# Naming Conventions Across Layers

- Use business names in `domain`, not transport, framework, or persistence terminology.
- Name state-changing use case input models with the `Command` suffix.
- Name read-oriented use case input models with the `Query` suffix when a dedicated object is needed.
- Name use case output models with the `Response` suffix.
- Name transport-layer HTTP models with `Request` and `HttpResponse` suffixes to keep adapter ownership explicit.
- Keep names specific to the feature or entity instead of relying on generic type names.