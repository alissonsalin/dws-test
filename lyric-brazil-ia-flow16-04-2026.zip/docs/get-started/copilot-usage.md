# Copilot Usage

After installation, use Copilot Chat normally in the target repository. The workspace entrypoint loads shared instructions automatically, and the feature workflow is started through the flow-orchestrator agent.

## Example Prompts

1. @flow-orchestrator Start a new feature flow for this requirement source and complete Step 1.
2. @flow-orchestrator Implement this.
3. @tech-refresh-orchestrator Start a migration with prerequisite analysis first, then continue to flow-orchestrator after approval.
4. Update tests according to the testing instruction file.
5. For docs updates, follow documentation rules from .github/instructions.

## How It Works

1. `.github/copilot-instructions.md` acts as the workspace entrypoint.
2. `.github/agents/flow-orchestrator.agent.md` drives the full Step 1 to Step 9 feature workflow through Planner and Coder delegation.
3. `.github/instructions/*.instructions.md` apply automatically when files match their `applyTo` patterns.
4. `.github/skills/*/SKILL.md` are loaded on demand for language-specific implementation baselines and specialized workflows such as CLI remediation and ArchUnit updates.

## Developer References

1. [For developers - Overview](../for-developers/overview.md)
2. [For developers - Clean Architecture](../for-developers/clean-architecture.md)
3. [Technologies - Arch Unit](../technologies/arch-unit.md)
4. [Technologies](../technologies/java.md)
5. [For developers - Unit test](../for-developers/unit-test.md)

## Next Step

If needed, go to [Troubleshooting](troubleshooting.md).