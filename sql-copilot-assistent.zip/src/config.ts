import * as vscode from 'vscode';

export const EXTENSION_NAMESPACE = 'sqlCopilot';

const PASSWORD_SECRET_KEY = 'sqlCopilot.mysqlPassword';
const SETTINGS_STATE_KEY = 'sqlCopilot.connectionSettings';

export interface MysqlConnectionSettings {
  host: string;
  port: number;
  user: string;
  database: string;
  connectionLimit: number;
  maxRows: number;
  useSsl: boolean;
  allowModelGeneratedMutations: boolean;
}

export interface ResolvedMysqlConnectionSettings extends MysqlConnectionSettings {
  password: string;
}

type PersistedMysqlConnectionSettings = Partial<MysqlConnectionSettings>;

export class MysqlConfigStore {
  constructor(private readonly context: vscode.ExtensionContext) {}

  public getSettings(): MysqlConnectionSettings {
    const config = vscode.workspace.getConfiguration(EXTENSION_NAMESPACE);
    const stored = this.getStoredSettings();

    return {
      host: normalizeString(this.getConfiguredValue(config, 'host', 'localhost', stored.host)),
      port: clamp(this.getConfiguredValue(config, 'port', 3306, stored.port), 1, 65535),
      user: normalizeString(this.getConfiguredValue(config, 'user', 'root', stored.user)),
      database: normalizeString(this.getConfiguredValue(config, 'database', '', stored.database)),
      connectionLimit: clamp(this.getConfiguredValue(config, 'connectionLimit', 4, stored.connectionLimit), 1, 20),
      maxRows: clamp(this.getConfiguredValue(config, 'maxRows', 200, stored.maxRows), 1, 1000),
      useSsl: this.getConfiguredValue(config, 'useSsl', false, stored.useSsl),
      allowModelGeneratedMutations: this.getConfiguredValue(config, 'allowModelGeneratedMutations', true, stored.allowModelGeneratedMutations)
    };
  }

  public async resolveSettings(): Promise<{ settings?: ResolvedMysqlConnectionSettings; missing: string[] }> {
    const settings = this.getSettings();
    const password = await this.context.secrets.get(PASSWORD_SECRET_KEY);
    const missing = [
      !settings.host && 'sqlCopilot.host',
      !settings.user && 'sqlCopilot.user',
      !settings.database && 'sqlCopilot.database',
      !password && 'MySQL password'
    ].filter((value): value is string => Boolean(value));

    if (missing.length > 0 || !password) {
      return { missing };
    }

    return {
      settings: {
        ...settings,
        password
      },
      missing: []
    };
  }

  public async promptForPassword(): Promise<boolean> {
    const password = await vscode.window.showInputBox({
      prompt: 'Enter the MySQL password used by SQL Copilot Assistant',
      password: true,
      ignoreFocusOut: true,
      placeHolder: 'MySQL password'
    });

    if (password === undefined) {
      return false;
    }

    await this.context.secrets.store(PASSWORD_SECRET_KEY, password);
    return true;
  }

  public async promptForConnectionSetup(): Promise<boolean> {
    const currentSettings = this.getSettings();
    const existingPassword = await this.context.secrets.get(PASSWORD_SECRET_KEY);

    const host = await vscode.window.showInputBox({
      title: 'SQL Copilot Assistant Setup',
      prompt: 'Enter the MySQL host name',
      ignoreFocusOut: true,
      value: currentSettings.host || 'localhost',
      validateInput: (value) => value.trim().length > 0 ? undefined : 'Host is required.'
    });

    if (host === undefined) {
      return false;
    }

    const portInput = await vscode.window.showInputBox({
      title: 'SQL Copilot Assistant Setup',
      prompt: 'Enter the MySQL port',
      ignoreFocusOut: true,
      value: String(currentSettings.port),
      validateInput: (value) => validatePort(value)
    });

    if (portInput === undefined) {
      return false;
    }

    const user = await vscode.window.showInputBox({
      title: 'SQL Copilot Assistant Setup',
      prompt: 'Enter the MySQL user name',
      ignoreFocusOut: true,
      value: currentSettings.user || 'root',
      validateInput: (value) => value.trim().length > 0 ? undefined : 'User is required.'
    });

    if (user === undefined) {
      return false;
    }

    const database = await vscode.window.showInputBox({
      title: 'SQL Copilot Assistant Setup',
      prompt: 'Enter the default MySQL database name',
      ignoreFocusOut: true,
      value: currentSettings.database,
      validateInput: (value) => value.trim().length > 0 ? undefined : 'Database is required.'
    });

    if (database === undefined) {
      return false;
    }

    const sslSelection = await vscode.window.showQuickPick([
      { label: 'No SSL', value: false },
      { label: 'Use SSL', value: true }
    ], {
      title: 'SQL Copilot Assistant Setup',
      placeHolder: 'Choose whether the MySQL connection should use SSL',
      ignoreFocusOut: true
    });

    if (!sslSelection) {
      return false;
    }

    const password = await vscode.window.showInputBox({
      title: 'SQL Copilot Assistant Setup',
      prompt: 'Enter the MySQL password',
      password: true,
      ignoreFocusOut: true,
      value: existingPassword,
      validateInput: (value) => value.length > 0 ? undefined : 'Password is required.'
    });

    if (password === undefined) {
      return false;
    }

    await this.context.globalState.update(SETTINGS_STATE_KEY, {
      host: host.trim(),
      port: Number(portInput),
      user: user.trim(),
      database: database.trim(),
      useSsl: sslSelection.value,
      connectionLimit: currentSettings.connectionLimit,
      maxRows: currentSettings.maxRows,
      allowModelGeneratedMutations: currentSettings.allowModelGeneratedMutations
    } satisfies PersistedMysqlConnectionSettings);
    await this.context.secrets.store(PASSWORD_SECRET_KEY, password);

    return true;
  }

  public async promptForDatabase(): Promise<boolean> {
    const currentSettings = this.getSettings();
    const database = await vscode.window.showInputBox({
      title: 'SQL Copilot Assistant',
      prompt: 'Enter the default MySQL database name',
      ignoreFocusOut: true,
      value: currentSettings.database,
      validateInput: (value) => value.trim().length > 0 ? undefined : 'Database is required.'
    });

    if (database === undefined) {
      return false;
    }

    await this.context.globalState.update(SETTINGS_STATE_KEY, {
      ...this.getStoredSettings(),
      database: database.trim()
    } satisfies PersistedMysqlConnectionSettings);

    return true;
  }

  public async clearPassword(): Promise<void> {
    await this.context.secrets.delete(PASSWORD_SECRET_KEY);
  }

  private getStoredSettings(): PersistedMysqlConnectionSettings {
    return this.context.globalState.get<PersistedMysqlConnectionSettings>(SETTINGS_STATE_KEY, {});
  }

  private getConfiguredValue<T>(
    config: vscode.WorkspaceConfiguration,
    key: string,
    defaultValue: T,
    storedValue: T | undefined
  ): T {
    const inspected = config.inspect<T>(key);
    const configuredValue = inspected?.workspaceFolderLanguageValue
      ?? inspected?.workspaceFolderValue
      ?? inspected?.workspaceLanguageValue
      ?? inspected?.workspaceValue
      ?? inspected?.globalLanguageValue
      ?? inspected?.globalValue;

    if (configuredValue !== undefined) {
      return config.get<T>(key, defaultValue);
    }

    if (storedValue !== undefined) {
      return storedValue;
    }

    return defaultValue;
  }
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

function normalizeString(value: string): string {
  return value.trim();
}

function validatePort(value: string): string | undefined {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 1 || parsed > 65535) {
    return 'Port must be an integer between 1 and 65535.';
  }

  return undefined;
}