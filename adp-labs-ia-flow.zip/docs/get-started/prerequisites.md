# Prerequisites

Before installing the instruction pack, make sure you have:

1. One supported IDE:
   - Visual Studio Code with GitHub Copilot and Copilot Chat extensions enabled.
   - IntelliJ IDEA with the GitHub Copilot plugin enabled.
2. GitHub authentication completed in your IDE so Copilot Chat can run.
3. Access to this repository, including the installer scripts.
4. A target repository where you want the instructions applied.

## Next Step

Go to [Installation](installation.md).