# ADP Labs GEN AI Documentation

## Overview
This GEN AI feature workflow is end-to-end process that starts by clarifying requirements, then designing the solution architecture, breaking work into testable user stories, implementing with clean architecture and strong engineering practices, validating security and dependencies, creating comprehensive unit tests with coverage, comparing implementation against requirements to close gaps, troubleshooting and documenting issues with production monitoring guidance, and finally capturing continuous improvements and lessons learned so future feature delivery becomes faster, safer, and more consistent.

<div class="grid cards" markdown>

-   :material-clock-fast:{ .lg .middle } __Quick setup__

    ---

    Follow simple steps to start using this solution

    [:octicons-arrow-right-24: Getting started](get-started.md)

-   :octicons-workflow-24:{ .lg .middle } __Follow the flow__

    ---

    Focus on your content and generate a responsive and searchable static site

    [:octicons-arrow-right-24: Reference](flow/flow.md)

-   :material-account-group-outline:{ .lg .middle } __For developers__

    ---

    Explore architecture, standards, and implementation guidance

    [:octicons-arrow-right-24: Open guide](for-developers/overview.md)

-   :octicons-comment-discussion-24:{ .lg .middle } __Copilot chat usage__

    ---

    Learn how to use Copilot Chat effectively in this workflow

    [:octicons-arrow-right-24: Open guide](copilot-chat-usage.md)


</div>

