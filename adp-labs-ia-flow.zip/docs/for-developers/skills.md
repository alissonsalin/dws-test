# Skills

## Purpose

This page documents the on-demand skills used in this repository. Skills are loaded only for specialized tasks so they do not consume context in every session.

## When To Use Skills

Use a skill when you need:

- a focused workflow for a narrow task
- reusable guidance that should remain opt-in
- specialized remediation, validation, or test patterns
- support material that complements agents and instructions instead of replacing them

## Skills in This Repository

### `.github/skills/cli-resilience/SKILL.md`

- Covers command preflight checks.
- Enforces fix-driven retries instead of unchanged reruns.
- Captures concise failure details for later reuse.
- Fits command recovery and validation workflows.

### `.github/skills/archunit/SKILL.md`

- Covers Java architecture boundary tests.
- Focuses on ArchUnit structure, layer rules, and test placement.
- Fits Java feature changes that affect clean architecture boundaries.

## Relationship To Other Customizations

1. Skills are not always-on; they are loaded only when the task calls for them.
2. Agents orchestrate workflows, while skills support specialized sub-workflows.
3. Instructions remain the source of truth for scoped, automatically applied rules.

## Selection Guidance

- Use instructions for broad, file-pattern-based rules.
- Use agents for multi-step workflow execution.
- Use skills for narrow, reusable expertise that should stay opt-in.

## Related References

- [Custom Instructions](custom-instructions.md)
- [Agents](agents.md)
- [Arch Unit](arch-unit.md)
- [Unit test](unit-test.md)