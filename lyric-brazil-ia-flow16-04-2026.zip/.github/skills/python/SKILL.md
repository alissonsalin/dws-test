---
name: python
description: "Use when explicitly starting Python feature implementation. Covers Python clean architecture structure, validation boundaries, testing expectations, and runtime quality rules for this project."
argument-hint: "Describe the Python feature, affected layers, and whether API or integration code is involved"
---

# Python Implementation Rules

- Follow clean architecture boundaries: domain, usecase, adapter, gateway.
- Keep business logic in domain and usecase layers, not in API or route handlers.
- Keep adapters focused on boundary mapping, validation at boundaries, and delegation.
- Use dependency injection patterns appropriate for Python modules and services.
- Prefer explicit types for core business interfaces and DTOs where practical.

# Project Structure and Code Quality

- Organize Python code under architecture-first folders such as `src/domain`, `src/usecase`, `src/adapter`, and `src/gateway` when applicable.
- Keep modules small and cohesive, use clear names for commands, queries, and use cases, and follow the project's existing linting and formatting tools.

# Reliability and Security

- Validate and sanitize external input at boundaries.
- Never log secrets or sensitive payloads.
- Use environment variables for configuration and secrets.
- Add request timeouts and retry or circuit-breaker logic for external integrations when needed.

# Testing Expectations

- Cover happy paths, error paths, and edge cases, isolate business logic with mocks or fakes at external boundaries, keep tests deterministic and diagnosable, and update tests whenever behavior or API contracts change.

# Command Resilience

- For Python command execution behavior, follow `.github/skills/node-python-cli/SKILL.md` and `.github/instructions/command-resilience.instructions.md`.