# Workflow Gates

Copilot must stop and ask at specific gates instead of assuming.

## Mandatory Gates

1. Design approval gate before implementation.
   - Copilot must not implement code before Step 2 technical design approval is explicitly recorded.
2. Step 5 CVE gate.
   - In normal interactive mode, Copilot must ask whether to run CVE validation before executing CVE commands.
   - In autonomous shortcut mode such as `Implement this`, Copilot may default CVE validation to yes and record that decision.
   - If answer is no, CVE is skipped and the decision is recorded.
   - If answer is yes, CVE flow runs per command policy.
   - If answer is unclear, Copilot asks again and keeps Step 5 in progress.
3. Destructive or ambiguous operations.
   - Copilot should pause for explicit confirmation before destructive or ambiguous actions.
4. Java version ambiguity gate.
   - If Java detection output is ambiguous, Copilot must ask for explicit version confirmation.

## Checklist Visibility

When a feature workflow starts, Copilot should continuously show a full checklist with one status per step.

Status icons:

1. ✅ completed
2. 🔄 in-progress
3. ⏳ pending
4. ❌ failed or blocker
5. ⏭ skipped

Copilot should also provide short progress updates while it works, then summarize what changed, what passed, and what remains.

## Next

Continue to [Command Behavior](command-behavior.md).