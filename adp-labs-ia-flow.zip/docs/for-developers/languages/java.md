# Java

## Purpose

Define Java-specific implementation standards used in this repository.

## Core Technical Stack

1. Java 21+
2. Spring Boot application model
3. Clean architecture package boundaries
4. ArchUnit for architecture constraints
5. JUnit + Mockito for behavior tests

## Key Expectations

- Java 21 or higher.
- Clean architecture boundaries (`domain`, `usecase`, `adapter`, `gateway`).
- Spring rules from dedicated Spring instruction file.
- Constructor-based dependency injection.
- Architecture tests with ArchUnit for boundary enforcement.

## Spring Configuration Model

- Use YAML configuration files:
	- `application.yml` (shared defaults)
	- `application-development.yml` (development profile)
	- `src/test/resources/application-test.yml` (test profile)
- Keep environment-specific values outside business logic.

## Dependency Injection Model

- Always use constructor injection.
- Do not use `@Autowired` for bean injection.
- Keep controllers thin, use use-case services for orchestration.

## Persistence Boundary Pattern

- Define repository interfaces in `usecase` or business-facing boundary modules.
- Implement them in `gateway`.
- Prefer JDBC-based access patterns unless explicitly overridden.

## Java Command Guidance

- Run `java -version` (Windows) or `java --version` (macOS/Linux) exactly once at Step 4 start.
- Do not rerun Java detection later unless explicitly requested.
- Use the approved Gradle verification command from Java CLI instructions.

## Testing Model

- Unit tests: JUnit + Mockito (`@ExtendWith(MockitoExtension.class)`).
- Spring slice tests: `@MockBean` for Spring-managed collaborator replacement.
- Architecture tests: ArchUnit enforcing layer boundaries.
- Coverage reports: generate JaCoCo HTML report after unit tests (`test jacocoTestReport`).

## Related Flow Steps

- [Step 4 - Start Implementation](../../flow/step-4.md)
- [Step 5 - Security Validation](../../flow/step-5.md)
- [Step 6 - Create Unit Tests](../../flow/step-6.md)
