import mysql, { Pool, PoolOptions, ResultSetHeader, RowDataPacket } from 'mysql2/promise';

import { ResolvedMysqlConnectionSettings } from './config';

export interface SchemaColumn {
  tableName: string;
  columnName: string;
  dataType: string;
  columnType: string;
  isNullable: boolean;
  columnKey: string;
  columnDefault: unknown;
  extra: string;
  ordinalPosition: number;
}

export interface SchemaTable {
  name: string;
  engine: string | null;
  estimatedRows: number | null;
  columns: SchemaColumn[];
}

export interface ForeignKeyInfo {
  tableName: string;
  columnName: string;
  referencedTableName: string;
  referencedColumnName: string;
}

export interface SchemaSummary {
  database: string;
  tables: SchemaTable[];
  foreignKeys: ForeignKeyInfo[];
  rawSummary: string;
}

export interface QueryResultRows {
  kind: 'rows';
  sql: string;
  columns: string[];
  rows: Record<string, unknown>[];
  displayedRowCount: number;
  totalRowCount: number;
}

export interface QueryResultMutation {
  kind: 'mutation';
  sql: string;
  affectedRows: number;
  insertId: number;
  warningStatus: number;
}

export type QueryExecutionResult = QueryResultRows | QueryResultMutation;

export class MysqlService {
  private pool?: Pool;
  private poolKey?: string;
  private schemaCache?: SchemaSummary;
  private schemaCacheKey?: string;

  public async dispose(): Promise<void> {
    const currentPool = this.pool;
    this.pool = undefined;
    this.poolKey = undefined;
    this.schemaCache = undefined;
    this.schemaCacheKey = undefined;

    if (currentPool) {
      await currentPool.end();
    }
  }

  public async ping(settings: ResolvedMysqlConnectionSettings): Promise<void> {
    const pool = await this.getPool(settings);
    await pool.query('SELECT 1');
  }

  public async getSchemaSummary(settings: ResolvedMysqlConnectionSettings, forceRefresh = false): Promise<SchemaSummary> {
    const cacheKey = this.createConnectionKey(settings);
    if (!forceRefresh && this.schemaCache && this.schemaCacheKey === cacheKey) {
      return this.schemaCache;
    }

    const pool = await this.getPool(settings);
    const [tableRows] = await pool.query<RowDataPacket[]>(
      `
        SELECT TABLE_NAME AS tableName, ENGINE AS engine, TABLE_ROWS AS estimatedRows
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = ?
        ORDER BY TABLE_NAME
      `,
      [settings.database]
    );

    const [columnRows] = await pool.query<RowDataPacket[]>(
      `
        SELECT
          TABLE_NAME AS tableName,
          COLUMN_NAME AS columnName,
          DATA_TYPE AS dataType,
          COLUMN_TYPE AS columnType,
          IS_NULLABLE AS isNullable,
          COLUMN_KEY AS columnKey,
          COLUMN_DEFAULT AS columnDefault,
          EXTRA AS extra,
          ORDINAL_POSITION AS ordinalPosition
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ?
        ORDER BY TABLE_NAME, ORDINAL_POSITION
      `,
      [settings.database]
    );

    const [foreignKeyRows] = await pool.query<RowDataPacket[]>(
      `
        SELECT
          TABLE_NAME AS tableName,
          COLUMN_NAME AS columnName,
          REFERENCED_TABLE_NAME AS referencedTableName,
          REFERENCED_COLUMN_NAME AS referencedColumnName
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
        WHERE TABLE_SCHEMA = ?
          AND REFERENCED_TABLE_NAME IS NOT NULL
        ORDER BY TABLE_NAME, COLUMN_NAME
      `,
      [settings.database]
    );

    const columnMap = new Map<string, SchemaColumn[]>();
    for (const row of columnRows) {
      const tableName = String(row.tableName);
      const entry: SchemaColumn = {
        tableName,
        columnName: String(row.columnName),
        dataType: String(row.dataType),
        columnType: String(row.columnType),
        isNullable: String(row.isNullable).toUpperCase() === 'YES',
        columnKey: String(row.columnKey ?? ''),
        columnDefault: row.columnDefault,
        extra: String(row.extra ?? ''),
        ordinalPosition: Number(row.ordinalPosition)
      };

      const bucket = columnMap.get(tableName) ?? [];
      bucket.push(entry);
      columnMap.set(tableName, bucket);
    }

    const tables: SchemaTable[] = tableRows.map((row) => ({
      name: String(row.tableName),
      engine: row.engine ? String(row.engine) : null,
      estimatedRows: row.estimatedRows === null ? null : Number(row.estimatedRows),
      columns: columnMap.get(String(row.tableName)) ?? []
    }));

    const foreignKeys: ForeignKeyInfo[] = foreignKeyRows.map((row) => ({
      tableName: String(row.tableName),
      columnName: String(row.columnName),
      referencedTableName: String(row.referencedTableName),
      referencedColumnName: String(row.referencedColumnName)
    }));

    const summary: SchemaSummary = {
      database: settings.database,
      tables,
      foreignKeys,
      rawSummary: formatSchemaSummary(settings.database, tables, foreignKeys)
    };

    this.schemaCache = summary;
    this.schemaCacheKey = cacheKey;

    return summary;
  }

  public async runReadOnlyQuery(settings: ResolvedMysqlConnectionSettings, sql: string): Promise<QueryResultRows> {
    const normalizedSql = normalizeSql(sql);
    ensureSingleStatement(normalizedSql);
    ensureReadOnlySql(normalizedSql);

    const pool = await this.getPool(settings);
    const [rows] = await pool.query<RowDataPacket[]>(normalizedSql);
    const serializedRows = rows.map((row) => ({ ...row })) as Record<string, unknown>[];
    const columns = serializedRows.length > 0
      ? Object.keys(serializedRows[0])
      : [];
    const displayedRows = serializedRows.slice(0, settings.maxRows);

    return {
      kind: 'rows',
      sql: normalizedSql,
      columns,
      rows: displayedRows,
      displayedRowCount: displayedRows.length,
      totalRowCount: serializedRows.length
    };
  }

  public async runMutation(settings: ResolvedMysqlConnectionSettings, sql: string): Promise<QueryResultMutation> {
    const normalizedSql = normalizeSql(sql);
    ensureSingleStatement(normalizedSql);
    ensureMutationSql(normalizedSql);

    const pool = await this.getPool(settings);
    const [result] = await pool.execute<ResultSetHeader>(normalizedSql);

    return {
      kind: 'mutation',
      sql: normalizedSql,
      affectedRows: result.affectedRows,
      insertId: result.insertId,
      warningStatus: result.warningStatus
    };
  }

  private async getPool(settings: ResolvedMysqlConnectionSettings): Promise<Pool> {
    const key = this.createConnectionKey(settings);
    if (this.pool && this.poolKey === key) {
      return this.pool;
    }

    await this.dispose();

    const poolOptions: PoolOptions = {
      host: settings.host,
      port: settings.port,
      user: settings.user,
      password: settings.password,
      database: settings.database,
      connectionLimit: settings.connectionLimit,
      waitForConnections: true,
      namedPlaceholders: false,
      ssl: settings.useSsl ? {} : undefined
    };

    this.pool = mysql.createPool(poolOptions);
    this.poolKey = key;
    return this.pool;
  }

  private createConnectionKey(settings: ResolvedMysqlConnectionSettings): string {
    return JSON.stringify({
      host: settings.host,
      port: settings.port,
      user: settings.user,
      database: settings.database,
      useSsl: settings.useSsl
    });
  }
}

function normalizeSql(sql: string): string {
  return sql.trim().replace(/;+\s*$/, '');
}

function ensureSingleStatement(sql: string): void {
  if (sql.includes(';')) {
    throw new Error('Only a single SQL statement is allowed.');
  }
}

function ensureReadOnlySql(sql: string): void {
  const lowered = sql.trim().toLowerCase();
  const isReadOnly = /^(select|show|describe|desc|explain)\b/.test(lowered)
    || (/^with\b/.test(lowered) && /\bselect\b/.test(lowered));

  if (!isReadOnly) {
    throw new Error('Only read-only SQL statements are allowed for immediate execution.');
  }

  if (/\b(insert|update|delete|alter|drop|truncate|create|grant|revoke|rename)\b/.test(lowered)) {
    throw new Error('Read-only execution blocked because the SQL contains a mutating or administrative keyword.');
  }
}

function ensureMutationSql(sql: string): void {
  const lowered = sql.trim().toLowerCase();
  const isMutation = /^(insert|update|delete|alter|drop|truncate)\b/.test(lowered);

  if (!isMutation) {
    throw new Error('Only INSERT, UPDATE, DELETE, ALTER, DROP, and TRUNCATE statements can be applied as staged write operations.');
  }

  if (/\b(create|grant|revoke|rename)\b/.test(lowered)) {
    throw new Error('CREATE, GRANT, REVOKE, and RENAME statements are blocked.');
  }
}

function formatSchemaSummary(database: string, tables: SchemaTable[], foreignKeys: ForeignKeyInfo[]): string {
  const lines: string[] = [`Database: ${database}`, `Tables: ${tables.length}`];

  for (const table of tables) {
    const columnFragments = table.columns.map((column) => {
      const keyPart = column.columnKey ? ` ${column.columnKey}` : '';
      const nullablePart = column.isNullable ? ' nullable' : ' not-null';
      const extraPart = column.extra ? ` ${column.extra}` : '';
      return `${column.columnName} ${column.columnType}${nullablePart}${keyPart}${extraPart}`.trim();
    });

    lines.push(`- ${table.name}${table.engine ? ` [${table.engine}]` : ''}${table.estimatedRows !== null ? ` rows~${table.estimatedRows}` : ''}`);
    if (columnFragments.length > 0) {
      lines.push(`  columns: ${columnFragments.join(', ')}`);
    }
  }

  if (foreignKeys.length > 0) {
    lines.push('Foreign keys:');
    for (const fk of foreignKeys) {
      lines.push(`- ${fk.tableName}.${fk.columnName} -> ${fk.referencedTableName}.${fk.referencedColumnName}`);
    }
  }

  return lines.join('\n');
}