---
name: java-cli
description: "Run Java workflow commands with repository-approved Java version detection, Gradle Wrapper preference, and implementation-time timing rules. Use when starting Java implementation or build/test verification."
argument-hint: "Describe the Java workflow phase, command goal, and any current command failure"
---

# Java Command Execution Rules

## When to Use

- Java implementation is starting.
- You need to choose or run a Java build or test command.
- You need the repository-approved Java version detection flow.

## Command Selection Rules

- Prefer Gradle Wrapper over system Gradle, run from the project root unless another path is required, keep commands minimal, avoid destructive actions unless requested, and prefer non-interactive variants.

## Commands by Phase

- For new Java projects, or when the project is not yet buildable, add or update required `build.gradle` or `build.gradle.kts` dependencies and plugins during implementation setup.
- Complete framework bootstrap and required dependency setup before running validation or verification commands.
- If missing dependencies or plugins are the reason a command would fail, fix the build configuration first instead of discovering the gap later.
- Treat dependency or plugin changes during implementation as the trigger for dependency-security validation.
- During implementation setup, inspect `build.gradle` or `build.gradle.kts` for Lombok configuration before implementing Java classes. If Lombok is missing, add it immediately so DTOs, entities, commands, responses, and value objects use the Lombok conventions required by this repository.
- When security validation is required, use `.github/skills/security/SKILL.md` for approved Java command selection and plugin setup expectations.
- For new Java projects, or when Java coverage setup changes, follow `.github/skills/jacoco/SKILL.md` for required JaCoCo plugin, task, verification, and lifecycle expectations.

## Approved Java Test Commands

- Use Gradle Wrapper as the default Java test runner for this repository.

## Java Environment Inspection

- Windows: `java -version`
- macOS and Linux: `java --version`
- Run this inspection exactly once at the start of implementation for each Java feature workflow.
- Do not run the inspection again later unless the user explicitly requests it.
- Parse the first version token into a major Java version.
- If the detected major version is 21 or higher, use that detected major version for project Java configuration.
- If the detected major version is lower than 21, configure the project to Java 21 and note that local JDK upgrade is required for runtime execution.
- If parsing fails or output is ambiguous, ask for explicit version confirmation before changing Java version settings.

## Retry and Reporting

- Follow `.github/instructions/command-resilience.instructions.md` for shared preflight checks, retry behavior, and failure reporting.
- Summarize results in plain language after execution.
- Highlight only the relevant lines: pass/fail status, errors, warnings, and artifact paths.