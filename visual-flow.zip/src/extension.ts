import * as vscode from "vscode";
import { randomUUID } from "crypto";
import { DashboardController } from "./steps/dashboardController";
import { FlowStore } from "./steps/flowStore";
import {
  buildInstruction,
  buildRunCommandTemplate,
  loadFeaturesFromJiraAgent,
  resolveRunCommand,
  resolveCopilotExecutable,
  resolveTerminalName
} from "./steps/copilot";
import { constants as fsConstants, promises as fs } from "fs";
import * as path from "path";
import {
  DEFAULT_FEATURE_OPTIONS,
  FLOW_ORCHESTRATOR_AGENT,
  Logger,
  StartRunRequest,
  quoteForDoubleQuotedShellArg,
  parseLineToWireEvent
} from "./steps/shared";

let pendingLogsFileWatcher: vscode.FileSystemWatcher | undefined;
let runArtifactWatchers: vscode.Disposable[] = [];
let runTimelineEventKeys = new Set<string>();

export function activate(context: vscode.ExtensionContext): void {
  const outputChannel = vscode.window.createOutputChannel("Visual Flow");
  const workspaceRootPath = resolveWorkspaceRootPath();
  const logger = new Logger(outputChannel, workspaceRootPath);
  const flowStore = new FlowStore(logger);

  const dashboard = new DashboardController(
    context,
    logger,
    flowStore,
    async (payload) => {
      await startRun(payload, workspaceRootPath, flowStore, dashboard, logger);
    },
    async () => {
      await loadFeatureOptions(workspaceRootPath, logger, dashboard);
    },
    workspaceRootPath
  );

  const openDashboardDisposable = vscode.commands.registerCommand("visualFlow.openDashboard", async () => {
    await dashboard.show();
  });

  const loadFeaturesDisposable = vscode.commands.registerCommand("visualFlow.loadFeatures", async () => {
    await dashboard.show();
    await loadFeatureOptions(workspaceRootPath, logger, dashboard);
  });

  const startRunDisposable = vscode.commands.registerCommand("visualFlow.startRun", async () => {
    await dashboard.show();
    const features = dashboard.getFeatures();
    const hasValidFeatures = features.some((feature) => feature.value !== DEFAULT_FEATURE_OPTIONS[0].value);
    if (!hasValidFeatures) {
      await loadFeatureOptions(workspaceRootPath, logger, dashboard);
    }
  });

  const receiveEventDisposable = vscode.commands.registerCommand("visualFlow.receiveEvent", async (rawEvent: unknown) => {
    if (!rawEvent) {
      return;
    }
    if (typeof rawEvent === "string") {
      flowStore.recordEvent(parseLineToWireEvent(rawEvent));
      return;
    }
    try {
      flowStore.recordEvent(parseLineToWireEvent(JSON.stringify(rawEvent)));
    } catch (error) {
      logger.log("Failed to parse raw event from command input.", { error: String(error), rawEvent });
    }
  });

  context.subscriptions.push(
    outputChannel,
    flowStore,
    dashboard,
    openDashboardDisposable,
    loadFeaturesDisposable,
    startRunDisposable,
    receiveEventDisposable
  );

  void dashboard.show();
}

export function deactivate(): void {
  // No-op. VS Code disposes all registered subscriptions.
}

async function loadFeatureOptions(
  workspaceRootPath: string | undefined,
  logger: Logger,
  dashboard: DashboardController
): Promise<void> {
  dashboard.setFeatureLoading(true);
  dashboard.setFeatureError("");
  try {
    const features = await loadFeaturesFromJiraAgent(workspaceRootPath, logger);
    dashboard.setFeatures(features);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    logger.log("Feature loading failed.", { message });
    dashboard.setFeatures([...DEFAULT_FEATURE_OPTIONS]);
    dashboard.setFeatureError(message);
  } finally {
    dashboard.setFeatureLoading(false);
  }
}

async function startRun(
  request: StartRunRequest,
  workspaceRootPath: string | undefined,
  flowStore: FlowStore,
  dashboard: DashboardController,
  logger: Logger
): Promise<void> {
  const feature = dashboard.getFeatures().find((entry) => entry.value === request.featureValue);
  if (!feature || feature.value === DEFAULT_FEATURE_OPTIONS[0].value) {
    throw new Error("Select a valid Jira feature before starting the run.");
  }

  const runId = randomUUID();
  const destinationPath = workspaceRootPath ?? vscode.workspace.workspaceFolders?.[0]?.uri.fsPath ?? "";
  if (!destinationPath) {
    throw new Error("Open a workspace folder before starting a run.");
  }

  const defaultInstruction = buildInstruction(feature.id, feature.title, feature.description, request.selectedAgent);
  const instruction = request.instruction?.trim().length
    ? `${defaultInstruction}\n\nAdditional run instruction:\n${request.instruction.trim()}`
    : defaultInstruction;

  flowStore.startRun(runId, feature, request.selectedAgent, instruction, destinationPath);

  clearPendingLogsFileWatcher();
  clearRunArtifactWatchers();
  runTimelineEventKeys.clear();
  dashboard.stopLogsWatcher();

  // Watch logs/logs.md only. visual-log owns file creation and writes.
  if (request.selectedAgent === FLOW_ORCHESTRATOR_AGENT) {
    const logsFilePath = path.join(destinationPath, "logs", "logs.md");
    void startLogsWatcherWhenFileExists(logsFilePath, dashboard, logger);
  }

  const executable = await resolveCopilotExecutable(workspaceRootPath);
  const workspaceConfiguration = vscode.workspace.getConfiguration();
  const terminalName = resolveTerminalName(workspaceConfiguration);
  const terminal = resolveRunTerminal(terminalName);
  const escapedAgent = quoteForDoubleQuotedShellArg(request.selectedAgent);
  const escapedInstruction = quoteForDoubleQuotedShellArg(instruction);
  const escapedWorkspace = quoteForDoubleQuotedShellArg(destinationPath);
  const runCommandTemplate = buildRunCommandTemplate(workspaceConfiguration, executable, request.selectedAgent, instruction);
  let runCommand = resolveRunCommand(runCommandTemplate, {
    copilotExecutable: executable.commandForTemplate,
    agent: escapedAgent,
    prompt: escapedInstruction,
    workspace: escapedWorkspace
  });

  if (!/\s--stream\s+off(\s|$)/.test(runCommand)) {
    runCommand += " --stream off";
  }

  setupRunArtifactWatchers(destinationPath, flowStore, logger);

  terminal.show(true);
  terminal.sendText(runCommand, true);
}

function resolveWorkspaceRootPath(): string | undefined {
  return vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
}

async function startLogsWatcherWhenFileExists(
  logsFilePath: string,
  dashboard: DashboardController,
  logger: Logger
): Promise<void> {
  const logsDir = path.dirname(logsFilePath);
  const logsFileName = path.basename(logsFilePath);

  const startReader = (): void => {
    clearPendingLogsFileWatcher();
    logger.log("Logs file detected. Starting watcher.", { logsFilePath });
    dashboard.startLogsWatcher(logsFilePath);
  };

  try {
    await fs.access(logsFilePath, fsConstants.R_OK);
    startReader();
    return;
  } catch {
    // Expected when visual-log has not created the file yet.
  }

  pendingLogsFileWatcher = vscode.workspace.createFileSystemWatcher(
    new vscode.RelativePattern(logsDir, logsFileName)
  );

  pendingLogsFileWatcher.onDidCreate(() => startReader());
  pendingLogsFileWatcher.onDidChange(() => startReader());
  pendingLogsFileWatcher.onDidDelete(() => {
    logger.log("Logs file deleted before watcher activation.", { logsFilePath });
  });

  logger.log("Waiting for visual-log to create logs file before reading.", { logsFilePath });
}

function clearPendingLogsFileWatcher(): void {
  if (!pendingLogsFileWatcher) {
    return;
  }
  pendingLogsFileWatcher.dispose();
  pendingLogsFileWatcher = undefined;
}

function setupRunArtifactWatchers(
  destinationPath: string,
  flowStore: FlowStore,
  logger: Logger
): void {
  clearRunArtifactWatchers();

  const patterns = ["documentation/**/*.md", "improvements/*.md", "README.md"];
  runArtifactWatchers = patterns.map((pattern) => createArtifactWatcher(pattern, destinationPath, flowStore, logger));
}

function clearRunArtifactWatchers(): void {
  for (const watcher of runArtifactWatchers) {
    watcher.dispose();
  }
  runArtifactWatchers = [];
}

function createArtifactWatcher(
  pattern: string,
  destinationPath: string,
  flowStore: FlowStore,
  logger: Logger
): vscode.Disposable {
  const watcher = vscode.workspace.createFileSystemWatcher(
    new vscode.RelativePattern(destinationPath, pattern)
  );

  const onCreate = watcher.onDidCreate((uri) => {
    emitArtifactTimelineEvent("artifact-created", uri, destinationPath, flowStore, logger);
  });

  const onChange = watcher.onDidChange((uri) => {
    emitArtifactTimelineEvent("artifact-updated", uri, destinationPath, flowStore, logger);
  });

  return new vscode.Disposable(() => {
    onCreate.dispose();
    onChange.dispose();
    watcher.dispose();
  });
}

function emitArtifactTimelineEvent(
  eventType: "artifact-created" | "artifact-updated",
  uri: vscode.Uri,
  destinationPath: string,
  flowStore: FlowStore,
  logger: Logger
): void {
  const absolutePath = uri.fsPath;
  const relativePath = path.relative(destinationPath, absolutePath);
  const displayPath = relativePath && !relativePath.startsWith("..")
    ? relativePath.replace(/\\/g, "/")
    : absolutePath;

  const label = eventType === "artifact-created" ? "Created" : "Updated";
  emitUniqueTimelineEvent(flowStore, {
    timestamp: new Date().toISOString(),
    type: eventType,
    owner: "extension",
    level: "info",
    message: `${label} ${displayPath}`
  });

  logger.log("Timeline artifact event captured from file watcher.", {
    eventType,
    path: displayPath
  });
}

function emitUniqueTimelineEvent(flowStore: FlowStore, event: {
  timestamp: string;
  type: string;
  owner: string;
  level: "info" | "warn" | "error";
  message: string;
}): void {
  const key = `${event.type}|${event.owner}|${event.message}`.toLowerCase();
  if (runTimelineEventKeys.has(key)) {
    return;
  }

  runTimelineEventKeys.add(key);
  flowStore.recordEvent(event);
}

function resolveRunTerminal(terminalName: string): vscode.Terminal {
  const active = vscode.window.activeTerminal;
  if (active) {
    return active;
  }
  const existingByName = vscode.window.terminals.find((terminal) => terminal.name === terminalName);
  if (existingByName) {
    return existingByName;
  }
  return vscode.window.createTerminal({ name: terminalName });
}
