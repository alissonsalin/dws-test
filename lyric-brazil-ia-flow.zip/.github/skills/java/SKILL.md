---
name: java
description: "Use when explicitly starting Java feature implementation. Covers Java package structure, naming conventions, repository and gateway placement, Java 21 baseline, and implementation rules for this project."
argument-hint: "Describe the Java feature, affected layers, and whether Spring, Lombok, or HTTP APIs are involved"
---

# Java Implementation Rules

- Follow clean architecture boundaries: domain, usecase, adapter, gateway.
- Keep business logic in use cases and domain, not controllers.
- Keep controllers focused on input/output mapping and delegation.
- Use the feature entity name as a class-name prefix for Java classes in `gateway`, controller/adapter, and `usecase` layers.
  - Examples for entity `Client`: `ClientController`, `ClientRepository`, `ClientGateway`, `RegisterClientUseCase`, `ClientCommand`, `ClientResponse`.
  - Use `Repository` for the business-facing interface and `Gateway` for the concrete outer-layer implementation.
  - Keep `Repository` interfaces in `usecase` boundary packages.
  - Keep `Gateway` implementations in `gateway` packages.
  - Do not create generic names like `Controller`, `Repository`, `Gateway`, `UseCase`, or names ending with `Impl` without the entity prefix.
  - Do not use implementation names with technology-specific prefixes or suffixes such as `JdbcClientGateway`, `ClientGatewayJdbc`, `JpaClientGateway`, or `RestClientGateway`.
- Standardize a reusable command-response mapping pattern for controller-to-usecase boundaries to reduce duplicate mapping code.
- Introduce shared validation helpers in the `usecase` package for common API field checks and consistent validation errors.
- Use constructor-based dependency injection.
- Use Java 21 or superior language level.
- For Java entity and DTO classes, follow `.github/skills/lombok/SKILL.md` for Lombok annotations. Lombok is mandatory for all DTOs, entities, commands, and responses if Lombok is present in the project. Do not use Java `record` classes for these types.
- For Java domain POJOs/value objects, also apply Lombok conventions from `.github/skills/lombok/SKILL.md` when Lombok is present in the project.
- Follow `.github/skills/spring/SKILL.md` for Spring Boot framework conventions, REST structure, and required Spring YAML configuration files.
- Follow `.github/skills/archunit/SKILL.md` for Java architecture test requirements that enforce `domain`, `usecase`, `adapter`, and `gateway` boundaries.
- Follow `.github/skills/java-cli/SKILL.md` for Java environment inspection and command timing.
- Follow `.github/skills/jacoco/SKILL.md` for Java coverage configuration, verification rules, and JaCoCo report expectations.
  - Run the OS-specific Java detection command exactly once at the start of Step 4 implementation for each Java feature implementation workflow.
  - Do not run the Java detection command again later in the same workflow unless the user explicitly requests it.
  - Parse the detected Java major version from the environment inspection command output.
  - If the detected major version is 21 or higher, configure the project Java version to that detected major version.
  - If the detected major version is lower than 21, update the `sourceCompatibility` and `targetCompatibility` in `build.gradle` to 21 after confirmation.
  - If output parsing fails or is ambiguous, ask for explicit version confirmation instead of assuming a value.
  - If the Java version is updated, also ensure that relevant dependencies and plugins remain compatible.
  - Use the same Java version for both compilation and runtime to avoid compatibility issues.
- Prefer immutable domain models and builder patterns where helpful.

# Recommended Java Package Structure

Use `com.adp` as the base package for all Java code. Under that root, use clean-architecture layer packages with an entity- or feature-specific subpackage inside each layer. Keep cross-feature shared code minimal and intentional.

## Example Package Tree

```text
src/main/java/com/adp/
├── Application.java
├── domain/
│   └── client/
│       ├── Client.java
│       ├── ClientId.java
│       ├── ClientStatus.java
│       └── exception/
│           └── DuplicateClientException.java
├── usecase/
│   └── client/
│       ├── RegisterClientUseCase.java
│       ├── GetClientUseCase.java
│       ├── repository/
│       │   └── ClientRepository.java
│       ├── command/
│       │   └── RegisterClientCommand.java
│       ├── query/
│       │   └── GetClientQuery.java
│       ├── response/
│       │   └── ClientResponse.java
│       └── validation/
│           └── ClientValidation.java
├── adapter/
│   └── client/
│       └── controller/
│           ├── ClientController.java
│           ├── request/
│           │   └── RegisterClientRequest.java
│           └── response/
│               └── ClientHttpResponse.java
├── gateway/
│   └── client/
│       ├── ClientGateway.java
│       ├── entity/
│       │   └── ClientRecord.java
│       ├── mapper/
│       │   └── ClientGatewayMapper.java
│       └── config/
│           └── ClientGatewayConfiguration.java
└── configuration/
    └── ClientApiConfiguration.java
```

## Layer Placement Rules

1. Put core business state and invariants in `domain`.
2. Start every Java package with `com.adp`.
3. Inside each layer root package, create an entity- or feature-specific package such as `domain/client` or `usecase/client` before placing classes for that entity.
4. Put application orchestration, repository interfaces, commands, queries, responses, and shared business validation in `usecase`.
5. Put HTTP-facing request and response models in `adapter` under the entity package, for example `adapter/client/controller`.
6. Put database or integration implementations in `gateway` under the entity package.
7. Use `configuration` only for Spring `@Configuration` classes and bean wiring, and keep it as a global package instead of nesting configuration by entity.

# Java Naming Conventions

- Use the feature or entity name as the class-name prefix in `usecase`, `adapter`, and `gateway` layers.
- Prefer `ClientController`, `ClientRepository`, `ClientGateway`, `RegisterClientUseCase`, `RegisterClientCommand`, and `ClientResponse`.
- Use verb-plus-entity naming for use cases, for example `RegisterClientUseCase` or `GetClientUseCase`.
- Use `Repository` only for the business-facing interface and `Gateway` only for the outer implementation.
- Do not use generic names like `Service`, `Helper`, `Manager`, `Processor`, `Controller`, `Repository`, or `UseCase` without the feature prefix.
- Do not use names ending with `Impl`.
- Do not use technology-specific prefixes or suffixes such as `JdbcClientRepository`, `JpaClientGateway`, `RestClientGateway`, or `ClientGatewayJdbc`.
- Use business-oriented names in `domain`, for example `Client`, `ClientId`, `ClientStatus`, and `DuplicateClientException`.
- Use `Request` only for adapter-layer transport models and avoid reusing HTTP request models inside `usecase` or `domain`.

# Reliability and Security

- Validate and sanitize inputs at boundaries.
- Do not expose sensitive data in logs.
- Prefer resilient integration patterns for external dependencies.
- Enforce payload size limits for write endpoints.
- Implement request rate limiting for write endpoints only when the user explicitly requests it or the approved requirements/design call for it. When applied, document threshold values in API behavior notes.
- Implement payload and optional rate protections using reusable configuration components instead of duplicating endpoint-level logic.
- Add or update tests for success and failure paths when behavior changes.