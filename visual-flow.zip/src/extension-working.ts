import * as vscode from "vscode";
import { execFile } from "child_process";
import { promises as fs } from "fs";
import * as path from "path";
import { promisify } from "util";
import { randomUUID } from "crypto";

const execFileAsync = promisify(execFile);

type StepStatus = "pending" | "in-progress" | "completed" | "failed" | "skipped";
type RunStatus = "idle" | "running" | "completed" | "failed";

interface FeatureOption {
  id: string;
  title: string;
  description: string;
  value: string;
  label: string;
}

interface StartRunRequest {
  selectedAgent: string;
  featureValue: string;
  instruction: string;
}

interface StepState {
  stepNumber: number;
  name: string;
  status: StepStatus;
  owner: string;
  details: string;
  updatedAt: string;
}

interface TimelineEntry {
  timestamp: string;
  message: string;
  level: "info" | "warn" | "error";
  type?: string;
  owner?: string;
  stepNumber?: number;
  stepStatus?: StepStatus;
}

interface RunState {
  runId: string;
  status: RunStatus;
  selectedAgent: string;
  feature: FeatureOption;
  instruction: string;
  destinationPath: string;
  eventFilePath?: string;
  startedAt: string;
  updatedAt: string;
  steps: StepState[];
  timeline: TimelineEntry[];
}

interface WireEvent {
  timestamp?: string;
  type?: string;
  owner?: string;
  level?: "info" | "warn" | "error";
  message?: string;
  stepNumber?: number;
  stepStatus?: StepStatus;
}

interface CopilotExecutable {
  commandForTemplate: string;
  execFile: string;
  execArgsPrefix: string[];
}

const CLI_COMMAND_TEMPLATE_SETTING = "visualFlow.copilotCli.commandTemplate";
const CLI_TERMINAL_NAME_SETTING = "visualFlow.copilotCli.terminalName";

const JIRA_FEATURE_AGENT = "jira-feature-intake";
const FLOW_ORCHESTRATOR_AGENT = "flow-orchestrator";

const AVAILABLE_AGENTS = [
  FLOW_ORCHESTRATOR_AGENT,
  JIRA_FEATURE_AGENT,
  "planner",
  "coder",
  "verifier",
  "diagnostics",
  "tech-refresh-orchestrator"
];

const JIRA_SAMPLE_REQUEST =
  "Return exactly 10 Jira samples as a valid JSON array only. No markdown, no prose, no prefix text. Each item must contain id, title, and description string fields.";

const WORKFLOW_STEP_NAMES = [
  "Identify Feature Details",
  "Technical Design",
  "Create User Stories",
  "Implementation",
  "Security Validation",
  "Test Verification and Coverage",
  "Compare and Adjust",
  "Troubleshooting and Debugging",
  "Continuous Improvement"
] as const;

const DEFAULT_FEATURE_OPTIONS: FeatureOption[] = [
  {
    id: "feature-placeholder",
    title: "Select a feature",
    description: "Load Jira samples to select a feature.",
    value: "feature-placeholder",
    label: "Select a feature"
  }
];

class Logger {
  private readonly outputChannel: vscode.OutputChannel;
  private readonly workspaceRootPath: string | undefined;
  private readonly logFilePath: string | undefined;

  public constructor(outputChannel: vscode.OutputChannel, workspaceRootPath: string | undefined) {
    this.outputChannel = outputChannel;
    this.workspaceRootPath = workspaceRootPath;
    this.logFilePath = workspaceRootPath ? path.join(workspaceRootPath, ".visual-flow", "extension-debug.log") : undefined;
  }

  public log(message: string, data?: unknown): void {
    const timestamp = new Date().toISOString();
    const payload = data === undefined ? "" : ` ${safeStringify(data)}`;
    const line = `[${timestamp}] ${message}${payload}`;
    this.outputChannel.appendLine(line);
    void this.appendToFile(line + "\n");
  }

  private async appendToFile(content: string): Promise<void> {
    if (!this.workspaceRootPath || !this.logFilePath) {
      return;
    }

    try {
      await fs.mkdir(path.join(this.workspaceRootPath, ".visual-flow"), { recursive: true });
      await fs.appendFile(this.logFilePath, content, "utf8");
    } catch {
      // Logging failures should never break extension flow.
    }
  }
}

class FlowStore implements vscode.Disposable {
  private state: RunState | undefined;
  private readonly emitter = new vscode.EventEmitter<RunState | undefined>();
  private attachedEventFilePath: string | undefined;
  private processedLineCount = 0;
  private pollingTimer: NodeJS.Timeout | undefined;
  private readonly logger: Logger;

  public constructor(logger: Logger) {
    this.logger = logger;
  }

  public get onDidChangeState(): vscode.Event<RunState | undefined> {
    return this.emitter.event;
  }

  public getState(): RunState | undefined {
    return this.state;
  }

  public startRun(
    runId: string,
    feature: FeatureOption,
    selectedAgent: string,
    instruction: string,
    destinationPath: string,
    eventFilePath?: string
  ): RunState {
    const now = new Date().toISOString();
    const steps = createInitialSteps();
    for (const step of steps) {
      step.owner = selectedAgent;
    }
    if (selectedAgent === FLOW_ORCHESTRATOR_AGENT) {
      steps[0].status = "in-progress";
      steps[0].updatedAt = now;
      steps[0].details = "Step started";
    }

    this.state = {
      runId,
      status: "running",
      selectedAgent,
      feature,
      instruction,
      destinationPath,
      eventFilePath,
      startedAt: now,
      updatedAt: now,
      steps,
      timeline: []
    };

    this.pushTimeline({
      timestamp: now,
      level: "info",
      type: "run-started",
      owner: "extension",
      message: `Run started with agent ${selectedAgent}.`
    });
    this.emit();
    return this.state;
  }

  public completeRun(message: string): void {
    if (!this.state) {
      return;
    }
    this.state.status = "completed";
    this.state.updatedAt = new Date().toISOString();
    this.pushTimeline({
      timestamp: this.state.updatedAt,
      level: "info",
      type: "run-completed",
      owner: "extension",
      message
    });
    this.emit();
  }

  public failRun(message: string): void {
    if (!this.state) {
      return;
    }
    this.state.status = "failed";
    this.state.updatedAt = new Date().toISOString();
    this.pushTimeline({
      timestamp: this.state.updatedAt,
      level: "error",
      type: "run-failed",
      owner: "extension",
      message
    });
    this.emit();
  }

  public recordEvent(event: WireEvent): void {
    if (!this.state) {
      return;
    }

    const timestamp = event.timestamp ?? new Date().toISOString();
    const message = (event.message ?? "").trim() || "Event received";
    const level = event.level ?? "info";
    const checklistUpdates = parseChecklistStatusUpdates(message);
    const firstChecklistUpdate = checklistUpdates[0];
    const timelineStepNumber = event.stepNumber ?? firstChecklistUpdate?.stepNumber;
    const timelineStepStatus = event.stepStatus ?? firstChecklistUpdate?.status;
    const timelineType = checklistUpdates.length > 0 ? "step-status" : event.type ?? "event";
    const timelineMessage =
      checklistUpdates.length > 0
        ? checklistUpdates.map((update) => `Step ${update.stepNumber} - ${update.stepName} [${update.status}]`).join(" | ")
        : message;

    const isMainMilestone =
      checklistUpdates.length > 0 ||
      level === "warn" ||
      level === "error" ||
      timelineType === "run-started" ||
      timelineType === "run-completed" ||
      timelineType === "run-failed";

    if (isMainMilestone) {
      this.pushTimeline({
        timestamp,
        level,
        type: timelineType,
        owner: event.owner,
        message: timelineMessage,
        stepNumber: timelineStepNumber,
        stepStatus: timelineStepStatus
      });
    }

    const fallbackOwner = event.owner?.trim() || this.state.selectedAgent;
    const compactDetails = timelineMessage.replace(/\s+/g, " ").trim().slice(0, 220);
    if (typeof timelineStepNumber === "number") {
      this.updateStepMetadata(timelineStepNumber, fallbackOwner, compactDetails);
    }

    if (typeof event.stepNumber === "number" && event.stepStatus) {
      this.applyStepStatus(event.stepNumber, event.stepStatus, timestamp, true);
    }

    for (const update of checklistUpdates) {
      this.applyStepStatus(update.stepNumber, update.status, timestamp, true, update.stepName);
      this.updateStepMetadata(update.stepNumber, fallbackOwner, update.stepName);
    }

    this.state.updatedAt = timestamp;
    this.emit();
  }

  public async attachEventFile(fileUri: vscode.Uri): Promise<void> {
    const filePath = fileUri.fsPath;
    this.attachedEventFilePath = filePath;
    this.processedLineCount = 0;

    if (!this.state) {
      const now = new Date().toISOString();
        this.state = {
        runId: `attached-${path.basename(filePath)}`,
        status: "running",
        selectedAgent: FLOW_ORCHESTRATOR_AGENT,
        feature: {
          id: "attached-run",
          title: "Attached Run",
          description: "State loaded from an existing event file.",
          value: "attached-run",
          label: "Attached Run"
        },
        instruction: "Attached event file replay",
        destinationPath: filePath,
        eventFilePath: filePath,
        startedAt: now,
        updatedAt: now,
        steps: createInitialSteps(),
        timeline: []
        };
      for (const step of this.state.steps) {
        step.owner = FLOW_ORCHESTRATOR_AGENT;
      }
      this.emit();
    } else {
      this.state.eventFilePath = filePath;
      this.emit();
    }

    await this.readNewEventLines();
    this.startPolling();
  }

  public dispose(): void {
    if (this.pollingTimer) {
      clearInterval(this.pollingTimer);
      this.pollingTimer = undefined;
    }
    this.emitter.dispose();
  }

  private emit(): void {
    this.emitter.fire(this.state ? { ...this.state, steps: [...this.state.steps], timeline: [...this.state.timeline] } : undefined);
  }

  private pushTimeline(entry: TimelineEntry): void {
    if (!this.state) {
      return;
    }
    this.state.timeline.push(entry);
    if (this.state.timeline.length > 400) {
      this.state.timeline = this.state.timeline.slice(this.state.timeline.length - 400);
    }
  }

  private applyStepStatus(
    stepNumber: number,
    status: StepStatus,
    updatedAt: string,
    guarded: boolean,
    stepName?: string
  ): void {
    if (!this.state) {
      return;
    }
    if (stepNumber < 1 || stepNumber > this.state.steps.length) {
      return;
    }
    const index = stepNumber - 1;
    const step = this.state.steps[index];

    if (guarded && !this.canApplyTransition(index, status)) {
      this.logger.log("Blocked invalid step transition", {
        runId: this.state.runId,
        stepNumber,
        from: step.status,
        to: status
      });
      return;
    }

    step.status = status;
    step.updatedAt = updatedAt;
    if (stepName && stepName.trim().length > 0) {
      step.name = stepName.trim();
    }

    if (status === "failed") {
      this.state.status = "failed";
    }
    if (status === "completed" && stepNumber === this.state.steps.length) {
      this.state.status = "completed";
    }
  }

  private canApplyTransition(stepIndex: number, target: StepStatus): boolean {
    if (!this.state) {
      return false;
    }
    const step = this.state.steps[stepIndex];
    if (!step) {
      return false;
    }

    if (stepIndex > 0 && target !== "pending") {
      const previous = this.state.steps[stepIndex - 1];
      if (previous.status !== "completed") {
        return false;
      }
    }

    if (target === "in-progress") {
      return step.status === "pending" || step.status === "in-progress";
    }
    if (target === "completed") {
      return step.status === "in-progress" || step.status === "pending";
    }
    if (target === "failed") {
      return step.status === "in-progress" || step.status === "pending";
    }
    if (target === "skipped") {
      return step.status === "pending" || step.status === "in-progress";
    }
    return true;
  }

  private updateStepMetadata(stepNumber: number, owner: string, details: string): void {
    if (!this.state || stepNumber < 1 || stepNumber > this.state.steps.length) {
      return;
    }
    const step = this.state.steps[stepNumber - 1];
    if (owner && owner.trim().length > 0) {
      step.owner = owner.trim();
    }
    if (details && details.trim().length > 0) {
      step.details = details.trim();
    }
  }

  private startPolling(): void {
    if (this.pollingTimer) {
      clearInterval(this.pollingTimer);
    }
    this.pollingTimer = setInterval(() => {
      void this.readNewEventLines();
    }, 1000);
  }

  private async readNewEventLines(): Promise<void> {
    if (!this.attachedEventFilePath || !this.state) {
      return;
    }

    try {
      const buffer = await fs.readFile(this.attachedEventFilePath, "utf8");
      const lines = buffer.split(/\r?\n/).map((line) => line.trim()).filter((line) => line.length > 0);
      if (lines.length <= this.processedLineCount) {
        return;
      }

      const newLines = lines.slice(this.processedLineCount);
      this.processedLineCount = lines.length;

      for (const line of newLines) {
        this.recordEvent(parseLineToWireEvent(line));
      }
    } catch (error) {
      this.logger.log("Failed to poll event file", {
        file: this.attachedEventFilePath,
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  }
}

class DashboardController implements vscode.Disposable {
  private panel: vscode.WebviewPanel | undefined;
  private webviewReady = false;
  private featureOptions: FeatureOption[] = [...DEFAULT_FEATURE_OPTIONS];
  private featureLoading = false;
  private featureLoadMessage = "Loading Jira sample features...";
  private readonly disposables: vscode.Disposable[] = [];
  private readonly context: vscode.ExtensionContext;
  private readonly store: FlowStore;
  private readonly onStartRun: (request: StartRunRequest) => Promise<void>;
  private readonly onLoadFeatures: () => Promise<void>;
  private readonly logger: Logger;

  public constructor(
    context: vscode.ExtensionContext,
    store: FlowStore,
    onStartRun: (request: StartRunRequest) => Promise<void>,
    onLoadFeatures: () => Promise<void>,
    logger: Logger
  ) {
    this.context = context;
    this.store = store;
    this.onStartRun = onStartRun;
    this.onLoadFeatures = onLoadFeatures;
    this.logger = logger;
    this.disposables.push(this.store.onDidChangeState((state) => this.postState(state)));
  }

  public open(): void {
    if (!this.panel) {
      this.panel = vscode.window.createWebviewPanel(
        "visualFlow.dashboard",
        "Visual Flow Dashboard",
        vscode.ViewColumn.One,
        {
          enableScripts: true,
          retainContextWhenHidden: true
        }
      );

      this.panel.onDidDispose(
        () => {
          this.panel = undefined;
          this.webviewReady = false;
        },
        undefined,
        this.disposables
      );

      this.panel.webview.onDidReceiveMessage(
        async (message: unknown) => {
          if (!message || typeof message !== "object") {
            return;
          }
          const payload = message as { type?: string; request?: StartRunRequest };
          if (payload.type === "webviewReady") {
            this.webviewReady = true;
            this.syncWebview();
            return;
          }
          if (payload.type === "startRun" && payload.request) {
            await this.onStartRun(payload.request);
            return;
          }
          if (payload.type === "requestFeatureRefresh") {
            await this.onLoadFeatures();
          }
        },
        undefined,
        this.disposables
      );
    }

    this.webviewReady = false;
    this.panel.webview.html = this.getHtml(this.panel.webview);
    this.panel.reveal(vscode.ViewColumn.One, true);
    void this.onLoadFeatures();
  }

  public setFeatureOptions(featureOptions: FeatureOption[]): void {
    this.featureOptions = featureOptions.length > 0 ? featureOptions : [...DEFAULT_FEATURE_OPTIONS];
    this.postFeatureOptions();
  }

  public setFeatureLoadingState(loading: boolean, message: string): void {
    this.featureLoading = loading;
    this.featureLoadMessage = message;
    this.postFeatureLoadingState();
  }

  public dispose(): void {
    this.panel?.dispose();
    this.disposables.forEach((item) => item.dispose());
  }

  private syncWebview(): void {
    this.postFeatureLoadingState();
    this.postFeatureOptions();
    this.postState(this.store.getState());
  }

  private postFeatureOptions(): void {
    if (!this.panel || !this.webviewReady) {
      return;
    }
    void this.panel.webview.postMessage({
      type: "featureOptions",
      featureOptions: this.featureOptions
    });
  }

  private postFeatureLoadingState(): void {
    if (!this.panel || !this.webviewReady) {
      return;
    }
    void this.panel.webview.postMessage({
      type: "featureLoadingState",
      loading: this.featureLoading,
      message: this.featureLoadMessage
    });
  }

  private postState(state: RunState | undefined): void {
    if (!this.panel || !this.webviewReady) {
      return;
    }
    void this.panel.webview.postMessage({
      type: "state",
      state
    });
  }

  private getHtml(webview: vscode.Webview): string {
    const nonce = randomUUID();
    const featureOptionsPayload = safeStringify(this.featureOptions);
    const agentsPayload = safeStringify(AVAILABLE_AGENTS);
    const statePayload = safeStringify(this.store.getState());
    const loadingPayload = this.featureLoading ? "true" : "false";
    const loadingMessagePayload = safeStringify(this.featureLoadMessage);

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}';" />
  <title>Visual Flow Dashboard</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #0f1b2f;
      --panel: #13233d;
      --panel-alt: #0d1a2f;
      --line: #27446f;
      --text: #e8f1ff;
      --muted: #9fb2d4;
      --ok: #3ccf91;
      --warn: #f8b454;
      --err: #ff7b7b;
      --run: #69b5ff;
    }
    body {
      margin: 0;
      padding: 14px;
      font-family: "Segoe UI", sans-serif;
      color: var(--text);
      background: var(--bg);
    }
    .card {
      border: 1px solid var(--line);
      border-radius: 10px;
      background: var(--panel);
      padding: 10px;
      margin-bottom: 12px;
    }
    .title {
      margin: 0 0 8px 0;
      font-size: 22px;
      font-weight: 700;
      letter-spacing: 0.03em;
      color: #b8d6ff;
    }
    .grid2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }
    label {
      display: block;
      margin-bottom: 6px;
      color: #c7dbff;
      font-size: 12px;
    }
    select, textarea, button {
      width: 100%;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: #071427;
      color: var(--text);
      font-size: 14px;
      box-sizing: border-box;
    }
    select {
      min-height: 36px;
      padding: 6px 10px;
    }
    textarea {
      min-height: 112px;
      padding: 10px;
      resize: vertical;
      line-height: 1.35;
    }
    .status {
      margin: 0 0 10px 0;
      display: flex;
      align-items: center;
      gap: 8px;
      color: #ffd38f;
      font-size: 13px;
    }
    .status.loading {
      color: #ffd38f;
    }
    .status.success {
      color: var(--ok);
    }
    .status.error {
      color: var(--err);
    }
    .dot {
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background: var(--warn);
      opacity: 0.9;
    }
    .dot.success {
      background: var(--ok);
    }
    .dot.error {
      background: var(--err);
    }
    .dot.loading {
      animation: pulse 1.1s ease-in-out infinite;
    }
    @keyframes pulse {
      0% { transform: scale(0.8); opacity: 0.35; }
      50% { transform: scale(1.2); opacity: 1; }
      100% { transform: scale(0.8); opacity: 0.35; }
    }
    .actions {
      margin-top: 10px;
      display: flex;
      gap: 8px;
      align-items: center;
    }
    button {
      width: auto;
      padding: 8px 14px;
      background: #1f4f87;
      cursor: pointer;
    }
    button:hover {
      background: #2763a7;
    }
    button.secondary {
      background: #183457;
    }
    .hint {
      margin-top: 8px;
      color: var(--muted);
      font-size: 12px;
    }
    .panel-title {
      margin: 0 0 10px 0;
      color: #b8d6ff;
      font-size: 22px;
      font-weight: 600;
      letter-spacing: 0.02em;
    }
    .step-list, .timeline-list {
      list-style: none;
      margin: 0;
      padding: 0;
      display: grid;
      gap: 8px;
    }
    .timeline-item {
      border: 1px solid #22426f;
      border-radius: 8px;
      background: var(--panel-alt);
      padding: 8px 10px;
    }
    .step-list table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }
    .step-list th, .step-list td {
      border-bottom: 1px solid #22426f;
      padding: 6px 8px;
      text-align: left;
      vertical-align: top;
    }
    .step-list th {
      color: #c7dbff;
      font-weight: 600;
    }
    .badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 999px;
      border: 1px solid transparent;
      font-size: 11px;
      text-transform: lowercase;
      font-weight: 600;
      line-height: 1.2;
    }
    .badge.pending {
      color: #ffcf82;
      border-color: color-mix(in srgb, #ffcf82 60%, transparent);
      background: color-mix(in srgb, #ffcf82 14%, transparent);
    }
    .badge.in-progress {
      color: var(--run);
      border-color: color-mix(in srgb, var(--run) 60%, transparent);
      background: color-mix(in srgb, var(--run) 14%, transparent);
    }
    .badge.completed {
      color: var(--ok);
      border-color: color-mix(in srgb, var(--ok) 60%, transparent);
      background: color-mix(in srgb, var(--ok) 14%, transparent);
    }
    .badge.failed {
      color: var(--err);
      border-color: color-mix(in srgb, var(--err) 60%, transparent);
      background: color-mix(in srgb, var(--err) 14%, transparent);
    }
    .badge.skipped {
      color: var(--muted);
      border-color: color-mix(in srgb, var(--muted) 60%, transparent);
      background: color-mix(in srgb, var(--muted) 14%, transparent);
    }
    .timeline-item {
      border-left: 2px solid var(--line);
    }
    .timeline-meta {
      color: var(--muted);
      font-size: 11px;
      margin-top: 4px;
    }
    .empty {
      color: var(--muted);
      font-size: 12px;
    }
  </style>
</head>
<body>
  <section class="card">
    <h1 class="panel-title">START RUN</h1>
    <div id="loadingStatus" class="status loading">
      <span id="loadingDot" class="dot"></span>
      <span id="loadingText">Loading features...</span>
    </div>

    <div class="grid2">
      <div>
        <label for="featureNameSelect">Feature</label>
        <select id="featureNameSelect"></select>
      </div>
      <div>
        <label for="agentSelect">Agent</label>
        <select id="agentSelect"></select>
      </div>
    </div>

    <div style="margin-top:10px;">
      <label for="featureDescriptionInput">Feature description</label>
      <textarea id="featureDescriptionInput" readonly></textarea>
    </div>

    <div class="actions">
      <button id="startRunButton" type="button">Start Run</button>
      <button id="reloadFeaturesButton" class="secondary" type="button">Reload Features</button>
    </div>
    <div class="hint">Select an agent to prepare the feature input and prompt.</div>
  </section>

  <div class="grid2">
    <section class="card">
      <h2 class="title">STEP STATUS</h2>
      <div id="stepList" class="step-list"></div>
      <div id="stepEmpty" class="empty">No active flow run yet.</div>
    </section>

    <section class="card">
      <h2 class="title">TIMELINE</h2>
      <ul id="timelineList" class="timeline-list"></ul>
      <div id="timelineEmpty" class="empty">No timeline events yet.</div>
    </section>
  </div>

  <script nonce="${nonce}">
    const vscodeApi = acquireVsCodeApi();
    const featureNameSelect = document.getElementById("featureNameSelect");
    const agentSelect = document.getElementById("agentSelect");
    const featureDescriptionInput = document.getElementById("featureDescriptionInput");
    const startRunButton = document.getElementById("startRunButton");
    const reloadFeaturesButton = document.getElementById("reloadFeaturesButton");
    const loadingDot = document.getElementById("loadingDot");
    const loadingStatus = document.getElementById("loadingStatus");
    const loadingText = document.getElementById("loadingText");
    const stepList = document.getElementById("stepList");
    const stepEmpty = document.getElementById("stepEmpty");
    const timelineList = document.getElementById("timelineList");
    const timelineEmpty = document.getElementById("timelineEmpty");

    let currentFeatureOptions = ${featureOptionsPayload};
    let availableAgents = ${agentsPayload};
    let currentState = ${statePayload};
    let isFeatureLoading = ${loadingPayload};
    let loadingMessage = ${loadingMessagePayload};

    function escapeText(value) {
      return String(value ?? "");
    }

    function getSelectedFeature() {
      const value = featureNameSelect.value;
      return currentFeatureOptions.find((item) => item.value === value) || currentFeatureOptions[0];
    }

    function buildFeatureDescription(feature) {
      if (!feature) {
        return "";
      }
      return "id: " + escapeText(feature.id) + "\\n"
        + "title: " + escapeText(feature.title) + "\\n"
        + "description: " + escapeText(feature.description || "");
    }

    function updateFeatureDescription() {
      featureDescriptionInput.value = buildFeatureDescription(getSelectedFeature());
    }

    function renderFeatureOptions() {
      const selectedValue = featureNameSelect.value;
      featureNameSelect.innerHTML = "";
      currentFeatureOptions.forEach((feature, index) => {
        const option = document.createElement("option");
        option.value = feature.value;
        option.textContent = feature.label;
        option.selected = selectedValue ? selectedValue === feature.value : index === 0;
        featureNameSelect.appendChild(option);
      });
      if (featureNameSelect.options.length > 0 && !featureNameSelect.value) {
        featureNameSelect.selectedIndex = 0;
      }
      updateFeatureDescription();
    }

    function renderAgents() {
      const selected = agentSelect.value || "${FLOW_ORCHESTRATOR_AGENT}";
      agentSelect.innerHTML = "";
      availableAgents.forEach((agent) => {
        const option = document.createElement("option");
        option.value = agent;
        option.textContent = agent;
        option.selected = selected === agent;
        agentSelect.appendChild(option);
      });
    }

    function setLoadingUi(loading, message) {
      isFeatureLoading = !!loading;
      loadingMessage = message || "";
      featureNameSelect.disabled = isFeatureLoading;
      loadingDot.classList.toggle("loading", isFeatureLoading);
      loadingDot.classList.toggle("success", !isFeatureLoading && !/^failed/i.test(loadingMessage));
      loadingDot.classList.toggle("error", !isFeatureLoading && /^failed/i.test(loadingMessage));
      loadingStatus.classList.toggle("loading", isFeatureLoading);
      loadingStatus.classList.toggle("success", !isFeatureLoading && !/^failed/i.test(loadingMessage));
      loadingStatus.classList.toggle("error", !isFeatureLoading && /^failed/i.test(loadingMessage));
      loadingText.textContent = loadingMessage || (isFeatureLoading ? "Loading features..." : "Features loaded");
    }

    function statusCss(status) {
      return "status-" + status;
    }

    function formatStepStatusLabel(status) {
      return String(status || "").replace("-", " ");
    }

    function formatAmericanDateTime(value) {
      if (!value) {
        return "-";
      }
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) {
        return String(value);
      }
      return date
        .toLocaleString("en-US", {
          month: "2-digit",
          day: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: true
        })
        .replace(",", "");
    }

    function compactTimelineMessage(value) {
      const text = escapeText(value || "No detail");
      return text
        .replace(/Run\\s+[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, "Run")
        .replace(/\\s+/g, " ")
        .trim();
    }

    function renderSteps() {
      stepList.innerHTML = "";
      const state = currentState;
      if (!state || !Array.isArray(state.steps) || state.steps.length === 0 || state.selectedAgent !== "${FLOW_ORCHESTRATOR_AGENT}") {
        stepEmpty.style.display = "block";
        return;
      }
      stepEmpty.style.display = "none";
      const rows = state.steps.map((step) => {
        const safeName = escapeText(step.name);
        const safeStatus = escapeText(step.status);
        const safeOwner = escapeText(step.owner || "-");
        const safeDetails = escapeText(step.details || "-");
        return "<tr>"
          + "<td>Step " + step.stepNumber + " - " + safeName + "</td>"
          + "<td><span class=\\"badge " + safeStatus + "\\">" + formatStepStatusLabel(safeStatus) + "</span></td>"
          + "<td>" + safeOwner + "</td>"
          + "<td>" + safeDetails + "</td>"
          + "</tr>";
      }).join("");

      stepList.innerHTML =
        "<table><thead><tr><th>Step</th><th>Status</th><th>Agent</th><th>Details</th></tr></thead><tbody>"
        + rows
        + "</tbody></table>";
    }

    function renderTimeline() {
      timelineList.innerHTML = "";
      const state = currentState;
      if (!state || !Array.isArray(state.timeline) || state.timeline.length === 0) {
        timelineEmpty.style.display = "block";
        return;
      }
      timelineEmpty.style.display = "none";
      const entries = [...state.timeline].reverse().slice(0, 20);
      entries.forEach((entry) => {
        const li = document.createElement("li");
        li.className = "timeline-item";
        const eventType = escapeText(entry.type || "event");
        const stepLabel = entry.stepNumber ? ("step " + entry.stepNumber) : "run";
        const ownerPart = entry.owner ? (" | " + escapeText(entry.owner)) : "";
        const messageText = compactTimelineMessage(entry.message);

        const head = document.createElement("div");
        const strong = document.createElement("strong");
        strong.textContent = eventType;
        head.appendChild(strong);
        head.appendChild(document.createTextNode(" (" + stepLabel + ")"));

        const detail = document.createElement("div");
        detail.textContent = messageText;

        const meta = document.createElement("div");
        meta.className = "timeline-meta";
        meta.textContent = formatAmericanDateTime(entry.timestamp) + ownerPart;

        li.appendChild(head);
        li.appendChild(detail);
        li.appendChild(meta);
        timelineList.appendChild(li);
      });
    }

    function renderState() {
      renderSteps();
      renderTimeline();
    }

    featureNameSelect.addEventListener("change", updateFeatureDescription);
    reloadFeaturesButton.addEventListener("click", () => {
      vscodeApi.postMessage({ type: "requestFeatureRefresh" });
    });
    startRunButton.addEventListener("click", () => {
      const feature = getSelectedFeature();
      vscodeApi.postMessage({
        type: "startRun",
        request: {
          selectedAgent: agentSelect.value,
          featureValue: feature ? feature.value : "",
          instruction: ""
        }
      });
    });

    window.addEventListener("message", (event) => {
      const message = event.data || {};
      if (message.type === "featureOptions") {
        currentFeatureOptions = Array.isArray(message.featureOptions) ? message.featureOptions : [];
        renderFeatureOptions();
      }
      if (message.type === "featureLoadingState") {
        setLoadingUi(!!message.loading, message.message || "");
      }
      if (message.type === "state") {
        currentState = message.state;
        renderState();
      }
    });

    renderAgents();
    renderFeatureOptions();
    setLoadingUi(isFeatureLoading, loadingMessage);
    renderState();
    vscodeApi.postMessage({ type: "webviewReady" });
  </script>
</body>
</html>`;
  }
}

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  const workspaceRootPath = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
  const outputChannel = vscode.window.createOutputChannel("Visual Flow");
  const logger = new Logger(outputChannel, workspaceRootPath);
  const store = new FlowStore(logger);
  let dashboard: DashboardController;
  let cachedJiraFeatureOptions: FeatureOption[] | undefined;
  let activeEventFileUri: vscode.Uri | undefined;

  const writeEvent = async (event: WireEvent): Promise<void> => {
    if (!activeEventFileUri) {
      return;
    }
    try {
      await fs.mkdir(path.dirname(activeEventFileUri.fsPath), { recursive: true });
      await fs.appendFile(activeEventFileUri.fsPath, safeStringify(event) + "\n", "utf8");
    } catch (error) {
      logger.log("Failed to append event line", {
        file: activeEventFileUri.fsPath,
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  };

  const isCommandAvailable = async (commandName: string): Promise<boolean> => {
    if (!commandName.trim()) {
      return false;
    }

    if (process.platform === "win32") {
      try {
        await execFileAsync(
          "powershell",
          [
            "-NoProfile",
            "-Command",
            `if (Get-Command '${quoteForPowerShellSingleQuotedArg(commandName)}' -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }`
          ],
          { timeout: 8000, windowsHide: true }
        );
        return true;
      } catch {
        return false;
      }
    }

    try {
      await execFileAsync("sh", ["-lc", `command -v ${commandName}`], { timeout: 8000, windowsHide: true });
      return true;
    } catch {
      return false;
    }
  };

  const asPowerShellFileExecutable = (scriptPath: string): CopilotExecutable => ({
    commandForTemplate: `powershell -NoProfile -ExecutionPolicy Bypass -File "${quoteForDoubleQuotedShellArg(scriptPath)}"`,
    execFile: "powershell",
    execArgsPrefix: ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", scriptPath]
  });

  const resolveCopilotExecutable = async (): Promise<CopilotExecutable | undefined> => {
    const envPath = process.env.COPILOT_CLI_PATH?.trim();
    if (envPath) {
      try {
        await fs.access(envPath);
        if (process.platform === "win32" && envPath.toLowerCase().endsWith(".ps1")) {
          const executable = asPowerShellFileExecutable(envPath);
          await execFileAsync(executable.execFile, [...executable.execArgsPrefix, "--version"], {
            timeout: 8000,
            windowsHide: true
          });
          return executable;
        }

        await execFileAsync(envPath, ["--version"], { timeout: 8000, windowsHide: true });
        return {
          commandForTemplate: envPath,
          execFile: envPath,
          execArgsPrefix: []
        };
      } catch {
        // Continue to fallback candidates.
      }
    }

    if (await isCommandAvailable("copilot")) {
      try {
        await execFileAsync("copilot", ["--version"], { timeout: 8000, windowsHide: true });
        return {
          commandForTemplate: "copilot",
          execFile: "copilot",
          execArgsPrefix: []
        };
      } catch {
        // Continue to fallback candidates.
      }
    }

    if (await isCommandAvailable("github-copilot-cli")) {
      try {
        await execFileAsync("github-copilot-cli", ["--version"], { timeout: 8000, windowsHide: true });
        return {
          commandForTemplate: "github-copilot-cli",
          execFile: "github-copilot-cli",
          execArgsPrefix: []
        };
      } catch {
        // Continue to fallback candidates.
      }
    }

    if (process.platform === "win32") {
      const appData = process.env.APPDATA;
      if (appData) {
        const fallbackPs1Path = path.join(
          appData,
          "Code",
          "User",
          "globalStorage",
          "github.copilot-chat",
          "copilotCli",
          "copilot.ps1"
        );
        try {
          await fs.access(fallbackPs1Path);
          const executable = asPowerShellFileExecutable(fallbackPs1Path);
          await execFileAsync(executable.execFile, [...executable.execArgsPrefix, "--version"], {
            timeout: 8000,
            windowsHide: true
          });
          return executable;
        } catch {
          // Continue to fallback candidates.
        }
      }
    }

    if (await isCommandAvailable("gh")) {
      try {
        await execFileAsync("gh", ["copilot", "--help"], { timeout: 8000, windowsHide: true });
        return {
          commandForTemplate: "gh copilot",
          execFile: "gh",
          execArgsPrefix: ["copilot"]
        };
      } catch {
        // Continue to fallback candidates.
      }
    }

    return undefined;
  };

  const runCopilotCli = async (
    selectedAgent: string,
    instruction: string,
    promptFileUri: vscode.Uri,
    workspaceUri: vscode.Uri,
    runId: string,
    eventFilePath: string
  ): Promise<void> => {
    const copilotExecutable = await resolveCopilotExecutable();
    if (!copilotExecutable) {
      throw new Error("Copilot CLI is not available.");
    }

    const config = vscode.workspace.getConfiguration("visualFlow");
    let template = config.get<string>(
      CLI_COMMAND_TEMPLATE_SETTING,
      "{copilotExecutable} --agent \"{agent}\" -p \"{prompt}\" --add-dir \"{workspace}\" --allow-all-tools"
    );
    const terminalName = config.get<string>(CLI_TERMINAL_NAME_SETTING, "Visual Flow CLI");

    if (!template.includes("{copilotExecutable}")) {
      template = "{copilotExecutable} " + template;
    }
    if (!template.includes("{agent}")) {
      template += " --agent \"{agent}\"";
    }
    if (!template.includes("{prompt}")) {
      template += " -p \"{prompt}\"";
    }
    if (!template.includes("{workspace}")) {
      template += " --add-dir \"{workspace}\"";
    }
    if (!template.includes("--allow-all-tools")) {
      template += " --allow-all-tools";
    }

    const resolved = template
      .replaceAll("{copilotExecutable}", copilotExecutable.commandForTemplate)
      .replaceAll("{agent}", quoteForDoubleQuotedShellArg(selectedAgent))
      .replaceAll("{workspace}", quoteForDoubleQuotedShellArg(workspaceUri.fsPath))
      .replaceAll("{runId}", quoteForDoubleQuotedShellArg(runId))
      .replaceAll("{promptFile}", quoteForDoubleQuotedShellArg(promptFileUri.fsPath))
      .replaceAll("{prompt}", process.platform === "win32" ? "$vfPrompt" : quoteForDoubleQuotedShellArg(instruction));

    const flowTerminal = vscode.window.createTerminal({ name: terminalName });
    const copilotTerminalName = `${terminalName} (Copilot)`;
    const copilotTerminal = vscode.window.createTerminal({ name: copilotTerminalName });
    flowTerminal.show(true);
    if (process.platform === "win32") {
      flowTerminal.sendText(`Write-Output "Launching Copilot CLI in terminal: ${quoteForDoubleQuotedShellArg(copilotTerminalName)}"`);
    } else {
      flowTerminal.sendText(`echo "Launching Copilot CLI in terminal: ${quoteForDoubleQuotedShellArg(copilotTerminalName)}"`);
    }
    copilotTerminal.show();

    if (process.platform === "win32") {
      copilotTerminal.sendText(`Set-Location "${quoteForDoubleQuotedShellArg(workspaceUri.fsPath)}"`);
      copilotTerminal.sendText(`$vfPrompt = Get-Content -Raw -LiteralPath '${quoteForPowerShellSingleQuotedArg(promptFileUri.fsPath)}'`);
      copilotTerminal.sendText(`$vfEventFile = '${quoteForPowerShellSingleQuotedArg(eventFilePath)}'`);
      copilotTerminal.sendText(
        `& { ${resolved} } 2>&1 | ForEach-Object { ` +
          `$vfLine = $_.ToString(); ` +
          `Write-Output $vfLine; ` +
          `if ($vfLine -match 'Step\\s+\\d+\\s*-\\s*.+\\[(pending|in-progress|completed|failed|skipped)\\]') { ` +
          `$vfPayload = @{ timestamp = (Get-Date).ToString('o'); type = 'step-status'; owner = 'copilot-cli'; message = $vfLine } | ConvertTo-Json -Compress; ` +
          `Add-Content -LiteralPath $vfEventFile -Value $vfPayload ` +
          `} ` +
        `}`
      );
    } else {
      copilotTerminal.sendText(`cd "${quoteForDoubleQuotedShellArg(workspaceUri.fsPath)}"`);
      copilotTerminal.sendText(resolved);
    }
  };

  const loadJiraFeatureOptions = async (): Promise<FeatureOption[]> => {
    const workspaceUri = vscode.workspace.workspaceFolders?.[0]?.uri;
    if (!workspaceUri) {
      throw new Error("Open a workspace folder before loading Jira features.");
    }

    const copilotExecutable = await resolveCopilotExecutable();
    if (!copilotExecutable) {
      throw new Error("Copilot CLI is not available.");
    }

    let lastStdout = "";

    try {
      logger.log("Loading Jira features", {
        workspace: workspaceUri.fsPath,
        agent: JIRA_FEATURE_AGENT
      });

      const args = [
        "--agent",
        JIRA_FEATURE_AGENT,
        "-p",
        JIRA_SAMPLE_REQUEST,
        "--add-dir",
        workspaceUri.fsPath,
        "--allow-all-tools",
        "--silent",
        "--no-color",
        "--stream",
        "off"
      ];

      const { stdout } = await execFileAsync(copilotExecutable.execFile, [...copilotExecutable.execArgsPrefix, ...args], {
        cwd: workspaceUri.fsPath,
        maxBuffer: 1024 * 1024,
        timeout: 90000,
        windowsHide: true
      });
      lastStdout = String(stdout ?? "");

      const featureOptions = parseFeatureOptionsFromCopilotOutput(lastStdout);
      if (featureOptions.length === 0) {
        throw new Error("No Jira features were returned by Copilot CLI.");
      }
      cachedJiraFeatureOptions = featureOptions;
      return featureOptions;
    } catch (error) {
      const rawOutput =
        (error && typeof error === "object" && "stdout" in error
          ? String((error as { stdout?: unknown }).stdout ?? "")
          : "") || lastStdout;
      if (rawOutput.trim().length > 0) {
        const rawOutputPath = path.join(workspaceUri.fsPath, ".visual-flow", "jira-raw-last.txt");
        try {
          await fs.mkdir(path.dirname(rawOutputPath), { recursive: true });
          await fs.writeFile(rawOutputPath, rawOutput, "utf8");
        } catch {
          // Ignore diagnostic file write errors.
        }
      }
      if (cachedJiraFeatureOptions && cachedJiraFeatureOptions.length > 0) {
        logger.log("Using cached Jira features after refresh failure", {
          count: cachedJiraFeatureOptions.length,
          reason: error instanceof Error ? error.message : "Unknown"
        });
        return cachedJiraFeatureOptions;
      }
      throw error;
    }
  };

  const buildInstruction = (
    selectedAgent: string,
    feature: FeatureOption,
    destinationPath: string,
    eventFilePath: string,
    runId: string
  ): string => {
    if (selectedAgent === JIRA_FEATURE_AGENT) {
      return "Use agent @jira-feature-intake and ask for exactly 10 Jira samples as a JSON array with id, title, and description.";
    }

    const base = [
      `Feature id: ${feature.id}`,
      `Feature title: ${feature.title}`,
      `Feature description: ${feature.description}`,
      `Destination path: ${destinationPath}`
    ].join("\n");

    if (selectedAgent === FLOW_ORCHESTRATOR_AGENT) {
      return [
        `Use agent @${FLOW_ORCHESTRATOR_AGENT} to deliver the selected feature.`,
        base,
        "",
        "Real-time tracking requirement:",
        `- runId: ${runId}`,
        `- if file writes are allowed, append NDJSON step/timeline events to ${eventFilePath}`,
        "- if file writes are restricted, continue the run and emit step/timeline updates in plain text output",
        "- emit Step 1 to Step 9 statuses using: Step N - <name> [pending|in-progress|completed|failed|skipped]"
      ].join("\n");
    }

    return [
      `Use agent @${selectedAgent} to execute this feature.`,
      base,
      "",
      "Provide progress updates with clear step status and key timeline events."
    ].join("\n");
  };

  const loadJiraFeaturesIntoDashboard = async (): Promise<void> => {
    dashboard.setFeatureLoadingState(true, "Loading Jira sample features...");
    try {
      const options = await loadJiraFeatureOptions();
      dashboard.setFeatureOptions(options);
      dashboard.setFeatureLoadingState(false, `Loaded ${options.length} Jira sample features.`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to load Jira features.";
      logger.log("Failed to load Jira features", { message });
      dashboard.setFeatureLoadingState(false, `Failed to load Jira features: ${message}`);
      dashboard.setFeatureOptions([...DEFAULT_FEATURE_OPTIONS]);
      void vscode.window.showWarningMessage(message);
    }
  };

  const runFromRequest = async (request: StartRunRequest): Promise<void> => {
    const workspaceUri = vscode.workspace.workspaceFolders?.[0]?.uri;
    if (!workspaceUri) {
      void vscode.window.showErrorMessage("Open a workspace folder before starting a run.");
      return;
    }

    const selectedAgent = request.selectedAgent.trim();
    if (!selectedAgent) {
      void vscode.window.showErrorMessage("Agent selection is required.");
      return;
    }

    const featurePool = cachedJiraFeatureOptions?.length ? cachedJiraFeatureOptions : DEFAULT_FEATURE_OPTIONS;
    const selectedFeature =
      featurePool.find((feature) => feature.value === request.featureValue) ??
      featurePool[0] ??
      DEFAULT_FEATURE_OPTIONS[0];

    if (!selectedFeature) {
      void vscode.window.showErrorMessage("A feature must be selected.");
      return;
    }

    const runId = randomUUID();
    const visualFlowDir = path.join(workspaceUri.fsPath, ".visual-flow");
    const eventFilePath = path.join(visualFlowDir, `run-${runId}.jsonl`);
    const promptFilePath = path.join(visualFlowDir, `prompt-${runId}.txt`);
    const eventFileUri = vscode.Uri.file(eventFilePath);
    const promptFileUri = vscode.Uri.file(promptFilePath);
    activeEventFileUri = eventFileUri;

    const defaultInstruction = buildInstruction(
      selectedAgent,
      selectedFeature,
      workspaceUri.fsPath,
      eventFilePath,
      runId
    );
    const instruction = request.instruction.trim().length > 0 ? request.instruction.trim() : defaultInstruction;

    try {
      await fs.mkdir(visualFlowDir, { recursive: true });
      await fs.writeFile(promptFilePath, instruction, "utf8");
      await fs.writeFile(eventFilePath, "", "utf8");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to initialize prompt and event files.";
      logger.log("Failed to initialize run files", { message });
      void vscode.window.showErrorMessage(message);
      return;
    }

    store.startRun(runId, selectedFeature, selectedAgent, instruction, workspaceUri.fsPath, eventFilePath);
    await writeEvent({
      timestamp: new Date().toISOString(),
      type: "run-started",
      level: "info",
      message: `Run started for feature ${selectedFeature.id}.`
    });
    await store.attachEventFile(eventFileUri);

    try {
      await runCopilotCli(selectedAgent, instruction, promptFileUri, workspaceUri, runId, eventFilePath);
      await writeEvent({
        timestamp: new Date().toISOString(),
        type: "run-cli-launched",
        owner: "extension",
        level: "info",
        message: "Copilot CLI terminal launched."
      });
      void vscode.window.showInformationMessage(`Run ${runId} started. Copilot CLI launched.`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to launch Copilot CLI.";
      store.failRun(message);
      await writeEvent({
        timestamp: new Date().toISOString(),
        type: "run-failed",
        level: "error",
        message
      });
      void vscode.window.showErrorMessage(message);
    }
  };

  const promptForStartRunRequest = async (): Promise<StartRunRequest | undefined> => {
    const selectedAgent = await vscode.window.showQuickPick(AVAILABLE_AGENTS, {
      title: "Visual Flow",
      placeHolder: "Select an agent"
    });
    if (!selectedAgent) {
      return undefined;
    }

    const featurePool = cachedJiraFeatureOptions?.length ? cachedJiraFeatureOptions : DEFAULT_FEATURE_OPTIONS;
    const featurePick = await vscode.window.showQuickPick(
      featurePool.map((feature) => ({
        label: feature.label,
        description: feature.description,
        value: feature.value
      })),
      {
        title: "Visual Flow",
        placeHolder: "Select a feature"
      }
    );
    if (!featurePick) {
      return undefined;
    }

    const instruction = await vscode.window.showInputBox({
      title: "Visual Flow",
      prompt: "Optional instruction override",
      value: "",
      ignoreFocusOut: true
    });
    if (instruction === undefined) {
      return undefined;
    }

    return {
      selectedAgent,
      featureValue: featurePick.value,
      instruction: instruction.trim()
    };
  };

  dashboard = new DashboardController(context, store, runFromRequest, loadJiraFeaturesIntoDashboard, logger);

  context.subscriptions.push(store, dashboard, outputChannel);
  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.openDashboard", () => {
      outputChannel.show(true);
      dashboard.open();
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.startRun", async () => {
      dashboard.open();
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.startRunWithPrompts", async () => {
      const request = await promptForStartRunRequest();
      if (!request) {
        return;
      }
      await runFromRequest(request);
      dashboard.open();
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.recordEvent", async () => {
      const state = store.getState();
      if (!state) {
        void vscode.window.showWarningMessage("Start or attach a run before recording events.");
        return;
      }
      const message = await vscode.window.showInputBox({
        title: "Visual Flow",
        prompt: "Event message",
        ignoreFocusOut: true
      });
      if (!message || message.trim().length === 0) {
        return;
      }
      const stepInput = await vscode.window.showInputBox({
        title: "Visual Flow",
        prompt: "Optional step number (1-9)",
        ignoreFocusOut: true
      });
      const statusPick = await vscode.window.showQuickPick(
        ["pending", "in-progress", "completed", "failed", "skipped"] as StepStatus[],
        {
          title: "Visual Flow",
          placeHolder: "Optional step status"
        }
      );
      const parsedStep = stepInput ? Number.parseInt(stepInput, 10) : undefined;
      const event: WireEvent = {
        timestamp: new Date().toISOString(),
        type: "manual-event",
        level: "info",
        message: message.trim(),
        stepNumber: Number.isNaN(parsedStep) ? undefined : parsedStep,
        stepStatus: normalizeStatus(statusPick)
      };
      store.recordEvent(event);
      await writeEvent(event);
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.completeRun", async () => {
      const state = store.getState();
      if (!state) {
        return;
      }
      store.completeRun("Run marked completed.");
      await writeEvent({
        timestamp: new Date().toISOString(),
        type: "run-completed",
        level: "info",
        message: "Run marked completed."
      });
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("visualFlow.attachEventFile", async () => {
      const selected = await vscode.window.showOpenDialog({
        canSelectMany: false,
        canSelectFiles: true,
        canSelectFolders: false,
        filters: {
          "Event files": ["json", "jsonl", "ndjson"]
        }
      });
      if (!selected || selected.length === 0) {
        return;
      }
      await store.attachEventFile(selected[0]);
      activeEventFileUri = selected[0];
      dashboard.open();
      void vscode.window.showInformationMessage(`Attached event file: ${selected[0].fsPath}`);
    })
  );

  logger.log("Visual Flow extension activated");
}

export function deactivate(): void {
  // no-op
}

function createInitialSteps(): StepState[] {
  const now = new Date().toISOString();
  return WORKFLOW_STEP_NAMES.map((name, index) => ({
    stepNumber: index + 1,
    name,
    status: "pending",
    owner: "-",
    details: "",
    updatedAt: now
  }));
}

function parseChecklistStatusUpdates(message: string): Array<{ stepNumber: number; stepName: string; status: StepStatus }> {
  const updates: Array<{ stepNumber: number; stepName: string; status: StepStatus }> = [];
  const regex = /Step\s+(\d+)\s*-\s*(.+?)\s*\[(pending|in-progress|completed|failed|skipped)\]/gi;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(message)) !== null) {
    const stepNumber = Number.parseInt(match[1], 10);
    const stepName = match[2].trim();
    const status = normalizeStatus(match[3]);
    if (stepNumber >= 1 && status) {
      updates.push({ stepNumber, stepName, status });
    }
  }
  return updates;
}

function parseLineToWireEvent(line: string): WireEvent {
  try {
    const parsed = JSON.parse(line) as Record<string, unknown>;
    const status = normalizeStatus(stringOrUndefined(parsed.stepStatus));
    return {
      timestamp: stringOrUndefined(parsed.timestamp),
      type: stringOrUndefined(parsed.type),
      owner: firstNonEmpty([stringOrUndefined(parsed.owner), stringOrUndefined(parsed.actor), stringOrUndefined(parsed.source)]),
      level: normalizeLevel(stringOrUndefined(parsed.level)),
      message: stringOrUndefined(parsed.message) ?? line,
      stepNumber: numberOrUndefined(parsed.stepNumber),
      stepStatus: status
    };
  } catch {
    return {
      timestamp: new Date().toISOString(),
      type: "raw-line",
      owner: "copilot-cli",
      level: "info",
      message: line
    };
  }
}

function parseFeatureOptionsFromCopilotOutput(stdout: string): FeatureOption[] {
  const text = normalizeCopilotText(stdout);
  if (text.length === 0) {
    throw new Error("Copilot CLI returned an empty Jira response.");
  }

  const candidates: Array<unknown[]> = [];
  for (const codeBlock of extractCodeBlocks(text)) {
    const parsed = tryParseJson(codeBlock);
    if (Array.isArray(parsed)) {
      candidates.push(parsed);
    } else if (parsed && typeof parsed === "object") {
      const record = parsed as Record<string, unknown>;
      for (const key of ["features", "items", "results", "data"]) {
        if (Array.isArray(record[key])) {
          candidates.push(record[key] as unknown[]);
        }
      }
    }
  }

  const firstArray = extractBracketArray(text);
  if (firstArray) {
    const parsed = tryParseJson(firstArray);
    if (Array.isArray(parsed)) {
      candidates.push(parsed);
    }
  }

  const direct = tryParseJson(text);
  if (Array.isArray(direct)) {
    candidates.push(direct);
  } else if (direct && typeof direct === "object") {
    collectArrayCandidatesFromObject(direct as Record<string, unknown>, candidates, 0);
  }

  for (const candidate of candidates) {
    const normalized = normalizeFeatureArray(candidate);
    if (normalized.length > 0) {
      return normalized;
    }
  }

  const jsonLike = parseFeaturesFromJsonLikeText(text);
  if (jsonLike.length > 0) {
    return jsonLike;
  }

  const fallback = parseFeaturesFromLines(text);
  if (fallback.length > 0) {
    return fallback;
  }

  throw new Error("Could not parse Jira features from Copilot CLI output.");
}

function normalizeFeatureArray(items: unknown[]): FeatureOption[] {
  const features: FeatureOption[] = [];
  for (const item of items) {
    if (!item || typeof item !== "object") {
      continue;
    }
    const record = item as Record<string, unknown>;
    const id = firstNonEmpty([
      stringOrUndefined(record.id),
      stringOrUndefined(record.key),
      stringOrUndefined(record.issueKey),
      stringOrUndefined(record.ticket)
    ]);
    const title = firstNonEmpty([
      stringOrUndefined(record.title),
      stringOrUndefined(record.name),
      stringOrUndefined(record.summary)
    ]);
    const description = firstNonEmpty([
      stringOrUndefined(record.description),
      stringOrUndefined(record.details),
      stringOrUndefined(record.body)
    ]) ?? "";

    if (!id || !title) {
      continue;
    }

    features.push({
      id,
      title,
      description,
      value: id,
      label: `${id} - ${title}`
    });
  }
  return dedupeFeatures(features);
}

function parseFeaturesFromLines(text: string): FeatureOption[] {
  const features: FeatureOption[] = [];
  const lines = text.split(/\r?\n/);

  for (const rawLine of lines) {
    const line = rawLine.trim().replace(/^[-*]\s*/, "");
    if (!line) {
      continue;
    }

    let match = /^([A-Za-z][A-Za-z0-9]+-\d+)\s*[-:]\s*(.+?)(?:\s*[|–—-]\s*(.+))?$/.exec(line);
    if (match) {
      const id = match[1].trim();
      const title = match[2].trim();
      const description = (match[3] ?? "").trim();
      features.push({ id, title, description, value: id, label: `${id} - ${title}` });
      continue;
    }

    match =
      /id\s*:\s*([A-Za-z][A-Za-z0-9]+-\d+).+title\s*:\s*([^|,;]+)(?:.+description\s*:\s*(.+))?/i.exec(line);
    if (match) {
      const id = match[1].trim();
      const title = match[2].trim();
      const description = (match[3] ?? "").trim();
      features.push({ id, title, description, value: id, label: `${id} - ${title}` });
    }
  }

  return dedupeFeatures(features);
}

function parseFeaturesFromJsonLikeText(text: string): FeatureOption[] {
  const features: FeatureOption[] = [];
  const objectPattern = /\{[\s\S]*?\}/g;
  let objectMatch: RegExpExecArray | null;

  while ((objectMatch = objectPattern.exec(text)) !== null) {
    const block = objectMatch[0];
    const id = captureFirst(block, [/\"id\"\s*:\s*\"([^\"]+)\"/i, /\"key\"\s*:\s*\"([^\"]+)\"/i, /\"issueKey\"\s*:\s*\"([^\"]+)\"/i]);
    const title = captureFirst(block, [/\"title\"\s*:\s*\"([^\"]+)\"/i, /\"name\"\s*:\s*\"([^\"]+)\"/i, /\"summary\"\s*:\s*\"([^\"]+)\"/i]);
    const description = captureFirst(block, [/\"description\"\s*:\s*\"([\s\S]*?)\"/i, /\"details\"\s*:\s*\"([\s\S]*?)\"/i]) ?? "";

    if (!id || !title) {
      continue;
    }

    features.push({
      id: normalizeLooseString(id),
      title: normalizeLooseString(title),
      description: normalizeLooseString(description),
      value: normalizeLooseString(id),
      label: `${normalizeLooseString(id)} - ${normalizeLooseString(title)}`
    });
  }

  return dedupeFeatures(features);
}

function dedupeFeatures(features: FeatureOption[]): FeatureOption[] {
  const byId = new Map<string, FeatureOption>();
  for (const feature of features) {
    if (!byId.has(feature.id)) {
      byId.set(feature.id, feature);
    }
  }
  return [...byId.values()];
}

function extractCodeBlocks(text: string): string[] {
  const blocks: string[] = [];
  const regex = /```(?:json)?\s*([\s\S]*?)```/gi;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(text)) !== null) {
    const value = match[1]?.trim();
    if (value) {
      blocks.push(value);
    }
  }
  return blocks;
}

function extractBracketArray(text: string): string | undefined {
  for (let i = 0; i < text.length; i += 1) {
    if (text[i] !== "[") {
      continue;
    }

    const end = findMatchingJsonBracket(text, i, "[", "]");
    if (end === -1) {
      continue;
    }

    const candidate = text.slice(i, end + 1).trim();
    if (candidate.length > 1) {
      return candidate;
    }
  }
  return undefined;
}

function tryParseJson(value: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    return undefined;
  }
}

function quoteForDoubleQuotedShellArg(value: string): string {
  return value.replace(/"/g, '\\"');
}

function quoteForPowerShellSingleQuotedArg(value: string): string {
  return value.replace(/'/g, "''");
}

function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value);
  } catch {
    return "null";
  }
}

function normalizeStatus(value: string | undefined): StepStatus | undefined {
  if (!value) {
    return undefined;
  }
  const normalized = value.trim().toLowerCase();
  if (
    normalized === "pending" ||
    normalized === "in-progress" ||
    normalized === "completed" ||
    normalized === "failed" ||
    normalized === "skipped"
  ) {
    return normalized;
  }
  return undefined;
}

function normalizeLevel(value: string | undefined): "info" | "warn" | "error" {
  if (value === "warn" || value === "error") {
    return value;
  }
  return "info";
}

function numberOrUndefined(value: unknown): number | undefined {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }
  if (typeof value === "string" && value.trim().length > 0) {
    const parsed = Number.parseInt(value, 10);
    return Number.isNaN(parsed) ? undefined : parsed;
  }
  return undefined;
}

function stringOrUndefined(value: unknown): string | undefined {
  return typeof value === "string" ? value : undefined;
}

function firstNonEmpty(values: Array<string | undefined>): string | undefined {
  for (const value of values) {
    if (value && value.trim().length > 0) {
      return value.trim();
    }
  }
  return undefined;
}

function captureFirst(value: string, patterns: RegExp[]): string | undefined {
  for (const pattern of patterns) {
    const match = pattern.exec(value);
    if (match?.[1]) {
      return match[1];
    }
  }
  return undefined;
}

function normalizeCopilotText(value: string): string {
  let normalized = value;

  // Remove UTF-16 NUL padding if CLI returned UTF-16 text decoded as UTF-8.
  normalized = normalized.replace(/\u0000/g, "");
  normalized = normalized.replace(/^\uFEFF/, "");
  normalized = normalized.replace(/\r\n/g, "\n");

  // Remove ANSI control sequences that can appear in terminal-backed output.
  normalized = normalized.replace(/\u001b\[[0-9;]*[A-Za-z]/g, "");
  normalized = normalized.replace(/^[^\[\{]*(?=[\[\{])/, "");

  return normalized.trim();
}

function normalizeLooseString(value: string): string {
  return value
    .replace(/\\n/g, " ")
    .replace(/\r?\n/g, " ")
    .replace(/\s+/g, " ")
    .replace(/\\"/g, "\"")
    .trim();
}

function collectArrayCandidatesFromObject(
  record: Record<string, unknown>,
  candidates: Array<unknown[]>,
  depth: number
): void {
  if (depth > 4) {
    return;
  }

  for (const key of ["features", "items", "results", "data", "issues", "tickets", "samples", "output"]) {
    if (Array.isArray(record[key])) {
      candidates.push(record[key] as unknown[]);
    }
  }

  for (const value of Object.values(record)) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      continue;
    }
    collectArrayCandidatesFromObject(value as Record<string, unknown>, candidates, depth + 1);
  }
}

function findMatchingJsonBracket(text: string, start: number, open: string, close: string): number {
  let depth = 0;
  let inString = false;
  let escaped = false;

  for (let i = start; i < text.length; i += 1) {
    const ch = text[i];

    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === "\"") {
        inString = false;
      }
      continue;
    }

    if (ch === "\"") {
      inString = true;
      continue;
    }

    if (ch === open) {
      depth += 1;
      continue;
    }

    if (ch === close) {
      depth -= 1;
      if (depth === 0) {
        return i;
      }
    }
  }

  return -1;
}
