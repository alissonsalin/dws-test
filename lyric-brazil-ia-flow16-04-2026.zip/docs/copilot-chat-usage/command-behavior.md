# Command Behavior

This page explains the command execution behavior users can expect during feature workflows.

## Preflight Checks

Before validation commands, Copilot verifies:

1. Tool availability
2. Expected files
3. Working directory

## Fix-Driven Retries

If a command fails:

1. Copilot applies a material fix before retrying.
2. Copilot does not repeat the same unchanged failing pattern.

## Minimal Command Strategy

1. Use only policy-approved verification and security commands.
2. Do not run extra diagnostics unless explicitly requested.

## Java-Specific Notes

1. Java version inspection runs exactly once at Step 4 start.
2. Final verification uses the approved Gradle command policy.

## Test Command Stability

1. Test commands come from the repository-approved command skills, not from per-run improvisation.
2. Java test execution uses the exact command policy from `.github/skills/java-cli/SKILL.md`.
3. Node.js and Python test execution uses the command-selection policy from `.github/skills/node-python-cli/SKILL.md`.
4. If the repository already defines a test script or wrapper command, reuse it instead of switching to a different runner command.

## Security Command Stability

1. Security-validation commands come from the repository-approved command skills, not from per-run improvisation.
2. Java security validation uses the exact command policy from `.github/skills/java-cli/SKILL.md`.
3. Node.js and Python security validation uses the command-selection policy from `.github/skills/node-python-cli/SKILL.md`.
4. If the repository already defines a security script or wrapper command, reuse it instead of switching to a different scanner command.

## Next

Continue to [Feature Flow Prompts](feature-flow-prompts.md).