---
name: cli-resilience
description: "Run implementation, verification, and security commands with preflight checks, fix-driven retries, and concise failure capture. Use for Java, Node.js, and Python workflows when commands fail or need resilient execution."
argument-hint: "Describe the command goal, stack (Java/Node/Python), and current failure if any"
---

# CLI Resilience

Use this skill to execute workflow commands with minimal retries and clear remediation tracking.

## When to Use

- A verification or security command fails and you need a reliable retry loop.
- You want to run one command per phase with minimal noise.
- You need structured reporting of command failures and applied fixes.

## Procedure

1. Confirm phase and goal:
- Identify whether this is implementation setup, verification, or security validation.
- Keep command scope to the current phase only.

2. Run preflight checks:
- Confirm required tools are in PATH.
- Confirm expected files exist for the stack.
- Confirm working directory context.

3. Execute one target command:
- Use non-interactive command variants.
- Prefer Gradle Wrapper for Java projects.

4. If command fails, apply fix-driven retry policy:
- Capture the error fingerprint.
- Apply a material fix before retrying.
- Do not rerun unchanged commands with unchanged errors.
- Continue until resolved or blocked by explicit user gate.

5. Report each attempt consistently:
- Command executed
- Key pass/fail result
- Fix applied
- Next action

6. Capture reusable learnings:
- Record repeated failures and successful remediations for Step 9 improvement notes.

## Stack Notes

- Java: run Java environment inspection once at Step 4 start; parse major version before project Java configuration decisions.
- Node/Python: validate toolchain and manifest files (`package.json`, `pyproject.toml`, `requirements.txt`) before verification/security commands.

## Constraints

- Keep command usage minimal and goal-oriented.
- Do not run extra diagnostics unless requested or required by retry policy.
- Do not mark recoverable command issues as final workflow failures.
