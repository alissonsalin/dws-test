# How To Use Copilot Chat With Project Instructions

This section explains how to use Copilot Chat in this project with clear, focused guides.

## Sections

1. [Instruction Resolution](copilot-chat-usage/instruction-resolution.md)
2. [Workflow Gates](copilot-chat-usage/workflow-gates.md)
3. [Command Behavior](copilot-chat-usage/command-behavior.md)
4. [Feature Flow Prompts](copilot-chat-usage/feature-flow-prompts.md)
5. [Tech Refresh Orchestrator Prompts](copilot-chat-usage/tech-refresh-orchestrator-prompts.md)
6. [Best Practices](copilot-chat-usage/best-practices.md)
