---
name: security
description: "Select and run approved security validation commands for Java, Node.js, and Python using stack-specific command rules and resilient retries."
argument-hint: "Describe the stack, workflow phase, security goal, and any current command failure"
---

# Security Command Selection Rules

## When to Use

- Security validation is requested or enabled.
- Dependency or plugin changes during implementation require CVE validation before completion.
- You need approved Java, Node.js, or Python security command selection and retry guidance.

## Shared Rules

- Follow `.github/instructions/command-resilience.instructions.md` for preflight checks, fix-driven retries, and reporting.
- Keep commands minimal, non-interactive, and run from project root unless repository instructions require another path.
- Use repository-defined scripts first; only fall back to tool-native commands when scripts are missing.
- Do not run multiple overlapping scanners for the same step unless repository policy explicitly requires them.

## Approved Java Security Commands

- Use Gradle Wrapper as the default Java security-validation runner.
- During implementation setup, inspect `build.gradle` or `build.gradle.kts` and add or repair the Dependency Check plugin and `dependencyCheckAnalyze` task when missing.
- Approved dedicated Java CVE scan command:
	- Windows: `.\\gradlew dependencyCheckAnalyze`
	- macOS and Linux: `./gradlew dependencyCheckAnalyze`
- `dependencyCheckAnalyze` is the repository-approved Java CVE scan task.
- If the task is missing, fix plugin configuration during implementation setup before retrying security validation.
- `dependencyUpdates` may be used for dependency update analysis when explicitly needed, but it does not satisfy CVE validation by itself.

## Approved Node.js Security Command Selection

- Determine package manager once from lockfile signals:
	- `pnpm-lock.yaml` -> `pnpm`
	- `yarn.lock` -> `yarn`
	- `package-lock.json` or `npm-shrinkwrap.json` -> `npm`
- Read `package.json` scripts and use the first matching approved script in this order:
	- `security`
	- `audit`
	- `test:security`
- If no approved security script exists, use the package-manager audit command exactly:
	- `npm audit --audit-level=high`
	- `pnpm audit --audit-level=high`
	- `yarn npm audit --severity high`

## Approved Python Security Command Selection

- Prefer the repository-defined Python security command when documented in README, Makefile, task runner, or project scripts.
- If no wrapper command is documented, use the first approved available command from project signals:
	- `python -m pip_audit`
	- `python -m safety check`
- Prefer `python -m ...` invocation over bare executables to reduce environment-path drift.

## Reporting

- After each attempt, summarize command executed, key result, fix applied, and next action.
- Capture repeated failure patterns and successful remediations in improvement notes.
