---
name: lombok
description: "Apply Lombok conventions for Java DTOs, entities, commands, responses, and builder-based models. Use for Java class implementation in this repository because Lombok is mandatory and must be added to Gradle if missing."
argument-hint: "Describe the Java model types involved and whether Lombok is already present in the build"
---

# Lombok Usage Rules

## When to Use

- A Java feature adds or changes DTOs, entities, commands, responses, or value objects.
- Java classes are being implemented or refactored and Lombok annotations must be applied consistently.
- You need to verify that Lombok is present in `build.gradle` or `build.gradle.kts` and add it if missing.

## Core Rules

- Use Lombok for DTOs, entities, commands, responses, and Java value objects in this repository.
- If Lombok is missing from `build.gradle` or `build.gradle.kts`, add it during Step 4 before implementing or updating Java model classes.
- For Gradle, add Lombok under both `compileOnly` and `annotationProcessor`, and add matching `testCompileOnly` and `testAnnotationProcessor` entries when tests compile Lombok-backed classes.
- Do not use Java `record` classes for DTOs, entities, commands, or responses.

## Builder Pattern

- Use Lombok `@Builder` for multi-field entities, DTOs, request/response payloads, and command objects; place it at class level and pair it with generated accessors needed for serialization.

## Annotation Guidelines

- Use `@Data` for simple domain entities and DTOs.
- Use `@Getter` and `@Setter` separately when finer access control is needed.
- Use `@RequiredArgsConstructor` for constructor-based dependency injection in service classes.
- Use `@NoArgsConstructor` and `@AllArgsConstructor` only when explicitly needed.
- Use `@Slf4j` for logger injection in service and controller classes.
- Avoid `@EqualsAndHashCode` on entities with JPA relationships to prevent circular comparison issues.

## Clean Architecture and Verification

- Use `@Builder` on domain entities, use case command objects, DTOs, and response objects without violating layer boundaries, ensure Lombok annotation processing is enabled in IDE and build tool, and verify generated code compiles successfully.