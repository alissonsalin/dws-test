---
name: node-python-cli
description: "Run Node.js or Python workflow commands with preflight checks, fix-driven retries, and concise remediation tracking. Use when Node.js or Python verification, test, or security commands need resilient execution."
argument-hint: "Describe the stack, workflow phase, target command, and current failure if any"
---

# Node and Python Command Resilience Rules

## When to Use

- A Node.js or Python verification command is about to run.
- A Node.js or Python security or test command fails and needs fix-driven retries.
- You need stack-specific preflight checks before running the target command.

## Preflight Checks

- Confirm required tools are in PATH.
- Confirm expected files exist, such as `package.json`, `pyproject.toml`, or `requirements.txt`.
- Confirm the working directory context.
- If preflight fails, fix the environment or command context first.

## Retry and Remediation Policy

- Follow `.github/instructions/command-resilience.instructions.md` as the shared baseline.
- Keep commands minimal, non-interactive, and fix-driven; continue remediation for recoverable errors, do not rerun unchanged failures, and do not mark recoverable command errors as failed workflow steps.

## Node Package Manager Detection

- Determine the package manager once from repository signals before selecting Node.js test or security commands:
	- `pnpm-lock.yaml` -> `pnpm`
	- `yarn.lock` -> `yarn`
	- `package-lock.json` or `npm-shrinkwrap.json` -> `npm`

## Approved Test Command Selection

### Node.js

- Read `package.json` scripts and use the first matching approved script in this order:
	- coverage run: `test:coverage`
	- CI-oriented run: `test:ci`
	- baseline run: `test`
- Use the matching package-manager command exactly:
	- `npm run test:coverage`, `npm run test:ci`, or `npm test`
	- `pnpm run test:coverage`, `pnpm run test:ci`, or `pnpm test`
	- `yarn test:coverage`, `yarn test:ci`, or `yarn test`
- Do not call `jest`, `vitest`, `mocha`, or another test runner directly when a project script already exists.
- If no test script exists, stop and inspect repository docs or existing tasks before inventing a direct runner command.

### Python

- Prefer the repository-defined Python test command when one is documented in the README, Makefile, task runner, or project scripts.
- If no wrapper command is documented, select the command from project signals:
	- if `pytest` is configured or implied by `pyproject.toml`, `pytest.ini`, or `tox.ini`, use `python -m pytest`
	- if coverage is required and `pytest-cov` is configured, use `python -m pytest --cov --cov-report=term-missing --cov-report=html`
- Do not switch between `pytest`, `unittest`, `tox`, `nox`, or ad-hoc module commands unless repository configuration clearly requires that tool.
- Prefer `python -m pytest` over bare `pytest` to avoid environment-path drift.

## Approved Security Command Selection

### Node.js

- Read `package.json` scripts and use the first matching approved script in this order:
	- security scan: `security`
	- audit run: `audit`
	- CI security run: `test:security`
- If no approved security script exists, use the package-manager audit command exactly:
	- `npm audit --audit-level=high`
	- `pnpm audit --audit-level=high`
	- `yarn npm audit --severity high`
- Do not switch between package-manager audit commands and direct third-party scanners unless the repository explicitly defines that tool.

### Python

- Prefer the repository-defined Python security command when one is documented in the README, Makefile, task runner, or project scripts.

- If no wrapper command is documented, use the first approved available command from project signals:
	- `python -m pip_audit`
	- `python -m safety check`
- Do not alternate between `pip-audit`, `safety`, `poetry audit`, or other scanners unless repository configuration clearly requires that tool.
- Prefer `python -m ...` invocation over bare executables to avoid environment-path drift.

## Reporting

- After each attempt, summarize the command executed, key result, fix applied, and next action.
- Capture repeated failure patterns and successful fixes in improvement notes.