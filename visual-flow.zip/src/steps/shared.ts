import * as vscode from "vscode";
import { promises as fs } from "fs";
import * as path from "path";

export type StepStatus = "pending" | "in-progress" | "completed" | "failed" | "skipped";
export type RunStatus = "idle" | "running" | "completed" | "failed";

export interface FeatureOption {
  id: string;
  title: string;
  description: string;
  value: string;
  label: string;
}

export interface StartRunRequest {
  selectedAgent: string;
  featureValue: string;
  instruction: string;
}

export interface StepState {
  stepNumber: number;
  name: string;
  status: StepStatus;
  owner: string;
  details: string;
  updatedAt: string;
}

export interface TimelineEntry {
  timestamp: string;
  message: string;
  level: "info" | "warn" | "error";
  type?: string;
  owner?: string;
  stepNumber?: number;
  stepStatus?: StepStatus;
}

export interface RunState {
  runId: string;
  status: RunStatus;
  selectedAgent: string;
  feature: FeatureOption;
  instruction: string;
  destinationPath: string;
  eventFilePath?: string;
  startedAt: string;
  updatedAt: string;
  steps: StepState[];
  timeline: TimelineEntry[];
}

export interface WireEvent {
  timestamp?: string;
  type?: string;
  owner?: string;
  level?: "info" | "warn" | "error";
  message?: string;
  stepNumber?: number;
  stepStatus?: StepStatus;
}

export interface CopilotExecutable {
  commandForTemplate: string;
  execFile: string;
  execArgsPrefix: string[];
}

export const CLI_COMMAND_TEMPLATE_SETTING = "visualFlow.copilotCli.commandTemplate";
export const CLI_TERMINAL_NAME_SETTING = "visualFlow.copilotCli.terminalName";

export const JIRA_FEATURE_AGENT = "jira-feature-intake";
export const FLOW_ORCHESTRATOR_AGENT = "flow-orchestrator";

export const AVAILABLE_AGENTS = [
  FLOW_ORCHESTRATOR_AGENT,
  JIRA_FEATURE_AGENT,
  "planner",
  "coder",
  "verifier",
  "diagnostics",
  "tech-refresh-orchestrator"
];

export const JIRA_SAMPLE_REQUEST =
  "Return exactly 10 Jira samples as a valid JSON array only. No markdown, no prose, no prefix text. Each item must contain id, title, and description string fields.";

export const WORKFLOW_STEP_NAMES = [
  "Identify Feature Details",
  "Technical Design",
  "Create User Stories",
  "Implementation",
  "Security Validation",
  "Test Verification and Coverage",
  "Compare and Adjust",
  "Troubleshooting and Debugging",
  "Continuous Improvement"
] as const;

export const STEP_DEFAULT_AGENTS: Record<number, "planner" | "coder" | "verifier"> = {
  1: "planner",
  2: "planner",
  3: "planner",
  4: "coder",
  5: "verifier",
  6: "verifier",
  7: "planner",
  8: "planner",
  9: "planner"
};

export const DEFAULT_FEATURE_OPTIONS: FeatureOption[] = [
  {
    id: "feature-placeholder",
    title: "Select a feature",
    description: "Load Jira samples to select a feature.",
    value: "feature-placeholder",
    label: "Select a feature"
  }
];

export class Logger {
  private readonly outputChannel: vscode.OutputChannel;
  private readonly workspaceRootPath: string | undefined;
  private readonly logFilePath: string | undefined;

  public constructor(outputChannel: vscode.OutputChannel, workspaceRootPath: string | undefined) {
    this.outputChannel = outputChannel;
    this.workspaceRootPath = workspaceRootPath;
    this.logFilePath = workspaceRootPath ? path.join(workspaceRootPath, ".visual-flow", "extension-debug.log") : undefined;
  }

  public log(message: string, data?: unknown): void {
    const timestamp = new Date().toISOString();
    const payload = data === undefined ? "" : ` ${safeStringify(data)}`;
    const line = `[${timestamp}] ${message}${payload}`;
    this.outputChannel.appendLine(line);
    void this.appendToFile(line + "\n");
  }

  private async appendToFile(content: string): Promise<void> {
    if (!this.workspaceRootPath || !this.logFilePath) {
      return;
    }

    try {
      await fs.mkdir(path.join(this.workspaceRootPath, ".visual-flow"), { recursive: true });
      await fs.appendFile(this.logFilePath, content, "utf8");
    } catch {
      // Logging failures should never break extension flow.
    }
  }
}

export function createInitialSteps(): StepState[] {
  const now = new Date().toISOString();
  return WORKFLOW_STEP_NAMES.map((name, index) => ({
    stepNumber: index + 1,
    name,
    status: "pending",
    owner: STEP_DEFAULT_AGENTS[index + 1] ?? "-",
    details: "",
    updatedAt: now
  }));
}

export function parseChecklistStatusUpdates(message: string): Array<{ stepNumber: number; stepName: string; status: StepStatus }> {
  const updates: Array<{ stepNumber: number; stepName: string; status: StepStatus }> = [];
  const normalizedMessage = message
    .replace(/\u001b\[[0-9;]*[A-Za-z]/g, "")
    .replace(/\r/g, "");

  const regex = /(?:^|\n)\s*(?:>\s*)?(?:[-*]\s*)?(?:[^\w\s]+\s*)*Step\s+(\d+)\s*(?:-|:)?\s*(.+?)\s*\[(pending|in-progress|completed|failed|skipped)\]/gi;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(normalizedMessage)) !== null) {
    const stepNumber = Number.parseInt(match[1], 10);
    const stepName = match[2].trim();
    const status = normalizeStatus(match[3]);
    if (stepNumber >= 1 && status) {
      updates.push({ stepNumber, stepName, status });
    }
  }
  return updates;
}

export function parseLineToWireEvent(line: string): WireEvent {
  try {
    const parsed = JSON.parse(line) as Record<string, unknown>;
    const message = stringOrUndefined(parsed.message) ?? line;
    const eventType = stringOrUndefined(parsed.type);
    const status = normalizeStatus(stringOrUndefined(parsed.stepStatus)) ?? mapEventTypeToStepStatus(eventType);
    const stepNumber = numberOrUndefined(parsed.stepNumber) ?? numberOrUndefined(parsed.step);
    const parsedOwner = firstNonEmpty([
      stringOrUndefined(parsed.owner),
      stringOrUndefined(parsed.actor),
      stringOrUndefined(parsed.source)
    ]);
    const inferredOwner = parsedOwner ?? inferAgentOwnerFromMessage(message);
    return {
      timestamp: stringOrUndefined(parsed.timestamp),
      type: eventType ?? (inferredOwner ? "agent-output" : undefined),
      owner: inferredOwner,
      level: normalizeLevel(stringOrUndefined(parsed.level)),
      message,
      stepNumber,
      stepStatus: status
    };
  } catch {
    const inferredOwner = inferAgentOwnerFromMessage(line);
    return {
      timestamp: new Date().toISOString(),
      type: inferredOwner ? "agent-output" : "raw-line",
      owner: inferredOwner ?? "copilot-cli",
      level: "info",
      message: line
    };
  }
}

export function parseFeatureOptionsFromCopilotOutput(stdout: string): FeatureOption[] {
  const text = normalizeCopilotText(stdout);
  if (text.length === 0) {
    throw new Error("Copilot CLI returned an empty Jira response.");
  }

  const candidates: Array<unknown[]> = [];
  for (const codeBlock of extractCodeBlocks(text)) {
    const parsed = tryParseJson(codeBlock);
    if (Array.isArray(parsed)) {
      candidates.push(parsed);
    } else if (parsed && typeof parsed === "object") {
      const record = parsed as Record<string, unknown>;
      for (const key of ["features", "items", "results", "data"]) {
        if (Array.isArray(record[key])) {
          candidates.push(record[key] as unknown[]);
        }
      }
    }
  }

  const firstArray = extractBracketArray(text);
  if (firstArray) {
    const parsed = tryParseJson(firstArray);
    if (Array.isArray(parsed)) {
      candidates.push(parsed);
    }
  }

  const direct = tryParseJson(text);
  if (Array.isArray(direct)) {
    candidates.push(direct);
  } else if (direct && typeof direct === "object") {
    collectArrayCandidatesFromObject(direct as Record<string, unknown>, candidates, 0);
  }

  for (const candidate of candidates) {
    const normalized = normalizeFeatureArray(candidate);
    if (normalized.length > 0) {
      return normalized;
    }
  }

  const jsonLike = parseFeaturesFromJsonLikeText(text);
  if (jsonLike.length > 0) {
    return jsonLike;
  }

  const fallback = parseFeaturesFromLines(text);
  if (fallback.length > 0) {
    return fallback;
  }

  throw new Error("Could not parse Jira features from Copilot CLI output.");
}

export function quoteForDoubleQuotedShellArg(value: string): string {
  return value.replace(/"/g, '\\"');
}

export function quoteForPowerShellSingleQuotedArg(value: string): string {
  return value.replace(/'/g, "''");
}

export function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value);
  } catch {
    return "null";
  }
}

export function normalizeStatus(value: string | undefined): StepStatus | undefined {
  if (!value) {
    return undefined;
  }
  const normalized = value.trim().toLowerCase();
  if (
    normalized === "pending" ||
    normalized === "in-progress" ||
    normalized === "completed" ||
    normalized === "failed" ||
    normalized === "skipped"
  ) {
    return normalized;
  }
  return undefined;
}

export function normalizeLevel(value: string | undefined): "info" | "warn" | "error" {
  if (value === "warn" || value === "error") {
    return value;
  }
  return "info";
}

export function numberOrUndefined(value: unknown): number | undefined {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }
  if (typeof value === "string" && value.trim().length > 0) {
    const parsed = Number.parseInt(value, 10);
    return Number.isNaN(parsed) ? undefined : parsed;
  }
  return undefined;
}

export function stringOrUndefined(value: unknown): string | undefined {
  return typeof value === "string" ? value : undefined;
}

export function firstNonEmpty(values: Array<string | undefined>): string | undefined {
  for (const value of values) {
    if (value && value.trim().length > 0) {
      return value.trim();
    }
  }
  return undefined;
}

function normalizeFeatureArray(items: unknown[]): FeatureOption[] {
  const features: FeatureOption[] = [];
  for (const item of items) {
    if (!item || typeof item !== "object") {
      continue;
    }
    const record = item as Record<string, unknown>;
    const id = firstNonEmpty([
      stringOrUndefined(record.id),
      stringOrUndefined(record.key),
      stringOrUndefined(record.issueKey),
      stringOrUndefined(record.ticket)
    ]);
    const title = firstNonEmpty([
      stringOrUndefined(record.title),
      stringOrUndefined(record.name),
      stringOrUndefined(record.summary)
    ]);
    const description = firstNonEmpty([
      stringOrUndefined(record.description),
      stringOrUndefined(record.details),
      stringOrUndefined(record.body)
    ]) ?? "";

    if (!id || !title) {
      continue;
    }

    features.push({
      id,
      title,
      description,
      value: id,
      label: `${id} - ${title}`
    });
  }
  return dedupeFeatures(features);
}

function parseFeaturesFromLines(text: string): FeatureOption[] {
  const features: FeatureOption[] = [];
  const lines = text.split(/\r?\n/);

  for (const rawLine of lines) {
    const line = rawLine.trim().replace(/^[-*]\s*/, "");
    if (!line) {
      continue;
    }

    let match = /^([A-Za-z][A-Za-z0-9]+-\d+)\s*[-:]\s*(.+?)(?:\s*[|–—-]\s*(.+))?$/.exec(line);
    if (match) {
      const id = match[1].trim();
      const title = match[2].trim();
      const description = (match[3] ?? "").trim();
      features.push({ id, title, description, value: id, label: `${id} - ${title}` });
      continue;
    }

    match =
      /id\s*:\s*([A-Za-z][A-Za-z0-9]+-\d+).+title\s*:\s*([^|,;]+)(?:.+description\s*:\s*(.+))?/i.exec(line);
    if (match) {
      const id = match[1].trim();
      const title = match[2].trim();
      const description = (match[3] ?? "").trim();
      features.push({ id, title, description, value: id, label: `${id} - ${title}` });
    }
  }

  return dedupeFeatures(features);
}

function parseFeaturesFromJsonLikeText(text: string): FeatureOption[] {
  const features: FeatureOption[] = [];
  const objectPattern = /\{[\s\S]*?\}/g;
  let objectMatch: RegExpExecArray | null;

  while ((objectMatch = objectPattern.exec(text)) !== null) {
    const block = objectMatch[0];
    const id = captureFirst(block, [/\"id\"\s*:\s*\"([^\"]+)\"/i, /\"key\"\s*:\s*\"([^\"]+)\"/i, /\"issueKey\"\s*:\s*\"([^\"]+)\"/i]);
    const title = captureFirst(block, [/\"title\"\s*:\s*\"([^\"]+)\"/i, /\"name\"\s*:\s*\"([^\"]+)\"/i, /\"summary\"\s*:\s*\"([^\"]+)\"/i]);
    const description = captureFirst(block, [/\"description\"\s*:\s*\"([\s\S]*?)\"/i, /\"details\"\s*:\s*\"([\s\S]*?)\"/i]) ?? "";

    if (!id || !title) {
      continue;
    }

    features.push({
      id: normalizeLooseString(id),
      title: normalizeLooseString(title),
      description: normalizeLooseString(description),
      value: normalizeLooseString(id),
      label: `${normalizeLooseString(id)} - ${normalizeLooseString(title)}`
    });
  }

  return dedupeFeatures(features);
}

function dedupeFeatures(features: FeatureOption[]): FeatureOption[] {
  const byId = new Map<string, FeatureOption>();
  for (const feature of features) {
    if (!byId.has(feature.id)) {
      byId.set(feature.id, feature);
    }
  }
  return [...byId.values()];
}

function extractCodeBlocks(text: string): string[] {
  const blocks: string[] = [];
  const regex = /```(?:json)?\s*([\s\S]*?)```/gi;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(text)) !== null) {
    const value = match[1]?.trim();
    if (value) {
      blocks.push(value);
    }
  }
  return blocks;
}

function extractBracketArray(text: string): string | undefined {
  for (let i = 0; i < text.length; i += 1) {
    if (text[i] !== "[") {
      continue;
    }

    const end = findMatchingJsonBracket(text, i, "[", "]");
    if (end === -1) {
      continue;
    }

    const candidate = text.slice(i, end + 1).trim();
    if (candidate.length > 1) {
      return candidate;
    }
  }
  return undefined;
}

function tryParseJson(value: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    return undefined;
  }
}

function captureFirst(value: string, patterns: RegExp[]): string | undefined {
  for (const pattern of patterns) {
    const match = pattern.exec(value);
    if (match?.[1]) {
      return match[1];
    }
  }
  return undefined;
}

function normalizeCopilotText(value: string): string {
  let normalized = value;

  normalized = normalized.replace(/\u0000/g, "");
  normalized = normalized.replace(/^\uFEFF/, "");
  normalized = normalized.replace(/\r\n/g, "\n");
  normalized = normalized.replace(/\u001b\[[0-9;]*[A-Za-z]/g, "");
  normalized = normalized.replace(/^[^\[\{]*(?=[\[\{])/, "");

  return normalized.trim();
}

function normalizeLooseString(value: string): string {
  return value
    .replace(/\\n/g, " ")
    .replace(/\r?\n/g, " ")
    .replace(/\s+/g, " ")
    .replace(/\\"/g, "\"")
    .trim();
}

function inferAgentOwnerFromMessage(message: string): string | undefined {
  const normalized = message
    .replace(/\u001b\[[0-9;]*[A-Za-z]/g, "")
    .replace(/\r?\n/g, " ")
    .trim();

  if (!normalized) {
    return undefined;
  }

  const match = /^(?:[-*•●]\s*)?(flow-orchestrator|planner|coder|verifier|diagnostics|tech-refresh-orchestrator|tech-refresh|visual-log)\b/i.exec(normalized);
  return match ? match[1].toLowerCase() : undefined;
}

function mapEventTypeToStepStatus(type: string | undefined): StepStatus | undefined {
  switch (type) {
    case "step.started":
    case "step.fix_applied":
      return "in-progress";
    case "step.completed":
      return "completed";
    case "step.failed":
      return "failed";
    case "step.skipped":
      return "skipped";
    default:
      return undefined;
  }
}

export function normalizeStepOwner(owner: string | undefined): "planner" | "coder" | "verifier" | undefined {
  const value = owner?.trim().toLowerCase();
  if (value === "planner" || value === "coder" || value === "verifier") {
    return value;
  }
  return undefined;
}

function collectArrayCandidatesFromObject(
  record: Record<string, unknown>,
  candidates: Array<unknown[]>,
  depth: number
): void {
  if (depth > 4) {
    return;
  }

  for (const key of ["features", "items", "results", "data", "issues", "tickets", "samples", "output"]) {
    if (Array.isArray(record[key])) {
      candidates.push(record[key] as unknown[]);
    }
  }

  for (const value of Object.values(record)) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      continue;
    }
    collectArrayCandidatesFromObject(value as Record<string, unknown>, candidates, depth + 1);
  }
}

function findMatchingJsonBracket(text: string, start: number, open: string, close: string): number {
  let depth = 0;
  let inString = false;
  let escaped = false;

  for (let i = start; i < text.length; i += 1) {
    const ch = text[i];

    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === "\"") {
        inString = false;
      }
      continue;
    }

    if (ch === "\"") {
      inString = true;
      continue;
    }

    if (ch === open) {
      depth += 1;
      continue;
    }

    if (ch === close) {
      depth -= 1;
      if (depth === 0) {
        return i;
      }
    }
  }

  return -1;
}
