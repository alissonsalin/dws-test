# Command Behavior

This page explains command execution behavior users should expect during feature workflows.

## Preflight Checks

Before validation commands, Copilot should verify:

1. Tool availability
2. Expected files
3. Working directory

## Fix-Driven Retries

If a command fails:

1. Copilot applies a material fix before retrying.
2. Copilot should not repeat the same unchanged failing pattern.

## Minimal Command Strategy

1. Use only policy-approved verification and security commands.
2. Do not run extra diagnostics unless explicitly requested.

## Java-Specific Notes

1. Java version inspection runs exactly once at Step 4 start.
2. Final verification uses the approved Gradle command policy.

## Test Command Stability

1. Test commands should come from the repository-approved command skills, not be improvised per run.
2. Java test execution should use the exact command policy from `.github/skills/java-cli/SKILL.md`.
3. Node.js and Python test execution should use the command-selection policy from `.github/skills/node-python-cli/SKILL.md`.
4. If the repository already defines a test script or wrapper command, reuse it instead of switching to a different runner command.

## Security Command Stability

1. Security-validation commands should come from the repository-approved command skills, not be improvised per run.
2. Java security validation should use the exact command policy from `.github/skills/java-cli/SKILL.md`.
3. Node.js and Python security validation should use the command-selection policy from `.github/skills/node-python-cli/SKILL.md`.
4. If the repository already defines a security script or wrapper command, reuse it instead of switching to a different scanner command.

## Next

Continue to [Feature Flow Prompts](feature-flow-prompts.md).