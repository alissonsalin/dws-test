Follow this workflow to create a new feature from scratch.

# Feature Start Checklist (Required)
- When starting any feature implementation request, present a checklist with Steps 1 to 9 and track status as `pending`, `in-progress`, `completed`, `failed`, or `skipped`.
- Use icon-based step status indicators in every checklist update:
  - `✅` completed
  - `🔄` in-progress
  - `⏳` pending
  - `❌` failed/blocker
  - `⏭` skipped
- Follow `.github/instructions/workflow-status.instructions.md` as the reference source for checklist status icons and formatting.
- Include checkpoints for every step in the checklist, not only command steps:
  - Step 1 checkpoint: feature source identified and requirement summary captured.
  - Step 2 checkpoint: technical design created, confirmation requested, and explicit user approval captured.
  - Step 3 checkpoint: user stories and Definition of Done checklist created and confirmed.
  - Step 4 checkpoint: implementation completed according to clean architecture and language rules, only after Step 2 approval is captured.
  - Step 5 checkpoint: security/dependency validation handled according to command policy and explicit user gate decision captured (run or skip).
  - Step 6 checkpoint: tests and approved verification command completed.
  - Step 7 checkpoint: implementation compared against requirements/design and gaps reviewed.
  - Step 8 checkpoint: troubleshooting actions and monitoring/debug notes captured when needed.
  - Step 9 checkpoint: improvements documented and completion gate satisfied.
- Include command checkpoints in the same checklist as sub-checkpoints:
  - Step 4 Java setup: Java detection command executed exactly once for Java feature workflows, following repository command-line instruction files.
  - Step 5 security validation command: run only when dependency or plugin changes require it, per command-line instruction rules.
  - Step 5 gate decision: always ask whether to run CVE validation and record explicit user answer before Step 5 execution.
  - Step 6 verification command: run the approved verification command according to repository command-line instructions.
- Keep the checklist updated as work progresses and include it in feature progress updates.
- At the start of each step, always print the full Step 1 to Step 9 checklist with icon and current status so progress can be tracked continuously.
- Before final handoff, ensure Step 9 checklist gates are marked complete.

# Interactive Prompt Format (Required)
- For every interactive question or gate, present options as a numbered list with icons.
- Use this exact option style for yes/no confirmations:
  - `1. ✅ Yes`
  - `2. ❌ No`
- Example prompt format:
  - `Would you like to continue?`
  - `1. ✅ Yes`
  - `2. ❌ No`
- If a gate needs more than two choices, keep the same numbered + icon format and include one clear recommended option.

# Design-First Enforcement (Hard Stop)
- No code generation, code edits, or source file creation is allowed before Step 2 is approved.
- Treat the following as blocked before Step 2 approval: creating or editing `.java`, `.kt`, `.js`, `.ts`, `.py`, test files, build files, or running implementation commands.
- Allowed before Step 2 approval: requirements analysis, technical design documentation, user stories, and clarification questions.
- If asked to generate code before Step 2 approval, refuse implementation and continue only with design completion and approval capture.
- Before entering Step 4, explicitly restate that Step 2 status is `completed` and approval is recorded.

# Flow Checklist Template (Use at Feature Start)
- Use this exact structure when a feature implementation starts:
  - ⏳ Step 1 - Identify Feature Details `[pending|in-progress|completed|failed|skipped]`
    - [ ] Source identified and requirement summary captured.
  - ⏳ Step 2 - Create Technical Design `[pending|in-progress|completed|failed|skipped]`
    - [ ] Technical design created, confirmation requested, and approval explicitly recorded.
  - ⏳ Step 3 - Create User Stories `[pending|in-progress|completed|failed|skipped]`
    - [ ] Stories and Definition of Done checklist created and confirmed.
  - ⏳ Step 4 - Start Implementation `[pending|in-progress|completed|failed|skipped]`
    - [ ] Step 2 technical design is completed and confirmed before implementation starts.
    - [ ] Pre-implementation gate passed: Step 2 status is `completed` and approval is recorded in the progress update.
    - [ ] Implementation completed according to architecture/language rules.
    - [ ] Java feature only: Java detection command executed exactly once.
  - ⏳ Step 5 - Security Validation `[pending|in-progress|completed|failed|skipped]`
    - [ ] Security/dependency validation completed per command policy.
  - ⏳ Step 6 - Create Unit Tests `[pending|in-progress|completed|failed|skipped]`
    - [ ] Tests completed and approved verification command executed.
  - ⏳ Step 7 - Compare & Adjust `[pending|in-progress|completed|failed|skipped]`
    - [ ] Implementation compared against requirements/design and gaps reviewed.
  - ⏳ Step 8 - Troubleshooting & Debugging `[pending|in-progress|completed|failed|skipped]`
    - [ ] Troubleshooting actions and monitoring/debug notes captured when needed.
  - ⏳ Step 9 - Continuous Improvement `[pending|in-progress|completed|failed|skipped]`
    - [ ] Improvements documented and completion gate satisfied.

# Step 1: Identify Feature Details
- Ask me where the source of the feature details is (file, Jira, Confluence, or direct input).
- Gather the content and summarize the requirements clearly.
- If the feature details come from a file, treat that file as the single source of truth for the feature and avoid drifting from it during later steps.
- When a feature file contains a stable identifier (for example `LRA-1234`), use that identifier to name related feature documents consistently.

# Step 2: Create Technical Design
- Propose a technical design solution based on the feature details.
- Include architecture diagrams or structured text (modules, layers, data flow).
- Ensure clean architecture principles are applied.
- Create two component diagrams for every technical design — both are mandatory. Follow `.github/instructions/docs.instructions.md` for diagram format rules.
Use a template for the technical design document that includes:
    - Requirement Summary
    - Technical Design (architecture, data flow, validation rules, technologies used like frameworks and libs, database schema). Use ASCIIDOC or Markdown for structured documentation.
    - API Design (if applicable)
    - Backward Compatibility Considerations
  - Impact and Risk Assessment (mandatory):
    - Performance impact analysis (latency, throughput, resource usage, caching implications, and expected hotspots)
    - Internal feature impact check (identify which existing features can be affected and how to validate no regression)
    - External dependency check (identify external projects/services this feature depends on, including failure/timeout behavior)
    - External impact check (identify whether this feature can impact external projects/services and define mitigations)
- For API features, add a contract-first mini-step in the design: define request payloads, response payloads, and error payloads before implementing controllers, use cases, or repositories.
- Ask me to confirm or refine the design before implementation.
- Create only one design document per feature and save it as `documentation/<feature-name>/<feature-name>-design.md`.
- Do not generate or modify implementation code while Step 2 is `pending` or `in-progress`.

# Step 3: Create User Stories
- Break down the feature into user stories.
- Each user story should be small enough to be implemented and tested independently.
- Each story must have clear acceptance criteria that can be used for testing.
- Each story should be linked to the relevant part of the technical design for traceability and the feature.
- Each story should have:
  - Title
  - Description
  - Acceptance Criteria
  - Assigned to a developer (if applicable)
- Create a small Definition of Done checklist per feature.
  - Include endpoint behavior, validation errors, persistence or DB write expectations, architecture test coverage, and required documentation updates.
- Ensure stories are clear, testable, and cover all requirements.
- Ask me to confirm or refine the user stories before proceeding.

# Step 4: Start Implementation
- Do not start Step 4 until Step 2 technical design is created and explicitly confirmed.
- Mandatory gate at Step 4 start: print checklist status showing Step 2 as `completed` and approval captured before any code action.
- Implement the feature in the requested language (Java, NodeJS, Python, or SQL).
- Follow clean architecture and language-specific implementation rules from applicable instruction files in `.github/instructions/`.
- During implementation consider best practices for performance, scalability, and maintainability.
- Fetch entity relationships and data flow from the design document and feature definition to ensure consistency.
- Validate code style and formatting according to language standards. Also use Linting tools as needed (e.g., Checkstyle for Java, ESLint for NodeJS, Pylint for Python).
- Generate code snippets step by step.
- Add logs at key points in the code for better traceability and debugging.
- Add logs for error handling to capture exceptions and important events.
- Automatically update existing code as needed (including unit tests).
- Batch implementation changes first and prefer a single verification pass at the end unless you are blocked and need to troubleshoot.
- Use a delta-first file reading approach for each new feature: read the feature details source and directly impacted files first, and avoid broad re-reading of unchanged classes unless needed for debugging, regressions, or ambiguity resolution.
  - Definition of directly impacted files: files expected to be edited for this feature plus immediate interfaces/DTOs/tests/documentation tied to those edits.
  - Do not re-read unchanged classes across unrelated modules when the requirement and impacted files are already clear.
  - Expand reading scope only when a failing test, architectural violation, merge conflict, or unclear dependency requires additional context.
- If a file is used for feature details, use it name to create all other documentation files
- Always run all steps and sub-steps in order, do not skip any step.
- Always confirm assumptions with me before proceeding.
- Keep the process iterative by sharing checkpoints and assumptions, while continuing non-interactively through steps.
- Do not pause for confirmation after every step by default; stop only for destructive or ambiguous actions, or explicit interactive gates defined in this workflow.
- Continue the workflow on recoverable command errors and keep troubleshooting until the issue is fixed.
- Before each workflow validation command, run preflight checks for required tools, expected files, and working directory context to reduce avoidable failures.
- If a command fails, apply a material fix before retrying and avoid repeating the same failing pattern unchanged.
- Step 5 exception to non-interactive mode: do not auto-skip CVE validation due to non-interactive execution; explicitly ask for run/skip decision first.
- If the workspace is not a git repository (no `.git`), skip git-state checks and proceed with file-based validation.
- For Java features, follow Java-specific framework, package, dependency, and configuration rules from applicable instruction files in `.github/instructions/`.
- For Java features, follow Lombok annotation rules from `.github/instructions/lombok.instructions.md` if Lombok is used in the project.
- For NodeJS and Python features, follow command-resilience and retry-reduction rules from applicable instruction files in `.github/instructions/`.
- Create one troubleshooting/debugging markdown file per feature (e.g., `documentation/<feature-name>/<feature-name>-troubleshooting.md`). Aside from the technical design and troubleshooting file, avoid unrelated markdown files.
- Respect markdown file creation limits: only `README.md`, feature design (`documentation/<feature-name>/<feature-name>-design.md`), feature troubleshooting (`documentation/<feature-name>/<feature-name>-troubleshooting.md`), and Step 9 improvements files (`improvements/session-dd-mm-yyyy.md`) are allowed.
- Hard constraint: do not create any other markdown files during the feature workflow unless the user explicitly requests that specific file.
- If a new markdown file outside the allowed list seems necessary, stop and ask for explicit approval before creating it.
- Create `README.md` if it does not exist and keep it updated with links to feature documentation and project run/test commands.
- For API features, follow OpenAPI, resilience, and caching guidance from applicable instruction files in `.github/instructions/`.
- For API features, prefer dependency-driven OpenAPI generation and controller annotations; do not create standalone Swagger/OpenAPI files unless the user explicitly requests them.

# Step 5: Security - Validate and update code and libraries
- For dependency and security validation command usage, follow the repository command-line instruction files.
- Interactive Step 5 gate: ask me whether I want to run CVE validation for the feature before executing any CVE validation command.
- If my answer is no, mark CVE validation as skipped, record that explicit decision, and continue automatically to Step 6.
- If my answer is yes, run CVE validation according to the repository command-line instruction files.
- If there is no explicit answer, do not execute Step 5 CVE commands and do not mark it as skipped by assumption; ask again and keep Step 5 as `in-progress`.
- check for any security vulnerabilities in the code and dependencies.
- Update any outdated libraries or frameworks to their latest secure versions.
- Ensure that sensitive data is handled securely (e.g., encryption, environment variables).
- Implement input validation and sanitization to prevent common security issues (e.g., SQL injection, XSS).
- Add a dependency scanning gate in CI before merge when dependency or plugin changes are introduced.
- Enforce payload size limits and request rate limiting for write endpoints when applicable.
- Implement payload size and rate limiting protections as reusable configuration components, not per-endpoint ad-hoc logic unless explicitly justified.
- Do not run extra validation commands outside the policy defined in the repository command-line instruction files.
- If vulnerabilities are found, fix code or dependencies first, then re-run only as allowed by the command-line instruction files.
- Do not mark Step 5 as failed for recoverable validation issues; keep Step 5 as `in-progress` while applying fixes and rerunning policy-allowed commands.

# Step 6: Create Unit Tests
- Write unit tests for all critical paths and edge cases.
- Target high automated coverage for changed critical paths, and use stricter coverage goals for core business logic.
- Create tests for both successful scenarios and failure cases (e.g., invalid input, exceptions).
- Use mocking frameworks as needed to isolate units of code.
- Consider create tests for performance, scalability and security aspects if applicable.
- Use appropriate testing frameworks (JUnit, Mocha/Chai, PyTest, etc.).
- Show me the coverage report or summary.
- For Java coverage floors, JaCoCo generation, and report-reuse behavior, follow `.github/instructions/testing.instructions.md` as the source of truth.
- Automatically add or modify existing tests as needed.
- Update tests to reflect any changes made during the implementation or security review.
- Follow the repository command-line instruction files for verification command timing, retries, OS-specific variants, and setup inspection rules.
- Execute test and coverage commands using a non-interactive approach (no prompts, no interactive menus, no input waiting).
- Do not mark Step 6 as failed for recoverable verification issues; keep Step 6 as `in-progress` while fixing root causes and rerunning policy-allowed verification.

# Step 7: Compare & Adjust
- Compare the implemented solution with the original feature details and technical design.
- Identify mismatches or gaps.
- If a mismatch is found between design documentation and implementation, update the design document to match the implemented architecture before final handoff.
- For Java clean architecture, explicitly verify repository/port placement: `Repository` interface at business boundary (`usecase`) and concrete implementation in `gateway`.
- Suggest adjustments to align implementation with design and requirements.
- Ask me to confirm before making changes.

# Step 8: Troubleshooting & Debugging
- If there are any issues during implementation or testing, identify the root cause.
- Use logs and debugging tools to trace the problem.
- Propose solutions to fix the issues.
- Implement fixes and re-run tests to ensure the problem is resolved.
- Document any significant issues and their resolutions in the technical design document for future reference.
- Create Splunk queries or other monitoring tools to track the health and performance of the feature in production. Use logs generated during implementation to create meaningful queries.

# Step 9: Continuous Improvement
- Step 9 is mandatory for every feature and cannot be skipped, even when no major issues are found.
- Run Step 9 after Step 8 and before final handoff.
- Do not finalize a feature until Step 9 outputs are documented and reviewed with the user.
- Review all previous steps for possible improvements.
- Suggest updates to templates, prompts, or design patterns.
- Document lessons learned for future features. 
- Save all suggestions for improvements in the `improvements` folder using this file pattern: `session-dd-mm-yyyy.md`.
  - Example: `improvements/session-11-04-2026.md`.
  - Update the same session file when adding new improvements in the same day/session.
    - More efficient implementation patterns.
    - Improved testing strategies.
    - Enhanced security practices.
    - Commands used during the process. This will be helpful for future reference and for other features to avoid errors and improve efficiency.
      - Gradle commands
      - Testing commands
      - Debugging commands
      - Any other relevant commands used during the implementation, testing, or debugging process.
    - Keep a deferred backlog section in the improvements file for non-critical ideas that should not be implemented immediately.
    - If command execution fails during the feature workflow, save the failure details in the improvements output for future reuse.
- Ask me if I want to apply improvements now or save them for later. Ask me that at the end of the step after all improvements have been identified and documented, and before making any changes to templates or instructions files.
- Step 9 completion gate:
  - Improvements file exists and is updated.
  - Improvements file path follows `improvements/session-dd-mm-yyyy.md`.
  - Deferred backlog section is present.
  - Command failures are captured when applicable.
  - User decision is recorded: apply now or save for later.

Verification Commands (Windows PowerShell if applicable):
- Use copyable commands in fenced `powershell` blocks when sharing execution steps.
- Prefer batching implementation changes first and running verification once at the end of the feature.
- Mandatory flow: complete implementation first, run the approved verification command at the end, and if it fails, follow the retry policy from the repository command-line instruction files.
- Follow the repository command-line instruction files for the exact command, OS-specific variant, and failure-handling rules.
- Command minimization policy: do not run extra Gradle or diagnostic commands outside Step 5/Step 6 approved flow unless the user explicitly requests them or a retry is required by policy after a failure.
- Coverage and gap-analysis commands may be executed only when explicitly requested by the user.


# Deliverables:
- Technical design document (concise, structured). Save the documentation in a folder "documentation" with a clear naming convention (e.g., `feature-name-design.md`). Save in root directory if the documentation is general and not specific to a feature.
- Implementation code following clean architecture.
- Unit test suite with coverage report.
- Suggested improvements to the workflow or templates or copilot_instructions.md and agents.md.

# Parameters:
- Source type: [file | Jira | Confluence | user input]
- Language: [Java | NodeJS | Python | SQL]