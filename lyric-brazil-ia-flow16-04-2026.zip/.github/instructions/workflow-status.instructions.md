---
description: "Use when flow-orchestrator or tech-refresh presents workflow progress and must enforce the Step 1 to Step 9 checklist with icon-based statuses."
---

# Workflow Status Checklist Rules

- At workflow startup and each step transition, print the full Step 1 to Step 9 checklist as mandatory user-visible output.
- If a tool call happens first, the first assistant message after the tool call must begin with the checklist before any other text.
- For the first visible workflow message, show Step 1 as `in-progress` and all later steps as `pending` unless a different status is already known.
- After the TODO list or internal step state marks a new step as `in-progress`, print the checklist immediately in the next user-visible message.
- After the workflow finishes, print the full checklist one final time using final statuses before the closing summary.
- Render the checklist as a vertical list with exactly one workflow step per line; never inline it as a paragraph or wrapped sentence.
- Keep one status per step line using this format:
  - <icon> Step N - <step name> [<status>]
- Use these status values only:
  - pending
  - in-progress
  - completed
  - failed
  - skipped
- Update statuses as the workflow advances and keep completed steps visible.
- Preserve line breaks exactly so the chat UI shows a readable list.
- Do not ask a question, summarize findings, or explain the next action before the checklist is printed.

# Exact Checklist Format

Always output the checklist as a markdown bullet list — each step on its own line prefixed with `- `. Use a blank line before and after the block. Copy this format exactly:

- 🔄 Step 1 - Identify Feature Details [in-progress]
- ⏳ Step 2 - Technical Design [pending]
- ⏳ Step 3 - Create User Stories [pending]
- ⏳ Step 4 - Implementation [pending]
- ⏳ Step 5 - Security Validation [pending]
- ⏳ Step 6 - Test Verification and Coverage [pending]
- ⏳ Step 7 - Compare and Adjust [pending]
- ⏳ Step 8 - Troubleshooting and Debugging [pending]
- ⏳ Step 9 - Continuous Improvement [pending]

Never omit the `- ` prefix. Never join steps into a single line or paragraph.

# Final Checklist Format

When the workflow is finished, print the same checklist with final statuses. Use `completed` for finished steps and `skipped` for intentionally bypassed steps.

Example final state for the current flow:

- ✅ Step 1 - Identify Feature Details [completed]
- ✅ Step 2 - Technical Design [completed]
- ✅ Step 3 - Create User Stories [completed]
- ✅ Step 4 - Implementation [completed]
- ⏭ Step 5 - Security Validation [skipped]
- ✅ Step 6 - Test Verification and Coverage [completed]
- ✅ Step 7 - Compare and Adjust [completed]
- ✅ Step 8 - Troubleshooting and Debugging [completed]
- ✅ Step 9 - Continuous Improvement [completed]

# Icon Map

- `✅` -> completed
- `🔄` -> in-progress
- `⏳` -> pending
- `❌` -> failed
- `⏭` -> skipped
