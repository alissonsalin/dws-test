# Custom Instructions

## Purpose

This page documents the instruction files used by Copilot during feature workflows. It focuses on the workspace entrypoint and the scoped `.instructions.md` files that load automatically by file pattern.

This repository now keeps the automatic instruction surface intentionally small. Framework-specific and language-specific implementation guidance that is only needed during active development has been moved into on-demand skills.

## How Instruction Loading Works

- The workspace entrypoint is defined in `.github/copilot-instructions.md`.
- File-scoped instructions are defined in `.github/instructions/*.instructions.md`.
- Each instruction file has an `applyTo` pattern that determines when it is loaded.
- When more than one instruction applies, use the most specific file as source of truth for detailed behavior.

## Workspace Entrypoint

The workspace entrypoint is `.github/copilot-instructions.md`.

It is responsible for:

- pointing feature work to the `flow-orchestrator` agent
- listing always-on instruction files
- listing on-demand skills
- defining shared feature deliverables and workspace-level expectations

## Instruction Files in This Repository

### `.github/instructions/workflow-status.instructions.md`

- Enforces the Step 1 to Step 9 checklist with icon-based statuses at each workflow transition.

### `.github/instructions/design-first.instructions.md`

- Blocks implementation actions until Step 2 design approval is captured.

### `.github/instructions/command-resilience.instructions.md`

- Enforces minimal, goal-oriented commands with fix-driven retries and preflight checks.

### `.github/instructions/docs.instructions.md`

- Defines documentation writing quality, structure, diagrams, and consistency.

### `.github/instructions/readme.instructions.md`

- Defines README-specific content expectations including project purpose, technologies, install steps, and run steps.

### `.github/instructions/release-notes.instructions.md`

- Defines release-note expectations including release format, features by release, and links to repository documentation.

### `.github/instructions/clean-architecture.instructions.md`

- Enforces `domain`, `usecase`, `adapter`, `gateway` boundaries with inward dependency direction.

### `.github/instructions/testing.instructions.md`

- Defines test authoring expectations: happy path, error path, edge cases, and coverage floors.

### `.github/instructions/tech-refresh.instructions.md`

- Enforces prerequisite analysis and approval before Step 1 to Step 9 for migration work.

### Specialized concerns moved to skills

Language-specific, framework-specific, and CLI implementation guidance is loaded on demand through skills instead of being always-on. See [Skills](skills.md) for the full list.

## Precedence and Conflict Handling

1. Use `.github/copilot-instructions.md` as the workspace entrypoint.
2. Use the relevant file-level instruction as source of truth for technical detail.
3. If two file-level rules overlap, prioritize the more specific domain file:
   - testing details: `.github/instructions/testing.instructions.md`
   - architecture tests: `.github/skills/archunit/SKILL.md`
   - Spring config/annotations: `.github/skills/spring/SKILL.md`
   - API contract behavior: `.github/skills/openapi/SKILL.md`
4. Keep workspace entrypoints and workflow files concise and avoid duplicating deep technical rules.
5. Use the tech refresh agent and instruction only for migration-style work; keep default feature flow unchanged for ordinary delivery.

## Operational Rules

- Design approval is required before implementation actions.
- Tech refresh work requires prerequisite analysis approval before Step 1 starts.
- Language, framework, and CLI specifics are loaded through skills during active development instead of being always-on.

## Related References

- [For Developers - Overview](overview.md)
- [Agents](agents.md)
- [Skills](skills.md)
- [Clean Architecture](clean-architecture.md)
- [Unit test](unit-test.md)
- [Flow - Step 2](../flow/step-2.md)
- [Flow - Step 6](../flow/step-6.md)
