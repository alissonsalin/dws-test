# Step 9: Continuous Improvement

## Purpose

The final step captures insights from feature development to improve future features, templates, processes, and team practices. This step ensures that every feature delivery makes the next one faster, safer, and higher quality.

## Mandatory Execution Rule

- Step 9 is required for every feature and must run after Step 8.
- Do not close or hand off the feature before Step 9 is completed.
- Run Step 9 even when no major issues were found; in that case, document "no major improvements" and keep at least one follow-up observation.

## Why This Step Matters

Without reflection:
- The same mistakes repeat in future features
- Improvements are never incorporated into templates or workflows
- Team knowledge is lost when people move on
- Opportunities to streamline processes are missed

Continuous improvement:
- Reduces cycle time for future features
- Improves code quality and consistency
- Builds team expertise
- Makes processes more efficient

## What You'll Do

1. **Review All Previous Steps**:
   - Which steps went smoothly? Why?
   - Which steps had challenges? What caused them?
   - Did the time estimates match actual effort?
   - Were there any surprises or learnings?

2. **Document Lessons Learned**:
   - Write observations and insights in `improvements/session-dd-mm-yyyy.md`
   - Include both successes and challenges
   - Be specific: what worked, what didn't, and why

3. **Suggest Process Improvements**:
   - Can the feature workflow be streamlined?
   - Were there ambiguous requirements that could be clarified earlier?
   - Did design decisions take longer than expected?
   - Were there unnecessary tools or steps?

4. **Track Deferred Improvements**:
   - Keep non-critical follow-up ideas in a single deferred backlog section
   - Include items that were intentionally postponed to keep scope tight
   - Revisit only when they are prioritized by the team or stakeholder

5. **Collect Command Examples**:
   - Document commands actually used during the feature and note whether they were policy-approved or explicitly user-requested
   - Note testing commands and patterns
   - Capture debugging approaches and tools
   - Include any shell scripts or automation created
   - If a command failed, capture the key error, root cause, applied fix, and retry result

   Example:
   ```markdown
   ## Commands Used in This Feature

   ### Build and Test
   - `./gradlew.bat test --console=plain` — Run tests with readable output

   ### Debugging
   - Used remote debugger on port 5005 to trace login flow
   - Logged user state transitions to track session lifecycle

   ### Dependency Management
   - Updated Spring Boot from 3.0.0 to 3.1.5 for security patches
   ```

6. **Suggest Template and Tool Updates**:
   - Should project templates be updated based on this feature?
   - Are there new best practices to capture in `.github/agents/feature-flow.agent.md`, `.github/copilot-instructions.md`, or `.github/instructions/`?
   - Should `.github/skills/` or `.github/instructions/` files be enhanced?
   - Are there new testing patterns to document?

   Example:
   ```markdown
   ## Suggested Template Updates

   - Add "Database Schema Design" section to technical design template
   - Add Redis integration steps to deployment checklist
   - Create example test for async operations (wasn't covered before)
   ```

7. **Identify Reusable Patterns**:
   - Was there common code that should be extracted into a utility library?
   - Are there design patterns that could be documented and reused?
   - Should this code become a template for similar features?

8. **Share Learnings with Team**:
   - Ask if improvements should be applied now or saved for later
   - Plan when to implement process improvements
   - Share command examples and debugging approaches with the team

## Improvement Categories

### More Efficient Implementation Patterns
- Reusable architecture patterns
- Common utility functions or base classes
- Faster ways to implement similar features
- Tools or libraries that speed up development

### Improved Testing Strategies
- Testing patterns discovered or refined
- Edge cases that should always be tested
- Mocking patterns that work well
- Performance test approaches

### Enhanced Security Practices
- New security checks discovered
- Validation patterns that work well
- Secrets management improvements
- Compliance checklist items

### Operational Improvements
- Monitoring and debugging approaches
- Logging patterns that help troubleshooting
- Deployment steps that went smoothly or had issues
- Performance optimization techniques

## Improvement Documentation Template

```markdown
# feature-name-improvements.md

## What Went Well
- Clear requirements upfront saved rework
- Design review caught architecture issues early
- Test coverage revealed edge cases before deployment

## What Was Challenging
- Database migration testing took longer than expected
- Performance testing revealed N+1 query problems

## Suggested Process Improvements
- Add "Database Migration Strategy" to technical design template
- Clarify non-functional requirements (performance targets, dependency constraints) in requirements step
- Add SQL query optimization checklist to implementation step

## Deferred Backlog
- Retrieval endpoint for audit history
- Explicit OpenAPI file generation
- Conflict-handling refinements for concurrent updates

## Commands for Future Reference
- Test with coverage: `.\gradlew test jacocoTestReport jacocoTestCoverageVerification`
- Debug remote: `java -agentlib:jdwp=transport=dt_socket,server=y,suspend=y,address=5005 -jar app.jar`
- Profile with JFR: `java -XX:+FlightRecorder -XX:StartFlightRecording=filename=app.jfr -jar app.jar`

## Command Failures Captured
- `./gradlew.bat test --console=plain` failed due to missing test fixture configuration
- Root cause: test resources were not loaded by the Gradle source set
- Fix applied: updated test source-set configuration
- Retry result: passed on second run

## Reusable Patterns
- UserSessionCache pattern works well for this domain
- Resilience4j configuration for external APIs should be documented

## Next Steps
- [ ] Update feature-flow.agent.md or related instructions with database migration guidance
- [ ] Add performance testing examples to testing.instructions.md
- [ ] Schedule team discussion on lessons learned
```

## Output

- Comprehensive improvements document in `improvements/session-dd-mm-yyyy.md`
- List of process improvements (prioritized)
- Examples of commands and techniques created during the feature
- Reusable patterns identified
- Suggested updates to templates, instructions, and documentation

## Completion Gate

Step 9 is complete only when all of the following are true:
- Improvements document is created or updated at `improvements/session-dd-mm-yyyy.md`
- Deferred backlog section exists for non-critical ideas
- Command failures are captured when they occurred
- A user decision is recorded: apply improvements now or save for later

## When To Complete

This is the final step. When complete:
- All learnings are documented
- Team has reviewed suggestions
- Priority improvements are scheduled for implementation
- Future features will benefit from these learnings

---

**Previous Step:** [Step 8 - Troubleshooting & Debugging](step-8.md)  
**Back to:** [Get Started Guide](../get-started.md)
