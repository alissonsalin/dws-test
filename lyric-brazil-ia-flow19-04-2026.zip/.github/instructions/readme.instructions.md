---
applyTo: "**/README.md"
description: "Use when creating or updating README files to keep project overviews consistent and complete."
---

# README Authoring Rules

- Update an existing `README.md` when present.
- Create `README.md` only when it does not already exist.
- Keep the README concise, practical, and oriented to new contributors or users.
- Include these core sections when relevant:
  - purpose of the project
  - technologies
  - how to install
  - how to run
  - link to release notes
- Prefer short setup and run steps with concrete commands.
- Avoid duplicating deep documentation that already lives under `docs/`; link to detailed pages when needed.
- Keep terminology aligned with the rest of the repository.

# Quality Checks Before Finalizing

- Confirm install and run instructions match the repository files that actually exist.
- Ensure the README explains what the project is before setup details.
- Prefer updating existing sections over adding repetitive new sections.