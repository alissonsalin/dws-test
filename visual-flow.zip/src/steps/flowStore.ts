import * as vscode from "vscode";
import { promises as fs } from "fs";
import * as path from "path";
import {
  createInitialSteps,
  FLOW_ORCHESTRATOR_AGENT,
  Logger,
  normalizeLevel,
  normalizeStatus,
  normalizeStepOwner,
  parseChecklistStatusUpdates,
  parseLineToWireEvent,
  RunState,
  StepStatus,
  TimelineEntry,
  WireEvent
} from "./shared";

const AGENT_TIMELINE_OWNERS = new Set([
  "flow-orchestrator",
  "planner",
  "coder",
  "verifier",
  "diagnostics",
  "tech-refresh",
  "tech-refresh-orchestrator",
  "visual-log"
]);

export class FlowStore implements vscode.Disposable {
  private state: RunState | undefined;
  private readonly emitter = new vscode.EventEmitter<RunState | undefined>();
  private attachedEventFilePath: string | undefined;
  private processedLineCount = 0;
  private pollingTimer: NodeJS.Timeout | undefined;
  private readonly logger: Logger;
  private lastNarrativeOwner: string | undefined;

  public constructor(logger: Logger) {
    this.logger = logger;
  }

  public get onDidChangeState(): vscode.Event<RunState | undefined> {
    return this.emitter.event;
  }

  public getState(): RunState | undefined {
    return this.state;
  }

  public startRun(
    runId: string,
    feature: RunState["feature"],
    selectedAgent: string,
    instruction: string,
    destinationPath: string,
    eventFilePath?: string
  ): RunState {
    const now = new Date().toISOString();
    this.lastNarrativeOwner = undefined;
    const steps = createInitialSteps();
    if (selectedAgent === FLOW_ORCHESTRATOR_AGENT) {
      steps[0].status = "in-progress";
      steps[0].updatedAt = now;
      steps[0].details = "Step started";
    }

    this.state = {
      runId,
      status: "running",
      selectedAgent,
      feature,
      instruction,
      destinationPath,
      eventFilePath,
      startedAt: now,
      updatedAt: now,
      steps,
      timeline: []
    };

    this.pushTimeline({
      timestamp: now,
      level: "info",
      type: "run-started",
      owner: "extension",
      message: `Run started with agent ${selectedAgent}.`
    });
    this.emit();
    return this.state;
  }

  public completeRun(message: string): void {
    if (!this.state) {
      return;
    }
    this.state.status = "completed";
    this.state.updatedAt = new Date().toISOString();
    this.pushTimeline({
      timestamp: this.state.updatedAt,
      level: "info",
      type: "run-completed",
      owner: "extension",
      message
    });
    this.emit();
  }

  public failRun(message: string): void {
    if (!this.state) {
      return;
    }
    this.state.status = "failed";
    this.state.updatedAt = new Date().toISOString();
    this.pushTimeline({
      timestamp: this.state.updatedAt,
      level: "error",
      type: "run-failed",
      owner: "extension",
      message
    });
    this.emit();
  }

  public recordEvent(event: WireEvent): void {
    if (!this.state) {
      return;
    }

    const timestamp = event.timestamp ?? new Date().toISOString();
    const message = (event.message ?? "").trim() || "Event received";
    const level = event.level ?? "info";
    const inferredOwner = inferAgentOwnerFromMessage(message);
    const eventOwner = event.owner?.trim();
    const inheritedOwner = !inferredOwner && !eventOwner && isBulletPrefixedNarrative(message)
      ? this.lastNarrativeOwner
      : undefined;
    const resolvedOwner = inferredOwner ?? eventOwner ?? inheritedOwner;
    const normalizedOwner = resolvedOwner?.toLowerCase();
    const isAgentOwner = normalizedOwner ? AGENT_TIMELINE_OWNERS.has(normalizedOwner) : false;

    if (isAgentOwner) {
      this.lastNarrativeOwner = normalizedOwner;
    }

    // Keep step status updates simple: if checklist lines are present, trust them.
    const checklistUpdates = parseChecklistStatusUpdates(message);
    const failureSummary = summarizeFailureDetails(message);
    const effectiveChecklistUpdates = checklistUpdates.map((update) => ({
      ...update,
      status: shouldKeepStepInProgress(update.stepNumber, update.status, failureSummary) ? "in-progress" : update.status
    }));
    const effectiveEventStepStatus = shouldKeepStepInProgress(event.stepNumber, event.stepStatus, failureSummary)
      ? "in-progress"
      : event.stepStatus;
    const firstChecklistUpdate = effectiveChecklistUpdates[0];
    const timelineStepNumber = event.stepNumber ?? firstChecklistUpdate?.stepNumber;
    const timelineStepStatus = effectiveEventStepStatus ?? firstChecklistUpdate?.status;
    const baseTimelineType =
      effectiveChecklistUpdates.length > 0
        ? "step-status"
        : event.type ?? mapStepStatusToTimelineType(effectiveEventStepStatus);
    const timelineType =
      isAgentOwner && (!baseTimelineType || !isMilestoneEventType(baseTimelineType.toLowerCase()))
        ? "agent-output"
        : baseTimelineType;
    const timelineMessage =
      effectiveChecklistUpdates.length > 0
        ? effectiveChecklistUpdates.map((update) => `${update.stepName} [${update.status}]`).join(" | ")
        : message;
    const isMainMilestone =
      effectiveChecklistUpdates.length > 0 ||
      level === "warn" ||
      level === "error" ||
      timelineType === "agent-output" ||
      timelineType === "milestone" ||
      timelineType === "artifact-created" ||
      timelineType === "artifact-updated" ||
      timelineType === "run-started" ||
      timelineType === "run-completed" ||
      timelineType === "run-failed" ||
      (typeof timelineStepNumber === "number" && timelineStepStatus !== undefined && timelineStepStatus !== "pending");

    if (isMainMilestone) {
      this.pushTimeline({
        timestamp,
        level,
        type: timelineType,
        owner: normalizedOwner ?? eventOwner,
        message: timelineMessage,
        stepNumber: timelineStepNumber,
        stepStatus: timelineStepStatus
      });
    }

    const failedChecklistStep = checklistUpdates.find((update) => update.status === "failed");
    if (failedChecklistStep) {
      if (failureSummary) {
        this.pushTimeline({
          timestamp,
          level: "warn",
          type: "step-failure-summary",
          owner: normalizedOwner ?? eventOwner,
          message: `Step ${failedChecklistStep.stepNumber} failure summary: ${failureSummary}`,
          stepNumber: failedChecklistStep.stepNumber,
          stepStatus: shouldKeepStepInProgress(failedChecklistStep.stepNumber, failedChecklistStep.status, failureSummary)
            ? "in-progress"
            : "failed"
        });
      }
    }

    for (const update of effectiveChecklistUpdates) {
      this.updateStep(update.stepNumber, update.status, event.owner, update.stepName, timestamp);
    }

    if (event.stepNumber && effectiveEventStepStatus) {
      this.updateStep(event.stepNumber, effectiveEventStepStatus, event.owner, message, timestamp);
    }

    this.state.updatedAt = timestamp;

    this.emit();
  }

  public updateStep(
    stepNumber: number,
    status: StepStatus,
    owner?: string,
    details?: string,
    updatedAt?: string
  ): void {
    if (!this.state) {
      return;
    }
    const step = this.state.steps.find((entry) => entry.stepNumber === stepNumber);
    if (!step) {
      return;
    }

    const now = updatedAt ?? new Date().toISOString();
    step.status = status;
    const normalizedOwner = normalizeStepOwner(owner);
    if (normalizedOwner) {
      step.owner = normalizedOwner;
    }
    step.details = details ?? step.details;
    step.updatedAt = now;
    this.state.updatedAt = now;
    this.emit();
  }

  public attachEventFile(eventFilePath: string): void {
    this.attachedEventFilePath = eventFilePath;
    this.processedLineCount = 0;
    this.logger.log("Attached event file for polling.", { eventFilePath });

    void fs
      .mkdir(path.dirname(eventFilePath), { recursive: true })
      .then(async () => {
        await fs.appendFile(eventFilePath, "", "utf8");
      })
      .catch((error) => {
        this.logger.log("Failed to ensure event file exists before polling.", { error: String(error) });
      });

    this.startPolling();
  }

  public detachEventFile(): void {
    this.attachedEventFilePath = undefined;
    this.processedLineCount = 0;
    this.stopPolling();
  }

  public dispose(): void {
    this.stopPolling();
    this.emitter.dispose();
  }

  private startPolling(): void {
    this.stopPolling();
    this.pollingTimer = setInterval(() => {
      void this.pollEventFile();
    }, 100);
  }

  private stopPolling(): void {
    if (!this.pollingTimer) {
      return;
    }
    clearInterval(this.pollingTimer);
    this.pollingTimer = undefined;
  }

  private async pollEventFile(): Promise<void> {
    if (!this.attachedEventFilePath) {
      return;
    }

    try {
      const content = await fs.readFile(this.attachedEventFilePath, "utf8");
      const lines = content.split(/\r?\n/).filter((line) => line.trim().length > 0);
      if (lines.length <= this.processedLineCount) {
        return;
      }

      const newLines = lines.slice(this.processedLineCount);
      this.processedLineCount = lines.length;
      for (const line of newLines) {
        this.recordEvent(parseLineToWireEvent(line));
      }
    } catch (error) {
      const err = error as NodeJS.ErrnoException;
      if (err?.code === "ENOENT") {
        return;
      }
      this.logger.log("Failed to poll event file.", { error: String(error) });
    }
  }

  private pushTimeline(entry: TimelineEntry): void {
    if (!this.state) {
      return;
    }

    const message = entry.message.trim();
    if (!message) {
      return;
    }

    const eventType = entry.type?.toLowerCase();
    if (eventType && !isMilestoneEventType(eventType)) {
      return;
    }
    if (message.startsWith("Run started with agent")) {
      return;
    }

    const normalizedMessage = normalizeTimelineMessage(message, eventType);
    if (normalizedMessage.length === 0) {
      return;
    }

    const timelineEntry: TimelineEntry = {
      timestamp: entry.timestamp,
      level: normalizeLevel(entry.level),
      type: entry.type,
      owner: entry.owner,
      stepNumber: entry.stepNumber,
      stepStatus: normalizeStatus(entry.stepStatus),
      message: normalizedMessage
    };

    const duplicate = this.state.timeline.find(
      (item) =>
        item.type === timelineEntry.type &&
        item.stepNumber === timelineEntry.stepNumber &&
        item.stepStatus === timelineEntry.stepStatus &&
        item.message === timelineEntry.message
    );
    if (duplicate && timelineEntry.type !== "agent-output") {
      return;
    }

    this.state.timeline.push(timelineEntry);
    if (this.state.timeline.length > 200) {
      this.state.timeline = this.state.timeline.slice(this.state.timeline.length - 200);
    }
  }

  private emit(): void {
    this.emitter.fire(this.state ? cloneRunState(this.state) : undefined);
  }
}

function cloneRunState(state: RunState): RunState {
  return {
    ...state,
    steps: state.steps.map((step) => ({ ...step })),
    timeline: state.timeline.map((entry) => ({ ...entry }))
  };
}

function isMilestoneEventType(type: string): boolean {
  return (
    type.startsWith("run-") ||
    type.startsWith("run.") ||
    type === "agent-output" ||
    type === "milestone" ||
    type === "artifact-created" ||
    type === "artifact-updated" ||
    type === "step-status" ||
    type.startsWith("step.") ||
    type === "step-started" ||
    type === "step-completed" ||
    type === "step-failed" ||
    type === "step-skipped" ||
    type === "step-failure-summary"
  );
}

function mapStepStatusToTimelineType(status: StepStatus | undefined): string | undefined {
  switch (status) {
    case "in-progress":
      return "step-started";
    case "completed":
      return "step-completed";
    case "failed":
      return "step-failed";
    case "skipped":
      return "step-skipped";
    default:
      return undefined;
  }
}

function normalizeTimelineMessage(message: string, eventType?: string): string {
  if (!eventType) {
    return message;
  }

  const stepMatch = /step\s+(\d+)/i.exec(message);
  const stepNumber = stepMatch ? stepMatch[1] : undefined;
  const stepLabel = stepNumber ? `Step ${stepNumber}` : "Step";

  switch (eventType) {
    case "step.started":
    case "step-started":
      return `${stepLabel} started`;
    case "step.completed":
    case "step-completed":
      return `${stepLabel} completed`;
    case "step.failed":
    case "step-failed":
      return `${stepLabel} failed`;
    case "step.skipped":
    case "step-skipped":
      return `${stepLabel} skipped`;
    case "run.completed":
    case "run-completed":
      return "Run completed";
    case "run.failed":
    case "run-failed":
      return "Run failed";
    default:
      return message;
  }
}

function inferAgentOwnerFromMessage(message: string): string | undefined {
  const normalized = message
    .replace(/\u001b\[[0-9;]*[A-Za-z]/g, "")
    .replace(/\r?\n/g, " ")
    .trim();

  if (!normalized) {
    return undefined;
  }

  const match = /^(?:[-*•●]\s*)?(flow-orchestrator|planner|coder|verifier|diagnostics|tech-refresh-orchestrator|tech-refresh|visual-log)\b/i.exec(normalized);
  return match ? match[1].toLowerCase() : undefined;
}

function isBulletPrefixedNarrative(message: string): boolean {
  const normalized = message
    .replace(/\u001b\[[0-9;]*[A-Za-z]/g, "")
    .trim();

  if (!/^(?:[•●]|[-*])\s+/u.test(normalized)) {
    return false;
  }

  return inferAgentOwnerFromMessage(normalized) === undefined;
}

function summarizeFailureDetails(message: string): string | undefined {
  const normalized = message
    .replace(/\u001b\[[0-9;]*[A-Za-z]/g, "")
    .replace(/\r/g, "");

  const checklistLineRegex = /^\s*(?:[-*]\s*)?(?:[\u2705\u274c\u23f3\u23ed\u{1f504}]\s*)?Step\s+\d+\s*(?:-|:)?\s*.+?\[(?:pending|in-progress|completed|failed|skipped)\]\s*$/iu;
  const detailLines = normalized
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .filter((line) => !checklistLineRegex.test(line));

  if (detailLines.length === 0) {
    return undefined;
  }

  const compact = detailLines.join(" ").replace(/\s+/g, " ").trim();
  if (compact.length <= 220) {
    return compact;
  }
  return `${compact.slice(0, 217).trimEnd()}...`;
}

function shouldKeepStepInProgress(
  stepNumber: number | undefined,
  status: StepStatus | undefined,
  summary: string | undefined
): boolean {
  if (stepNumber !== 6 || status !== "failed" || !summary) {
    return false;
  }

  const normalized = summary.toLowerCase();
  const recoverableSignals = [
    "rerun",
    "re-run",
    "retry",
    "fix",
    "repair",
    "targeted fix",
    "send",
    "sent back to the coder",
    "coverage",
    "threshold",
    "blocked by build configuration",
    "dependencies are resolving",
    "configuration"
  ];

  return recoverableSignals.some((signal) => normalized.includes(signal));
}
