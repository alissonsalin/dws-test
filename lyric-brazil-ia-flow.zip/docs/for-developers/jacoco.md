# JaCoCo

## Purpose

JaCoCo provides the Java coverage-report and verification model used in this repository for Gradle-based Java projects.

Primary runtime source: `.github/skills/jacoco/SKILL.md`.

## When To Use

Use JaCoCo guidance when:

1. a Java project needs coverage reporting
2. a Gradle build is missing coverage verification tasks
3. Step 6 requires report review or threshold enforcement
4. a coverage failure must be diagnosed before test work is considered complete

## Required Build Configuration

- Keep JaCoCo configuration in `build.gradle` or `build.gradle.kts`.
- Apply the Gradle JaCoCo plugin for Java projects that require coverage reporting.
- Define both `jacocoTestReport` and `jacocoTestCoverageVerification` when Java coverage setup is added or repaired.
- Keep coverage verification attached to the build lifecycle by wiring `check` with `dependsOn jacocoTestCoverageVerification`.
- Keep coverage configuration in the build, not in shell-only steps or manual notes.

## Coverage Verification Model

Use layer-based verification instead of chasing a single global 100% line-coverage target.

- `domain`: 90%+ line coverage
- `usecase`: 90%+ line coverage
- `gateway`: 90%+ line coverage
- `adapter`: prioritize controller, contract, slice, or integration correctness over raw unit-only coverage targets

Do not close Java test work if changed `domain`, `usecase`, or `gateway` code is below the documented floor unless the gap is explicitly documented and approved.

## Approved Command Relationship

Use `.github/skills/java-cli/SKILL.md` as the source of truth for the exact approved Java test-and-coverage command.

For this repository, the standard combined verification flow is:

```powershell
.\gradlew test jacocoTestReport jacocoTestCoverageVerification
```

Use the OS-appropriate variant when not on Windows, but keep the same task sequence.

## Report Review Checklist

After running Java tests with coverage:

1. open the JaCoCo HTML report
2. confirm the changed packages and layers are represented
3. identify line or branch gaps in changed business logic
4. note any failing threshold or verification rule
5. share a short summary with outcome, gaps, and report path when available

If a valid current JaCoCo report already exists and the code under review has not changed since that report, summarize the existing report instead of rerunning coverage when that is sufficient for the task.

## Example Gradle Intent

Use this as a conceptual baseline only. Adapt naming and syntax to the existing build.

```gradle
plugins {
    id 'java'
    id 'jacoco'
}

tasks.named('check') {
    dependsOn tasks.named('jacocoTestCoverageVerification')
}
```

## Recommended Failure Handling

- Treat JaCoCo verification failures as test-completion blockers for changed Java business layers.
- Fix missing tests or incorrect verification rules before relaxing thresholds.
- If a temporary exception is unavoidable, document the reason, the affected package or layer, and the removal plan.
- Do not bypass the repository-approved command flow with ad-hoc alternative coverage commands.

## Separation Of Concerns

- Use [Java](languages/java.md) for Java implementation baseline rules.
- Use [Unit test](unit-test.md) for cross-language testing expectations.
- Use [Arch Unit](arch-unit.md) for Java architecture boundary tests.
- Use `.github/skills/java-cli/SKILL.md` for exact command selection and execution timing.

## Related Flow Steps

- [Step 4 - Start Implementation](../flow/step-4.md)
- [Step 6 - Create Unit Tests](../flow/step-6.md)
- [Step 7 - Compare & Adjust](../flow/step-7.md)