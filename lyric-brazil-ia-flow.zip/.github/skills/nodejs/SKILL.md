---
name: nodejs
description: "Use when explicitly starting Node.js or TypeScript feature implementation. Covers Node.js clean architecture structure, routing boundaries, dependency patterns, testing, and runtime quality rules for this project."
argument-hint: "Describe the Node.js feature, affected layers, and whether HTTP APIs or external integrations are involved"
---

# Node.js Implementation Rules

- Follow clean architecture boundaries: domain, usecase, adapter, gateway.
- For command execution resilience and retry-reduction behavior, follow `.github/skills/node-python-cli/SKILL.md`.
- Keep business logic in use cases and domain, not controllers or route handlers.
- Keep controllers and route handlers focused on input/output mapping and delegation.
- Use constructor-based or module-level dependency injection.
- Prefer TypeScript for type safety and maintainability if the project uses it.
- Use async and await for asynchronous operations; avoid callback-heavy flows.
- Maintain immutable data structures where practical.

# Project Structure and Dependencies

- Organize code in `src/domain`, `src/usecase`, `src/adapter`, and `src/gateway` directories.
- Keep dependencies declared in `package.json` with clear versions.
- Use npm workspaces for monorepo management if applicable.
- Document dependency changes and updates in commit messages or project notes when required by the workflow.
- Pin production dependencies to known-good versions; use `^` for minor updates only.

# Express.js and API Conventions

- Use Express middleware for request logging and error handling at boundaries when Express is in use.
- Keep route definitions in dedicated route files.
- Use `app.use()` only for middleware; keep route handlers thin.
- Return consistent JSON response formats.
- Use appropriate HTTP status codes.
- Document API endpoints with clear error scenarios.

# Code Quality and Testing

- Use consistent linting and formatting with project-adopted tools such as ESLint and Prettier.
- Validate and sanitize inputs at route boundaries.
- Never expose sensitive data in logs or responses.
- Use environment variables for configuration and secrets.
- Write unit tests with Jest or Mocha and use meaningful test names.
- Aim for strong coverage on critical business logic.

# Reliability and Performance

- Use connection pooling for database access.
- Implement retry logic with exponential backoff for external API calls.
- Use caching for frequently accessed data when justified.
- Prefer async operations over blocking calls.
- Add request timeouts and circuit breakers for external dependencies.

# Security Best Practices

- Validate and sanitize all external inputs.
- Use HTTPS in production and enforce secure cookie settings when cookies are used.
- Hash passwords with bcrypt or equivalent and never store plaintext.
- Use JWT or session-based authentication and validate tokens on protected endpoints.
- Keep dependencies updated and run dependency audit checks during validation phases.
- Encrypt sensitive data at rest and in transit.