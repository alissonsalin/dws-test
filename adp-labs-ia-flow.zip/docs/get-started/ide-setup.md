# IDE Setup

After installation, set up and verify your IDE environment.

## Visual Studio Code

1. Open the target repository in Visual Studio Code.
2. Confirm these paths exist:
   - .github/copilot-instructions.md
   - .github/instructions/
3. Ensure GitHub Copilot and Copilot Chat extensions are installed and authenticated.
4. Open Copilot Chat and start a new chat session.

## IntelliJ IDEA

1. Open the target repository in IntelliJ IDEA.
2. Confirm these paths exist:
   - .github/copilot-instructions.md
   - .github/instructions/
3. Ensure the GitHub Copilot plugin is installed and authenticated.
4. Open GitHub Copilot Chat and start a new chat session.

## Next Step

Go to [Copilot Usage](copilot-usage.md).