---
name: java
description: "Use when explicitly starting Java feature implementation. Covers Java package structure, naming conventions, repository and gateway placement, Java 21 baseline, and implementation rules for this project."
argument-hint: "Describe the Java feature, affected layers, and whether Spring, Lombok, or HTTP APIs are involved"
---

# Java Implementation Rules

- Follow clean architecture boundaries: domain, usecase, adapter, gateway.
- Keep business logic in use cases and domain, not controllers.
- Keep controllers focused on input/output mapping and delegation.
- Use the feature entity name as a class-name prefix for Java classes in `gateway`, controller/adapter, and `usecase` layers.
  - Examples for entity `Client`: `ClientController`, `ClientRepository`, `ClientGateway`, `RegisterClientUseCase`, `ClientCommand`, `ClientResponse`.
  - Use `Repository` for the business-facing interface and `Gateway` for the concrete outer-layer implementation.
  - Keep `Repository` interfaces in `usecase` boundary packages.
  - Keep `Gateway` implementations in `gateway` packages.
  - Do not create generic names like `Controller`, `Repository`, `Gateway`, `UseCase`, or names ending with `Impl` without the entity prefix.
  - Do not use implementation names with technology-specific prefixes or suffixes such as `JdbcClientGateway`, `ClientGatewayJdbc`, `JpaClientGateway`, or `RestClientGateway`.
- Standardize a reusable command-response mapping pattern for controller-to-usecase boundaries to reduce duplicate mapping code.
- Introduce shared validation helpers in the `usecase` package for common API field checks and consistent validation errors.
- Use constructor-based dependency injection.
- Use Java 21 or superior language level.
- Do not create generic adapter subpackages such as `http`, `filter`, or `interceptor` by default. For HTTP features, keep controllers and transport models under the feature package, for example `adapter/client/controller`, unless the user or approved design explicitly requires a dedicated filter or interceptor.
- For Java entity and DTO classes, follow `.github/skills/lombok/SKILL.md` for Lombok annotations. Lombok is mandatory for all DTOs, entities, commands, and responses in this repository. If Lombok is missing from `build.gradle` or `build.gradle.kts`, add it during implementation setup before implementing those classes. Do not use Java `record` classes for these types.
- For Java domain POJOs/value objects, also apply Lombok conventions from `.github/skills/lombok/SKILL.md`. If Lombok is missing from the build, add it before implementing or refactoring those classes.
- Follow `.github/skills/spring/SKILL.md` for Spring Boot framework conventions, REST structure, and required Spring YAML configuration files.
- Follow `.github/skills/archunit/SKILL.md` for Java architecture test requirements that enforce `domain`, `usecase`, `adapter`, and `gateway` boundaries.
- Follow `.github/skills/java-cli/SKILL.md` for Java environment inspection and command timing.
- Follow `.github/skills/jacoco/SKILL.md` for Java coverage configuration, verification rules, and JaCoCo report expectations.
- Use the Java version and environment-inspection flow from `.github/skills/java-cli/SKILL.md`: run detection once at implementation start, configure 21+ when available, confirm before forcing 21 when the detected version is lower, and keep compilation and runtime versions aligned.
- Prefer immutable domain models and builder patterns where helpful.

# Recommended Java Package Structure

**Required** Use `com.adp` as the base package for all Java code. Under that root, use clean-architecture layer packages with an entity- or feature-specific subpackage inside each layer. Keep cross-feature shared code minimal and intentional.

Keep the application entry class name as `Application.java`. Do not rename or replace it with another application-class name during implementation unless the user explicitly requests that change.

## Detailed Example Package Tree

```text
src/main/java/com/adp/
├── Application.java
├── domain/
│   └── client/
│       ├── Client.java
│       ├── ClientId.java
│       ├── ClientStatus.java
│       └── exception/
│           └── DuplicateClientException.java
├── usecase/
│   └── client/
│       ├── RegisterClientUseCase.java
│       ├── GetClientUseCase.java
│       ├── repository/
│       │   └── ClientRepository.java
│       ├── command/
│       │   └── RegisterClientCommand.java
│       ├── query/
│       │   └── GetClientQuery.java
│       ├── response/
│       │   └── ClientResponse.java
│       └── validation/
│           └── ClientValidation.java
├── adapter/
│   └── client/
│       └── controller/
│           ├── ClientController.java
│           ├── request/
│           │   └── RegisterClientRequest.java
│           └── response/
│               └── ClientHttpResponse.java
├── gateway/
│   └── client/
│       ├── ClientGateway.java
│       ├── entity/
│       │   └── ClientRecord.java
│       ├── mapper/
│       │   └── ClientGatewayMapper.java
│       └── config/
│           └── ClientGatewayConfiguration.java
└── configuration/
  └── ClientApiConfiguration.java
```

## Layer Placement Rules

1. Put core business state and invariants in `domain`.
2. Start every Java package with `com.adp`.
3. Inside each layer root package, create an entity- or feature-specific package such as `domain/client` or `usecase/client` before placing classes for that entity.
4. Put application orchestration, repository interfaces, commands, queries, responses, and shared business validation in `usecase`.
5. Put HTTP-facing request and response models in `adapter` under the entity package, for example `adapter/client/controller`.
6. Do not introduce `adapter/<feature>/http/filter` or similar generic transport subtrees unless a filter/interceptor is explicitly required by the user or approved design.
7. Put database or integration implementations in `gateway` under the entity package.
8. Use `configuration` only for Spring `@Configuration` classes and bean wiring, and keep it as a global package instead of nesting configuration by entity.

# Java Naming Conventions

- Every class in `usecase`, `adapter`, and `gateway` layers must use the entity name as the class-name prefix.
- Use names such as `ClientController`, `ClientRepository`, `ClientGateway`, `RegisterClientUseCase`, `RegisterClientCommand`, and `ClientResponse` as the required naming pattern.
- Use verb-plus-entity naming for use cases, for example `RegisterClientUseCase` or `GetClientUseCase`.
- Use `Repository` only for the business-facing interface and `Gateway` only for the outer implementation.
- Do not use generic names like `Service`, `Helper`, `Manager`, `Processor`, `Controller`, `Repository`, or `UseCase` without the entity prefix.
- Do not use names ending with `Impl`.
- Do not use technology-specific prefixes or suffixes such as `JdbcClientRepository`, `JpaClientGateway`, `RestClientGateway`, or `ClientGatewayJdbc`.
- Use business-oriented names in `domain`, for example `Client`, `ClientId`, `ClientStatus`, and `DuplicateClientException`.
- Use `Request` only for adapter-layer transport models and avoid reusing HTTP request models inside `usecase` or `domain`.

# Reliability and Security

- Validate and sanitize inputs at boundaries.
- Do not expose sensitive data in logs.
- Prefer resilient integration patterns for external dependencies.
- Add or update tests for success and failure paths when behavior changes.