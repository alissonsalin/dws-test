# Command Behavior

This page explains command execution behavior users should expect during feature workflows.

## Preflight Checks

Before validation commands, Copilot should verify:

1. Tool availability
2. Expected files
3. Working directory

## Fix-Driven Retries

If a command fails:

1. Copilot applies a material fix before retrying.
2. Copilot should not repeat the same unchanged failing pattern.

## Minimal Command Strategy

1. Use only policy-approved verification and security commands.
2. Do not run extra diagnostics unless explicitly requested.

## Java-Specific Notes

1. Java version inspection runs exactly once at Step 4 start.
2. Final verification uses the approved Gradle command policy.

## Next

Continue to [Feature Flow Prompts](feature-flow-prompts.md).