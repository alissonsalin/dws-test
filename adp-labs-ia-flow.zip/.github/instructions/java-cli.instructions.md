---
applyTo: "**/*.{java,kt,gradle,kts,yml,yaml,md}"
description: "Use when suggesting or executing command-line workflows for Java projects in this repository."
---

# Java Command Execution Rules

- Use this file as the source of truth for Java command selection, timing, OS variants, retry policy, and failure handling.
- Prefer Gradle Wrapper instead of system Gradle.
- Run commands from the project root unless a different path is explicitly required.
- Keep command usage minimal and goal-oriented.
- Avoid destructive commands unless explicitly requested.
- Do not use interactive commands when a non-interactive alternative exists.

# Commands by Phase

- Step 4 implementation and build setup:
  - For new Java projects, or when the project is not yet buildable, add or update required `build.gradle` or `build.gradle.kts` dependencies and plugins during Step 4.
  - Complete framework bootstrap and required dependency setup before running validation or verification commands.
  - If missing dependencies or plugins are the reason a command would fail, fix the build configuration first instead of using later validation runs to discover missing setup.
  - Treat Step 4 dependency or plugin changes as the trigger for any later dependency-security validation.

- Java environment inspection:
  - Windows: `java -version`
  - MacOS/Linux: `java --version`
  - For Java feature implementation workflows, run this inspection exactly once at the start of Step 4 implementation.
  - Do not run this inspection again later in the workflow unless the user explicitly requests it.
  - This is a hard constraint to avoid repeated environment checks.
  - This inspection does not replace dependency-security validation or final verification commands.
  - Parse the major Java version from the first version token in command output.
    - Example parse targets: `java version "21.0.2"` -> `21`, `openjdk 22.0.1` -> `22`, `java version "1.8.0_402"` -> `8`.
  - Apply this decision policy after parsing:
    - If detected major version is 21 or higher, use the detected major version for project Java configuration.
    - If detected major version is lower than 21, configure project Java version to 21 and note that local JDK upgrade is required for runtime execution.
  - If parsing fails or output is ambiguous, do not guess; request explicit version confirmation before changing Java version settings.

# Constraints and Retry Policy

- Follow `.github/instructions/command-resilience.instructions.md` as the source of truth for preflight checks, retry behavior, command minimization, and failure reporting.

# Output and Reporting

- Summarize results in plain language after execution.
- Highlight only relevant lines such as errors, warnings, pass/fail status, and artifact paths.
