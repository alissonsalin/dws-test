# Step 8: Troubleshooting & Debugging

## Purpose

Despite careful planning and testing, issues may arise during implementation or testing. This step provides a structured approach to identify root causes, fix problems, and document learnings for future reference and production monitoring.

## Why This Step Matters

Ignoring issues:
- Leads to problems in production that could have been caught
- Wastes time on unrelated debugging later
- Reduces user confidence in the feature
- Prevents learning from mistakes

Systematic troubleshooting:
- Identifies root causes (not just symptoms)
- Fixes problems completely, not just temporarily
- Provides insights for production monitoring
- Builds team knowledge

## What You'll Do

1. **Identify Issues** — Issues may come from:
   - Failed tests during Step 6
   - Design mismatches discovered in Step 7
   - Performance problems under load testing
   - Security vulnerabilities missed in Step 5
   - Integration problems with external systems

2. **Root Cause Analysis**:
   - **Reproduce the issue**: Can you reliably trigger it with specific input?
   - **Isolate the problem**: Is it in your code, a dependency, or infrastructure?
   - **Trace the execution**: Use logs and debugging tools to follow the code path
   - **Ask why repeatedly**: Keep asking "why?" until you find the root cause

   Example:
   ```
   Problem: Login endpoint returns 500 error
   Why? → Database query failed
   Why? → User table doesn't exist in test database
   Why? → Migration script wasn't run before tests
   Root Cause: Test setup doesn't run migrations
   Fix: Update test configuration to run migrations before test suite
   ```

3. **Use Logs and Debugging Tools**:
   - Review application logs for error messages and stack traces
   - Use a debugger to step through code and inspect variables
   - Check database state and query performance
   - Monitor system resources (CPU, memory) for performance issues

4. **Propose and Implement Fixes**:
   - Propose a fix that addresses the root cause (not just the symptom)
   - Implement the fix in code
   - Verify the fix with a focused test
   - Re-run full test suite to ensure no regressions

5. **Re-Validate**:
   - Run all tests again to confirm the fix works
   - Verify that no new issues were introduced
   - Update tests if the issue reveals a missing test case

6. **Document the Issue**:
   - Record what went wrong and how it was fixed
   - Update the technical design document with any architectural changes
   - Note any edge cases that should be tested in similar features

## Production Monitoring and Observability

For production deployment, create monitoring and debugging tools:

### Logging Queries (Example)

For Java with Slf4j and aggregated logging (Splunk, ELK, etc.):

```java
// Log login attempts and outcomes
logger.info("Login attempt", 
    kv("user_email", email),
    kv("status", result ? "success" : "failed"),
    kv("timestamp", System.currentTimeMillis())
);

// Log errors with context
logger.error("Database connection failed",
    kv("database", "users_db"),
    kv("retry_attempt", retryCount),
    kv("error", e.getMessage())
);
```

### Splunk Query Examples

```
source=application.log login_attempt
| stats count by status
| timechart count by status

source=application.log error
| grep "Database connection failed"
| stats count by database
```

### Circuit Breaker Monitoring

If using Resilience4j:
```java
circuitBreaker.onEvent(event -> 
    logger.warn("Circuit breaker state change",
        kv("name", "external-api"),
        kv("state", event.getStateTransition().getToState()),
        kv("timestamp", System.currentTimeMillis())
    )
);
```

## Output

- All identified issues have been root-cause analyzed and fixed
- Full test suite passes after fixes
- Documentation of issues and solutions
- Production monitoring queries prepared
- Lessons learned recorded for team knowledge

## When To Proceed

Before moving to Step 9:
- All issues discovered have been investigated and fixed
- Tests pass consistently
- Root causes are understood
- Production monitoring is in place
- Team understands what to watch for in production

---

**Previous Step:** [Step 7 - Compare & Adjust](step-7.md)  
**Next Step:** [Step 9 - Continuous Improvement](step-9.md)
