---
applyTo: "**/*.{java,kt,gradle,kts}"
description: "Use when implementing Java features to apply Lombok annotations for reducing boilerplate code and improving readability."
---

# Lombok Usage Rules

- If the project already includes Lombok as a dependency, use Lombok for all DTOs, entities, commands, and responses. Lombok is mandatory in this case, not optional.
- If the project does not yet have Lombok as a dependency, stop and propose the Gradle/Maven dependency addition before implementing entity/DTO classes.
- Do not use Java `record` classes for DTOs, entities, commands, or responses. Always use Lombok `@Data` + `@Builder` instead for consistency.

# Builder Pattern for Object Creation

- Always use `@Builder` annotation from Lombok for creating objects with multiple fields.
- Use `@Builder` on entity classes, DTOs, request/response payloads, and command objects.
- When using `@Builder`, place it on the class level, not on constructor methods.
- Ensure the class also includes `@Data` or equivalent field accessors for proper serialization.

# Lombok Annotations Best Practices

- Use `@Data` for simple domain entities and DTOs — generates `@Getter`, `@Setter`, `@ToString`, `@EqualsAndHashCode`, `@RequiredArgsConstructor`.
- Use `@Getter` and `@Setter` separately when you need finer control over field access.
- Use `@RequiredArgsConstructor` for constructor-based dependency injection in service classes (Spring beans).
- Use `@NoArgsConstructor` and `@AllArgsConstructor` only when explicitly needed (rarely).
- Use `@Slf4j` for logger injection in service and controller classes.
- Avoid `@EqualsAndHashCode` on entities with JPA relationships to prevent circular comparison issues.
- Document the rationale for excluding specific Lombok features in code comments when intentional.

# Lombok and Clean Architecture

- Use `@Builder` on domain entities (`domain` layer) for immutable object creation.
- Use `@Builder` on use case command objects (`usecase` layer) for clear request construction.
- Use `@Builder` on DTOs and response objects (`adapter` layer) for API consistency.
- Ensure Lombok-generated code does not violate clean architecture boundaries.

# Verification

- Ensure Lombok annotation processing is enabled in your IDE and build tool.
- Verify that generated code compiles and runs without errors.
- Include Lombok's annotation processor in the Gradle/Maven build configuration:
  - For Gradle: `annotationProcessor 'org.projectlombok:lombok'`
  - Verify it is listed in `build.gradle` or `build.gradle.kts` under `compileOnly` and `annotationProcessor`
