# Tech Refresh Orchestrator Prompts

Use this page when you want one conversation to coordinate both migration analysis and implementation through explicit agent handoffs.

## When To Use It

Use the `tech-refresh-orchestrator` agent when:

1. you want prerequisite migration analysis first
2. you want explicit approval before implementation starts
3. you want the approved analysis handed into the standard feature workflow automatically
4. you want `tech-refresh` and `flow-orchestrator` to stay separate instead of mixing both responsibilities into one run

## What It Does

The orchestrator runs in two phases:

1. hand off to `tech-refresh` for prerequisite analysis and approval readiness
2. after explicit approval, hand off to `flow-orchestrator` for Step 1 to Step 9 delivery using the approved analysis as source context

The recommended UI flow uses handoff buttons:

1. `Start Prerequisite Analysis`
2. `Continue To Flow Orchestrator`

Both buttons are defined on the orchestrator agent. Use the second button only after the approval gate is answered with `Yes`.

## Prompt Structure

Include these details when possible:

1. migration scope
2. current system or module
3. target stack
4. source context such as file paths, Jira IDs, or Confluence pages
5. any known target project path

## Example A: NodeJS To Java Migration

```text
@tech-refresh-orchestrator Use handoff-based tech refresh for the billing notification module.
Current system: NodeJS service in services/billing-notifications.
Target stack: Java Spring Boot.
Source context: docs/migrations/billing-notifications.md.
Start with prerequisite analysis through tech-refresh.
After approval, continue through flow-orchestrator using the approved analysis as source context.
```

## Example B: Framework Modernization

```text
@tech-refresh-orchestrator Modernize the customer-profile API from legacy Spring MVC to current Spring Boot patterns.
Current module: customer-profile-api.
Target stack: Java Spring Boot 3.x.
Source context: Jira CPR-1842 and docs/architecture/customer-profile-modernization.md.
Run prerequisite analysis first and stop for approval before implementation handoff.
```

## Example C: Migration With Explicit Target Path

```text
@tech-refresh-orchestrator Migrate the contract renewal job from Python to Java.
Current module: jobs/contract-renewal.
Target stack: Java.
Target path: services/contract-renewal-java.
Source context: Confluence Operations / Renewal Job Modernization.
Use the target path during analysis, then continue to flow-orchestrator only after approval.
```

## Approval Checkpoint

Expect an explicit gate between analysis and delivery:

```text
Would you like to continue from approved tech refresh analysis into the standard feature workflow?

1. ✅ Yes
2. ❌ No
```

If you answer `Yes`, the orchestrator passes the approved analysis into `flow-orchestrator` and continues delivery.

When handoffs are enabled, the second transition can be offered from the orchestrator and also from the `tech-refresh` agent.

## Related References

- [Feature Flow Prompts](feature-flow-prompts.md)
- [Instruction Resolution](instruction-resolution.md)
- [Tech Refresh](../for-developers/tech-refresh.md)