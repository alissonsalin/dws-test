# Example: Continuous Improvement Session File

This page shows what a completed Step 9 improvements file looks like.
The file is saved as `improvements/session-dd-mm-yyyy.md`.

---

## Session: `improvements/session-11-04-2026.md`

**Feature:** Client Registration API (`LRA-1042`)  
**Date:** 11 April 2026

---

## Improvements Identified

### Implementation Patterns

- **Constructor injection enforced** — Always use constructor-based injection for Spring beans. Do not annotate fields with `@Autowired`. The prohibition is now explicit in `.github/skills/spring/SKILL.md`.
- **Exception handler placement** — Place `@ExceptionHandler` methods in the same controller that owns the endpoint, not in a separate class, unless the handler is truly shared across multiple controllers. Use a shared `@ControllerAdvice` class only when two or more controllers need the same mapping.
- **Use case input as a command object** — Wrap all use case input fields in a dedicated command record or class (e.g., `RegisterClientCommand`). This avoids primitive obsession and makes the use case signature stable even as fields change.

### Testing Strategies

- **Layer-based coverage floors applied** — `domain` and `usecase` layers target 90%+ line coverage. `adapter` and `gateway` layers rely on integration tests, not unit-only coverage.
- **ArchUnit test created at Step 4** — Do not defer ArchUnit test creation to Step 6. Create the `CleanArchitectureArchUnitTest` class during Step 4 so architectural violations are caught immediately.
- **Controller slice test for 409 path** — The duplicate email 409 path was missed initially. Always include a controller test for every HTTP status code documented in the API design.

### Security Practices

- **Email uniqueness check inside the use case** — Never expose uniqueness checks at the controller layer. The use case owns that rule.

---

## Commands Used

### Build and Test

```powershell
# Run all tests
.\gradlew test

# Run tests with coverage report
.\gradlew test jacocoTestReport jacocoTestCoverageVerification

# Build without running tests
.\gradlew build -x test
```

### Debugging

```powershell
# Print dependency tree
.\gradlew dependencies --configuration runtimeClasspath

# Check for outdated dependencies (Step 5)
.\gradlew dependencyUpdates
```

### Java Environment

```powershell
# Detect Java version (run exactly once at Step 4 start)
java -version
```

---

## Command Failures Captured

| Command | Step | Error | Fix Applied | Retry Succeeded |
|---------|------|-------|-------------|-----------------|
| `.\gradlew test` | Step 6 | `ArchUnit: usecase depends on gateway` | Changed constructor param to domain interface | Yes |
| `\.\gradlew build` | Step 4 | `application.properties` created instead of `.yml` | Added explicit prohibition to `.github/skills/spring/SKILL.md`, re-ran Step 4 | Yes |

---

## Deferred Backlog

> Non-critical ideas not implemented in this session. Review in a future session.

- [ ] Add OpenAPI snapshot contract tests to CI pipeline for all controller endpoints.
- [ ] Explore mutation testing with PIT for the `usecase` layer to validate assertion strength.
- [ ] Add a shared `GlobalExceptionHandler` using `@ControllerAdvice` once two or more controllers share the same exception types.

---

## User Decision

> Apply improvements now or save for later?

**Decision recorded:** Save for later — improvements captured in this file for the next feature session.

---

**Related:** [Step 9 - Continuous Improvement](../../flow/step-9.md)
