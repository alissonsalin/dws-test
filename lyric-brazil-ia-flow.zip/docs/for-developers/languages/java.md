# Java

## Purpose

Define Java-specific implementation standards used in this repository.

## Core Technical Stack

1. Java 21+
2. Spring Boot application model
3. Clean architecture package boundaries
4. ArchUnit for architecture constraints
5. JUnit + Mockito for behavior tests

## Key Expectations

- Java 21 or higher.
- Clean architecture boundaries (`domain`, `usecase`, `adapter`, `gateway`).
- Spring rules from the dedicated Spring skill.
- Lombok is mandatory for Java DTOs, entities, commands, responses, and value objects in this repository.
- Constructor-based dependency injection.
- Architecture tests with ArchUnit for boundary enforcement.

## Spring Configuration Model

- Use YAML configuration files:
	- `application.yml` (shared defaults)
	- `application-development.yml` (development profile)
	- `src/test/resources/application-test.yml` (test profile)
- Keep environment-specific values outside business logic.

## Dependency Injection Model

- Always use constructor injection.
- Do not use `@Autowired` for bean injection.
- Keep controllers thin, use use-case services for orchestration.

## Persistence Boundary Pattern

- Define repository interfaces in `usecase` or business-facing boundary modules.
- Implement them in `gateway`.
- Prefer JDBC-based access patterns unless explicitly overridden.

## Recommended Package Structure

Use `com.adp` as the base package for all Java code. Under that root, use clean-architecture layer packages with an entity- or feature-specific subpackage inside each layer. Keep cross-feature shared code minimal and intentional.

### Example Package Tree

```text
src/main/java/com/adp/
├── Application.java
├── domain/
│   └── client/
│       ├── Client.java
│       ├── ClientId.java
│       ├── ClientStatus.java
│       └── exception/
│           └── DuplicateClientException.java
├── usecase/
│   └── client/
│       ├── RegisterClientUseCase.java
│       ├── GetClientUseCase.java
│       ├── repository/
│       │   └── ClientRepository.java
│       ├── command/
│       │   └── RegisterClientCommand.java
│       ├── query/
│       │   └── GetClientQuery.java
│       ├── response/
│       │   └── ClientResponse.java
│       └── validation/
│           └── ClientValidation.java
├── adapter/
│   └── client/
│       └── controller/
│           ├── ClientController.java
│           ├── request/
│           │   └── RegisterClientRequest.java
│           └── response/
│               └── ClientHttpResponse.java
├── gateway/
│   └── client/
│       ├── ClientGateway.java
│       ├── entity/
│       │   └── ClientRecord.java
│       ├── mapper/
│       │   └── ClientGatewayMapper.java
│       └── config/
│           └── ClientGatewayConfiguration.java
└── configuration/
	└── ClientApiConfiguration.java
```

### Layer Placement Rules

1. Put core business state and invariants in `domain`.
2. Start every Java package with `com.adp`.
3. Inside each layer root package, create an entity- or feature-specific package such as `domain/client` or `usecase/client` before placing classes for that entity.
4. Put application orchestration, repository interfaces, commands, queries, responses, and shared business validation in `usecase`.
5. Put HTTP-facing request and response models in `adapter` under the entity package, for example `adapter/client/controller`.
6. Put database or integration implementations in `gateway` under the entity package.
7. Use `configuration` only for Spring `@Configuration` classes and bean wiring, and keep it as a global package instead of nesting configuration by entity.

## Naming Conventions

### Feature Prefix

- Use the feature or entity name as the class-name prefix in `usecase`, `adapter`, and `gateway`.
- Prefer `ClientController`, `ClientRepository`, `ClientGateway`, `RegisterClientUseCase`, `ClientResponse`.
- Avoid generic names such as `Controller`, `Service`, `Repository`, or `UseCase` without the feature prefix.

### Use Case Naming

- Use verb-plus-entity naming for use cases.
- Prefer `RegisterClientUseCase`, `GetClientUseCase`, `UpdateClientUseCase`, `DeleteClientUseCase`.
- Do not use `ClientService` as a substitute for a use case.

### Boundary Naming

- Name the business-facing port with the `Repository` suffix and keep it in `usecase/repository`.
- Name the outer implementation with the `Gateway` suffix and keep it in `gateway`.
- Prefer `ClientRepository` plus `ClientGateway`.
- Avoid `ClientRepositoryImpl`, `JdbcClientRepository`, `JpaClientGateway`, or `ClientGatewayImpl`.

### DTO and Boundary Model Naming

- Use `Command` for state-changing use case input.
- Use `Query` for read-oriented use case input when a dedicated object is needed.
- Use `Response` for use case output models.
- Use `Request` and `HttpResponse` for adapter-layer HTTP models to make transport ownership explicit.

### Domain Naming

- Use business language for entities and value objects: `Client`, `ClientId`, `ClientStatus`.
- Keep framework or persistence terms out of domain names.
- Prefer specific exception names such as `DuplicateClientException` or `InactiveClientException`.

## Recommended Package-by-Feature Variant

If a bounded context grows large, group by feature first and keep the same layer names inside each feature.

```text
src/main/java/com/adp/
├── shared/
│   ├── configuration/
│   └── exception/
└── client/
	├── domain/
	├── usecase/
	├── adapter/
	└── gateway/
```

Use this variant when features are mostly independent. Keep shared modules small so they do not become a new dumping ground that bypasses architecture boundaries.

## Java Command Guidance

- Run `java -version` (Windows) or `java --version` (macOS/Linux) exactly once at Step 4 start.
- Do not rerun Java detection later unless explicitly requested.
- Inspect `build.gradle` or `build.gradle.kts` during Step 4 and add Lombok if it is missing before implementing Java classes.
- Use the approved Gradle verification command from the Java CLI skill.

## Testing Model

- Unit tests: JUnit + Mockito (`@ExtendWith(MockitoExtension.class)`).
- Spring slice tests: `@MockBean` for Spring-managed collaborator replacement.
- Architecture tests: ArchUnit enforcing layer boundaries.
- Coverage reports and verification rules: use `.github/skills/jacoco/SKILL.md`.

## Related Flow Steps

- [Step 4 - Start Implementation](../../flow/step-4.md)
- [Step 5 - Security Validation](../../flow/step-5.md)
- [Step 6 - Create Unit Tests](../../flow/step-6.md)
