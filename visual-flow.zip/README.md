# Visual Flow Extension

## Purpose

Visual Flow is a VS Code extension scaffold that helps you:

- send an instruction to Copilot Chat
- track Step 1 to Step 9 progress in a live dashboard
- replay events from a JSON or JSONL event file

## Technologies

- TypeScript
- VS Code Extension API

## Install

1. Open this folder in a terminal.
2. Run npm install.
3. Run npm run build.

## Run

1. Open this folder in VS Code.
2. Press F5 to launch the Extension Development Host.
3. Use the Command Palette and run:
   - Visual Flow: Open Dashboard
   - Visual Flow: Start Run
   - Visual Flow: Record Event
   - Visual Flow: Mark Run Completed
   - Visual Flow: Attach Event File

## Release Notes

Release notes are not created yet for this extension scaffold.
