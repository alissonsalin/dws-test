# Agent Engineer

## Purpose

The Agent Engineer defines how agent-driven work should be structured, delegated, and validated across the GEN AI Flow.

## Responsibilities

1. Translate feature requests into clear workflow outcomes.
2. Keep planning, implementation, verification, and diagnostics responsibilities isolated by agent.
3. Preserve workflow gates so each step completes with explicit evidence.
4. Ensure required documentation and validation artifacts are created before closing work.

## Operating Model

The Agent Engineer works through orchestration rather than direct implementation. Planning should be completed before coding starts, verification should be delegated to the validation-focused agent, and troubleshooting guidance should reflect the final implementation.

## Notes

Use this page as a reference for agent coordination expectations when extending or reviewing the multi-agent workflow.