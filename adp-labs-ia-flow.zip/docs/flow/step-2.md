# Step 2: Create Technical Design

## Purpose

Once requirements are clear, you must design **how** the feature will be built. Technical design bridges the gap between business requirements and implementation, ensuring the solution is:
- Architecturally sound and maintainable
- Scalable and performant
- Aligned with clean architecture principles
- Well-documented for the development team

## Why This Step Matters

Without a solid design:
- Developers make conflicting architectural choices
- Integration problems emerge late in development
- The codebase becomes harder to maintain
- Security or performance issues are discovered post-release

A strong design:
- Prevents rework by catching design flaws early
- Provides a shared reference for the team
- Enables parallel development with clear interfaces
- Makes code review faster and more focused

## What You'll Do

1. **Propose the Architecture** — Design a solution that:
   - Follows clean architecture principles (domain, usecase, adapter, gateway layers)
   - Clearly separates concerns
   - Identifies key modules, classes, and data structures
   - Defines how components interact

2. **Create Visual Diagrams** — Both formats are mandatory for every technical design:
   - **ASCII component diagram** — inside a fenced Markdown code block; boxes labeled by module/layer, arrows showing data flow direction
   - **Mermaid component diagram** — inside a fenced `mermaid` code block; must represent the same architecture as the ASCII diagram

3. **Document the Design** — Create a comprehensive design document with sections:
   - **Requirement Summary**: Recap key requirements from Step 1
   - **Technical Design**: Architecture explanation with diagrams, data flow, validation rules
   - **Database Schema**: If applicable, show entity relationships and key fields
   - **API Design**: If applicable, define endpoints, request/response formats, error handling
   - **Backward Compatibility**: How will this work with existing systems or data?
   - **Impact and Risk Assessment**:
     - Performance impact analysis (latency, throughput, resource usage, and caching implications)
     - Internal feature impact check (which existing features can be affected and regression validation plan)
     - External dependency check (which external projects/services are required, and timeout/failure behavior)
     - External impact check (whether this feature can affect external projects/services and mitigation plan)

4. **Use Contract-First API Design** — For API features, define the contract before coding:
   - Request payload fields and validation rules
   - Response payload structure for success paths
   - Error payload structure for failure paths
   - Endpoint behavior and status codes
   - Keep this contract stable while implementing controller, use case, and repository layers

5. **Get Confirmation** — Present the design to:
   - Technical stakeholders for feasibility review
   - Domain experts for accuracy
   - The feature owner for alignment

## Output

A single design document (e.g., `documentation/feature-name/feature-name-design.md`) containing:
- Clear architecture diagrams with labeled components
- Explanation of how components work together
- Data flow and transformation logic
- Technology and framework choices with rationale
- Impact and risk assessment covering performance, internal feature impact, external dependencies, and external impact
- Known constraints or open questions

## When To Confirm

Before moving to Step 3:
- The design has been reviewed and approved by stakeholders
- All technical questions have been answered
- The team understands the architecture
- Edge cases and error scenarios are considered
- For API work, request, response, and error contracts are explicit enough to drive implementation

---

**Previous Step:** [Step 1 - Identify Feature Details](step-1.md)  
**Next Step:** [Step 3 - Create User Stories](step-3.md)
