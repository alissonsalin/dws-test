---
name: openapi
description: "Design, implement, or validate public HTTP APIs using annotation-driven Swagger/OpenAPI conventions. Use when work adds controllers, endpoints, request or response models, error payloads, or API contract validation."
argument-hint: "Describe the endpoint or controller change and whether public API documentation or contract tests are affected"
---

# Swagger and OpenAPI Rules

Use this skill when API contract guidance is needed during design or implementation.

## When to Use

- A public HTTP API is added or changed.
- Controller annotations, request and response contracts, or API error models are part of the work.
- You need to validate controller behavior against generated OpenAPI output.

## Contract Rules

- Keep OpenAPI documentation up to date for every public HTTP API change using framework-supported annotations and dependencies.
- Do not create standalone Swagger or OpenAPI YAML, YML, JSON, or Markdown specification files unless explicitly requested.
- Prefer dependency-driven OpenAPI generation from controller annotations instead of separate contract files.
- Define endpoint summaries, descriptions, parameters, request bodies, and responses.
- Use reusable schemas or components to avoid duplicated contract definitions.
- Include explicit error response models for 4xx and 5xx scenarios.
- Document authentication and authorization requirements for protected endpoints.
- Add realistic request and response examples for critical endpoints.
- Keep API versioning strategy explicit and documented.
- Avoid breaking contract changes unless they are approved and documented.

## Validation

- Validate generated OpenAPI output exposed by the configured framework before finalizing changes.
- Keep implementation, tests, and OpenAPI contract aligned.
- Maintain snapshot-based API contract tests for controller behavior to detect contract drift.