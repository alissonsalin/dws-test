# Human Interaction Diagram

This page provides a high-level visualization of where human checkpoints interact with the workflow.

```mermaid
%%{init: {'themeVariables': {'fontSize': '13px'}, 'flowchart': {'nodeSpacing': 80, 'rankSpacing': 90, 'useMaxWidth': false}} }%%
flowchart TD
    A[Inputs<br/>requirements and context] --> B[Define and Refine Scope]
    B --> C[Design and Risk Review]
    C --> D[Implementation Sessions]
    D --> E[Validate Session Outputs]
    E --> F[Improve Process]
    F --> B

    H1{{Human checkpoint}} --> B
    H2{{Human checkpoint}} --> C
    H3{{Human checkpoint}} --> E
    H4{{Human checkpoint}} --> F

    style H1 fill:#1E3A8A,stroke:#0B1F5E,stroke-width:1.5px,color:#FFFFFF
    style H2 fill:#1E3A8A,stroke:#0B1F5E,stroke-width:1.5px,color:#FFFFFF
    style H3 fill:#1E3A8A,stroke:#0B1F5E,stroke-width:1.5px,color:#FFFFFF
    style H4 fill:#1E3A8A,stroke:#0B1F5E,stroke-width:1.5px,color:#FFFFFF
```

## How To Read The Diagram

- The main lane shows a simplified workflow overview, not all Step 1 to Step 9 details.
- The loop from Improve Process back to Define and Refine Scope shows continuous learning.
- Human checkpoints are placed where judgment changes outcomes most: scope, design, validation, and improvement prioritization.

## Related

- [Human Loop Overview](../human-loop.md)