# Subagents

## Purpose

Subagents provide focused execution units inside the GEN AI Flow so work can be delegated to specialized roles without overloading a single agent.

## Responsibilities

1. Execute a clearly scoped task with an explicit outcome.
2. Stay within the boundaries passed by the orchestrating agent.
3. Return useful outputs that can be consumed by the next workflow step.
4. Reduce ambiguity by separating planning, implementation, verification, and diagnostics concerns.

## Operating Model

Subagents should be used when a task has a narrow purpose, clear completion criteria, and enough context to be performed independently. They are most effective when the parent agent passes the source context, expected outputs, constraints, and the specific files or outcomes the subagent owns.

Subagents should not be used as a vague fallback for incomplete instructions. Each delegation should define what the subagent is responsible for, what it must avoid, and what result it must return.

## Parallel Execution

Subagents can run in parallel when their work is independent and there is no workflow gate forcing a sequence.

1. Run subagents in parallel only when they touch different files or produce different non-conflicting outcomes.
2. Make the file or output ownership explicit before starting parallel work.
3. Avoid parallel execution when one subagent depends on the output of another.
4. Reconcile parallel results before moving to the next gated step.
5. Use parallel execution for separated tracks such as design versus story drafting, or troubleshooting versus improvement capture, when the workflow explicitly allows it.

## Notes

Use this page as a reference for when to delegate to subagents and how to coordinate concurrent work safely. Parallelism should accelerate delivery without weakening workflow control or result quality.