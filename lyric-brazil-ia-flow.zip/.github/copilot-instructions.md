# Feature Workflow

For feature implementation, use the `feature-flow` agent — it enforces the full 9-step workflow including design-first gates, checklist tracking, CVE validation, and Step 9 deferred backlog carry-forward.

**Agent file**: `.github/agents/feature-flow.agent.md`

To start: open the agent picker and select **feature-flow**, or mention `@feature-flow` in chat with a feature description or source reference (file path, Jira ID, Confluence link, or direct description).

For technology migration and modernization work, use the `tech-refresh` agent — it adds a mandatory prerequisite analysis phase before the standard Step 1 to Step 9 workflow.

**Agent file**: `.github/agents/tech-refresh.agent.md`

To start: open the agent picker and select **tech-refresh**, or mention `@tech-refresh` in chat with the current system/module, target stack, and migration scope.

For handoff-driven tech refresh execution, use the `tech-refresh-orchestrator` agent — it starts with `tech-refresh` for prerequisite analysis and approval, then continues with `feature-flow` for Step 1 to Step 9 delivery.

**Agent file**: `.github/agents/tech-refresh-orchestrator.agent.md`

To start: open the agent picker and select **tech-refresh-orchestrator**, or mention `@tech-refresh-orchestrator` in chat with the migration scope, source context, and target stack.

---

## Always-On Instruction Files

The following files are scoped via `applyTo` and load automatically for their target file types:

Keep this list limited to workflow control, architecture, testing, and documentation rules that should remain available by default.

| Concern | File |
|---|---|
| Clean architecture | `.github/instructions/clean-architecture.instructions.md` |
| Design-first gate | `.github/instructions/design-first.instructions.md` |
| Workflow checklist format | `.github/instructions/workflow-status.instructions.md` |
| Testing patterns & coverage | `.github/instructions/testing.instructions.md` |
| Command resilience | `.github/instructions/command-resilience.instructions.md` |
| Documentation format | `.github/instructions/docs.instructions.md` |
| Tech refresh workflow | `.github/instructions/tech-refresh.instructions.md` |

---

## On-Demand Skills

Use these for specialized workflows that should not be loaded by default:

| Concern | Skill |
|---|---|
| CLI retries and preflight remediation | `.github/skills/cli-resilience/SKILL.md` |
| Java architecture boundary tests (ArchUnit) | `.github/skills/archunit/SKILL.md` |
| Java implementation baseline | `.github/skills/java/SKILL.md` |
| Node.js implementation baseline | `.github/skills/nodejs/SKILL.md` |
| Python implementation baseline | `.github/skills/python/SKILL.md` |
| Spring Boot conventions | `.github/skills/spring/SKILL.md` |
| Lombok model and builder rules | `.github/skills/lombok/SKILL.md` |
| Java CLI startup and validation flow | `.github/skills/java-cli/SKILL.md` |
| JaCoCo coverage configuration and reporting | `.github/skills/jacoco/SKILL.md` |
| Annotation-driven OpenAPI / Swagger | `.github/skills/openapi/SKILL.md` |
| Node/Python CLI resilience | `.github/skills/node-python-cli/SKILL.md` |

---

## Feature Deliverables

Every completed feature must produce:
- `documentation/<feature-name>/<feature-name>-design.md`
- `documentation/<feature-name>/<feature-name>-troubleshooting.md`
- `improvements/session-dd-mm-yyyy.md` (Step 9 output, today's date)
- Updated `README.md`

---

## Parameters

- Source type: `file | Jira | Confluence | user input`
- Language: `Java | NodeJS | Python | SQL`
