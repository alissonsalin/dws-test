---
applyTo: "**/*{test,spec}*.{java,js,ts,py}"
description: "Use when creating or updating tests to ensure predictable, maintainable coverage of feature behavior."
---

# Test Authoring Rules

- Cover both happy path and error path for each behavior change.
- Keep test names behavior-focused and explicit.
- Follow Arrange, Act, Assert structure.
- Use mocks only at external boundaries.
- Avoid brittle assertions tied to implementation details.
- Keep fixtures minimal and local to the test when possible.
- Keep business-layer tests focused and independent from unnecessary full runtime context loading.

# Quality and Coverage

- Add tests for input validation and edge cases.
- Prefer deterministic tests without timing dependencies.
- Ensure failures are easy to diagnose from test output.
- Update existing tests when requirements or contracts change.
- For critical validation logic, add mutation testing in CI to verify assertion strength.
- For public HTTP APIs, add controller contract tests generated from OpenAPI snapshots.
- If mutation or contract tests are skipped, document the reason and risk in test notes.

# Coverage Floors by Layer

- Apply coverage goals per clean architecture layer as a verification gate. Do not use a single 100% line coverage target.
- `domain` layer: 90%+ line coverage. This is core business logic and must be thoroughly tested.
- `usecase` layer: 90%+ line coverage. All orchestration flows, success paths, and failure paths must be covered.
- `adapter` layer: integration-tested via controller/slice tests. Unit coverage is secondary to contract correctness.
- `gateway` layer: 90%+ line coverage. Use integration tests and/or focused tests to ensure this floor is met.
- Do not write tests purely to satisfy a coverage number. Every test must verify a meaningful behavior or failure case.
- Do not mark test work complete if changed critical business layers are below the documented coverage floor unless the gap is explicitly documented and approved.
- When the project supports package- or layer-based verification rules, configure them to enforce the documented coverage floors.

# Language-Specific Test Execution

- Treat language-specific skills as the source of truth for stack-specific test frameworks, exact commands, coverage tooling, and architecture-test behavior.
- Run test commands in non-interactive mode only.
- Use the repository-approved test command for the stack instead of inventing alternative runner commands.
- Generate and review the stack-appropriate coverage report in the same verification cycle when coverage tooling is part of the project.
- If the repository already has a valid current coverage report and the user asks for coverage, summarize the existing report instead of rerunning commands when that is sufficient.

# Maintainability

- Group tests by feature behavior, not by helper method.
- Remove dead or duplicate tests when replacing behavior.
- Keep helper utilities small and reusable.

# Skill Routing

- For Java-specific test setup, coverage tooling, coverage verification, and architecture-test behavior, use `.github/skills/java/SKILL.md`, `.github/skills/java-cli/SKILL.md`, `.github/skills/jacoco/SKILL.md`, and `.github/skills/archunit/SKILL.md` as applicable.
- For Node.js-specific test execution, use `.github/skills/nodejs/SKILL.md` and `.github/skills/node-python-cli/SKILL.md`.
- For Python-specific test execution, use `.github/skills/python/SKILL.md` and `.github/skills/node-python-cli/SKILL.md`.
