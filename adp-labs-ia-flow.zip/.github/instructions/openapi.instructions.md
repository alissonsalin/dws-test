---
applyTo: "{src/adapter/controller/**,src/adapter/controllers/**,docs/api/**,documentation/api/**,**/*openapi*.{yml,yaml,json,md},**/*swagger*.{yml,yaml,json,md}}"
description: "Use when designing, implementing, or documenting HTTP APIs to enforce Swagger/OpenAPI standards."
---

# Swagger/OpenAPI Rules

- Keep OpenAPI documentation up to date for every public HTTP API change using framework-supported annotations and dependencies out of the box.
- Do not create standalone Swagger/OpenAPI YAML, YML, JSON, or Markdown specification files unless the user explicitly requests that specific file.
- Do not create OpenAPI or Swagger files under `src/main/resources`, `docs/api`, `documentation/api`, or any other folder by default.
- Prefer dependency-driven OpenAPI generation from controller annotations instead of maintaining separate contract files.
- Define endpoint summaries, descriptions, parameters, request bodies, and responses.
- Use reusable schemas/components to avoid duplicated contract definitions.
- Include explicit error response models for 4xx and 5xx scenarios.
- Document authentication and authorization requirements for protected endpoints.
- Add realistic request and response examples for critical endpoints.
- Keep API versioning strategy explicit and documented in the spec.
- Avoid breaking contract changes unless approved and documented.
- Validate the generated OpenAPI output exposed by the configured dependency/framework before finalizing changes.
- Ensure implementation, tests, and OpenAPI contract stay aligned.
- Maintain snapshot-based API contract tests for controller behavior to detect contract drift.
