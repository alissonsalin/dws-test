# Custom Instructions

## Purpose

This page documents the project custom instruction files used by Copilot during feature workflows. It helps developers understand which rules are applied, when they are loaded, and what behavior they enforce.

## How Instruction Loading Works

- Workspace instructions are defined in `.github/copilot-instructions.md`.
- File-scoped instructions are defined in `.github/instructions/*.instructions.md`.
- Each instruction file has an `applyTo` pattern that determines when it is loaded.
- When more than one instruction applies, use the most specific file as source of truth for detailed behavior.

## Detailed Instruction Reference

### `.github/copilot-instructions.md` (Workflow Orchestrator)

- Defines the end-to-end 9-step feature workflow.
- Enforces design-first behavior before implementation.
- Controls interactive gates (design approval, CVE decision, improvement decision).
- Defines allowed documentation files and final completion gates.

### `.github/instructions/workflow-status.instructions.md`

- Standardizes checklist format and status icons across progress updates.
- Ensures every step (1 to 9) is shown with a clear current status.
- Prevents partial or inconsistent workflow status reporting.

### `.github/instructions/design-first.instructions.md`

- Blocks coding actions until Step 2 (technical design) is approved.
- Ensures implementation cannot start without explicit user confirmation.
- Keeps requirement analysis and design separated from code generation.

### `.github/prompts/tech-refresh.prompt.md`

- Adds an opt-in migration workflow for tech refresh initiatives.
- Requires a prerequisite analysis phase before the standard Step 1 to Step 9 flow.
- Forces explicit approval before the normal feature workflow can begin.

### `.github/instructions/tech-refresh.instructions.md`

- Defines the required sections for tech refresh analysis documents.
- Prevents documenting or executing Step 1 to Step 9 before analysis approval.
- Standardizes migration planning, validation planning, and rollback coverage.

### `.github/instructions/command-resilience.instructions.md`

- Defines retry and remediation behavior for command failures.
- Requires fix-first retries instead of rerunning failing commands unchanged.
- Encourages preflight checks to reduce avoidable command errors.

### `.github/instructions/java-cli.instructions.md`

- Defines Java command-line flow, including Java version detection timing.
- Enforces a single Java detection execution at Step 4 start.
- Aligns command usage with repository-approved verification flow.

### `.github/instructions/docs.instructions.md`

- Defines documentation writing quality, structure, and consistency.
- Enforces Step 2 diagrams (ASCII + Mermaid) when producing technical design docs.
- Adds required technical design sections, including impact/risk checks.

### `.github/instructions/clean-architecture.instructions.md`

- Defines architecture boundaries: `domain`, `usecase`, `adapter`, `gateway`.
- Enforces inward dependency direction.
- Clarifies boundary ownership for interfaces and infrastructure implementations.

### `.github/instructions/java.instructions.md`

- Defines Java implementation conventions and naming patterns.
- Enforces entity-prefixed class names across controller/usecase/gateway areas.
- Aligns Java behavior with Spring, ArchUnit, Lombok, and CLI command policies.

### `.github/instructions/spring.instructions.md`

- Enforces Spring-specific structure and annotation rules.
- Requires constructor injection and blocks `@Autowired` field injection.
- Enforces YAML-only configuration (`application.yml`, `application-development.yml`, and `application-test.yml`).
- Requires `Application` as the exact main class name.

### `.github/instructions/lombok.instructions.md`

- Defines Lombok usage strategy for Java DTO/entity/command/response classes.
- Enforces `@Builder`-based object construction patterns.
- Blocks Java `record` usage for those model types when Lombok is present.

### `.github/instructions/archunit.instructions.md`

- Enforces architecture test creation/update for Java features.
- Defines mandatory layer-boundary rules for `domain`, `usecase`, `adapter`, and `gateway`.
- Clarifies naming and placement for architecture test classes.

### `.github/instructions/testing.instructions.md`

- Defines test authoring expectations (happy path, failure path, edge cases).
- Enforces coverage floors by layer and Java completion gates.
- Defines JaCoCo generation, report reuse behavior, and non-interactive command rules.

### `.github/instructions/openapi.instructions.md`

- Enforces API documentation alignment with implementation and tests.
- Uses dependency/annotation-driven OpenAPI generation by default.
- Blocks creation of standalone Swagger/OpenAPI files unless explicitly requested.

### `.github/instructions/nodejs.instructions.md`

- Defines NodeJS clean architecture conventions and implementation quality rules.
- Guides controller/service/repository separation for JavaScript/TypeScript features.

### `.github/instructions/python.instructions.md`

- Defines Python clean architecture conventions and validation/testing expectations.
- Guides boundary design, error handling, and maintainable Python test strategy.

### `.github/instructions/node-python-cli-resilience.instructions.md`

- Applies command resilience behavior specifically for NodeJS and Python workflows.
- Reduces retry loops and enforces fix-driven command remediation.

## Precedence and Conflict Handling

1. Use `.github/copilot-instructions.md` for workflow-level gates and sequencing.
2. Use the relevant file-level instruction as source of truth for technical detail.
3. If two file-level rules overlap, prioritize the more specific domain file:
   - testing details: `.github/instructions/testing.instructions.md`
   - architecture tests: `.github/instructions/archunit.instructions.md`
   - Spring config/annotations: `.github/instructions/spring.instructions.md`
   - API contract behavior: `.github/instructions/openapi.instructions.md`
4. Keep workflow files concise and avoid duplicating deep technical rules.
5. Use the tech refresh prompt and instruction only for migration-style work; keep default feature flow unchanged for ordinary delivery.

## Operational Rules You Should Expect

- Design approval is required before implementation actions.
- Tech refresh work requires prerequisite analysis approval before Step 1 starts.
- Interactive gates use numbered options with icons.
- Test and JaCoCo commands run in non-interactive mode.
- Coverage requests should reuse an existing JaCoCo HTML report when valid for current code state.
- Java API implementations should use dependency-driven OpenAPI generation and controller annotations by default (no standalone OpenAPI files unless explicitly requested).

## Related References

- [For Developers - Overview](overview.md)
- [Clean Architecture](clean-architecture.md)
- [Unit test](unit-test.md)
- [Flow - Step 2](../flow/step-2.md)
- [Flow - Step 6](../flow/step-6.md)
