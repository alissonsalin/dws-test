# Flow Overview

This section is your practical roadmap for delivering a feature from idea to production-ready quality using GEN AI guidance.

The flow is organized in 9 steps. Each step has a clear purpose, expected outputs, and decision points so you can move forward with confidence and avoid rework.

## What You Will Achieve

By following this flow end to end, you will:

1. Clarify requirements before coding.
2. Design with clean architecture in mind.
3. Build in small, testable increments.
4. Validate security and quality before release.
5. Capture lessons learned to improve future deliveries.

## Flow

1. [Step 1 - Identify Feature Details](step-1.md)
	Capture and summarize requirements from the source of truth.
2. [Step 2 - Technical Design](step-2.md)
	Define architecture, data flow, and clean-architecture boundaries.
3. [Step 3 - Create User Stories](step-3.md)
	Break the Step 1 requirements and Step 2 design into small, testable stories with acceptance criteria; this must start in parallel with Step 2 and must be reconciled before Step 4.
4. [Step 4 - Start Implementation](step-4.md)
	Build the feature through the `coder` agent using clean architecture and the identified language skill.
5. [Step 5 - Security Validation](step-5.md)
	Delegate to `verifier` to run static and dynamic analysis tools for security verification. Resolve detected vulnerabilities before proceeding.
6. [Step 6 - Test Verification and Coverage](step-6.md)
	Delegate to `verifier` to run tests and perform coverage analysis. Resolve test failures or coverage regressions before proceeding.
7. [Step 7 - Compare and Adjust](step-7.md)
	Validate implementation against requirements and design.
8. [Step 8 - Troubleshooting and Debugging](step-8.md)
	Delegate to `diagnostics` to create troubleshooting guidance and health procedures based on final implementation.
9. [Step 9 - Continuous Improvement](step-9.md)
	Document learnings and improve templates, instructions, and workflow.

## Quick Tips

1. Keep feature scope explicit and document detailed technical requirements from the beginning.
2. Use small feedback loops between design, implementation, testing, and troubleshooting documentation.
3. Treat security and testing as part of development, not as final checks.
4. Document what you learn so the next feature is faster and safer.
5. Use repository command-line instruction files as the source of truth for command selection, timing, retries, and failure capture.

## Developer Guidance

Use the [For developers - Overview](../for-developers/overview.md) section for implementation conventions, architecture-testing rules, and language-specific guidance while executing the flow.

---

Ready to begin? Continue to [Step 1 - Identify Feature Details](step-1.md).
