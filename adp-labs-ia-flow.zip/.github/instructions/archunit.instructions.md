---
applyTo: "**/*.{java,kt,gradle,kts}"
description: "Use when creating or updating Java architecture tests with ArchUnit to enforce clean architecture layer boundaries."
---

# ArchUnit Test Rules

- Use ArchUnit for Java architecture tests whenever Java feature behavior or structure changes.
- ArchUnit tests are mandatory for Java features that touch clean architecture layers.
- **Timing:** Create ArchUnit test class during Step 4 (Implementation). Update during Step 6 (Unit Tests) if your implementation changes the architecture.
- If no ArchUnit test class exists yet, create one.
- If an ArchUnit test class already exists, update it to cover the current feature changes.
- For every Java feature, ensure at least one dedicated ArchUnit test class is present after implementation.

# Required Clean Architecture Layer Coverage

- Validate package boundaries for all clean architecture layers:
  - `domain`
  - `usecase`
  - `adapter`
  - `gateway`
- Verify dependency direction is inward. Enforce these forbidden dependencies:
  - `domain` must NOT depend on `usecase`, `adapter`, or `gateway`
  - `usecase` must NOT depend on `adapter` or `gateway`
  - `adapter` must NOT depend on `gateway`
  - `gateway` is the outermost layer (infrastructure) and may depend on all inner layers
- Provide at least one `@ArchTest` rule per layer boundary to document these constraints clearly.

# Test Placement and Naming

- Place all ArchUnit tests in a dedicated `architecture` package under `src/test/java/<project-root>/architecture/`.
- Example location: `src/test/java/org/example/architecture/CleanArchitectureArchUnitTest.java`.
- Keep ArchUnit tests separate from unit tests for clarity.
- Use explicit class names that indicate architecture intent, for example `CleanArchitectureArchUnitTest`.
- Keep rule names readable and mapped to architecture constraints.

# Example ArchUnit Rules

Use this pattern for all four layer boundaries:

```java
@AnalyzeClasses(packages = "org.example", importOptions = ImportOption.DoNotIncludeTests.class)
class CleanArchitectureArchUnitTest {

    @ArchTest
    static final ArchRule domainShouldNotDependOnOuterLayers = noClasses()
            .that().resideInAPackage("..domain..")
            .should().dependOnClassesThat().resideInAnyPackage("..usecase..", "..adapter..", "..gateway..");

    @ArchTest
    static final ArchRule usecaseShouldNotDependOnAdapter = noClasses()
            .that().resideInAPackage("..usecase..")
            .should().dependOnClassesThat().resideInAnyPackage("..adapter..");

    @ArchTest
    static final ArchRule usecaseShouldNotDependOnGateway = noClasses()
            .that().resideInAPackage("..usecase..")
            .should().dependOnClassesThat().resideInAnyPackage("..gateway..");

    @ArchTest
    static final ArchRule adapterShouldNotDependOnGateway = noClasses()
            .that().resideInAPackage("..adapter..")
            .should().dependOnClassesThat().resideInAnyPackage("..gateway..");
}
```

Adapt package names and class names to match your project structure.

# When Layers Are Missing

- If a project does not yet include one of the target layers, keep rules for existing layers and document the missing layer rationale in test notes.
- Expand ArchUnit coverage when missing layers are introduced.

# Verification Expectation

- Ensure ArchUnit tests are included in the standard test run.
- When an ArchUnit rule is temporarily relaxed, document the reason and remediation plan.