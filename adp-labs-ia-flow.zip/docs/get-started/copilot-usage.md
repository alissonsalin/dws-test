# Copilot Usage

After installation, use Copilot Chat normally in the target repository. The workspace entrypoint loads shared instructions automatically, and the feature workflow is started through the feature-flow agent.

## Example Prompts

1. @feature-flow Start a new feature flow for this requirement source and complete Step 1.
2. @feature-flow Implement this.
3. Update tests according to the testing instruction file.
4. For docs updates, follow documentation rules from .github/instructions.

## How It Works

1. `.github/copilot-instructions.md` acts as the workspace entrypoint.
2. `.github/agents/feature-flow.agent.md` drives the full Step 1 to Step 9 feature workflow.
3. `.github/instructions/*.instructions.md` apply automatically when files match their `applyTo` patterns.
4. `.github/skills/*/SKILL.md` are loaded on demand for specialized workflows such as CLI remediation and ArchUnit updates.

## Developer References

1. [For developers - Overview](../for-developers/overview.md)
2. [For developers - Clean Architecture](../for-developers/clean-architecture.md)
3. [For developers - Arch Unit](../for-developers/arch-unit.md)
4. [For developers - Languages](../for-developers/languages/java.md)
5. [For developers - Unit test](../for-developers/unit-test.md)

## Next Step

If needed, go to [Troubleshooting](troubleshooting.md).