# Best Practices

Use these practices for better Copilot results.

## Prompting Practices

1. Be explicit about source type: file, Jira, Confluence, or user input.
2. Include paths, ticket IDs, and page names whenever possible.
3. Ask for one step at a time if you want tighter review control.
4. Ask for non-interactive continuation if you want faster end-to-end execution.
5. Confirm assumptions early before implementation starts.
6. Answer gate questions explicitly with yes or no to avoid stalled in-progress states.
7. Provide exact file paths or ticket IDs to reduce retries and clarification loops.

## Quick Verification Checklist

Before trusting generated output, verify:

1. It follows the step order defined in project workflow.
2. It references the correct feature source.
3. It applies the expected architecture and testing rules.
4. It keeps documentation and implementation aligned.
5. It shows gate decisions explicitly, including design approval and CVE run or skip.
6. It keeps the full step checklist visible as execution progresses.

## Back to Overview

Return to [Copilot Chat Usage Overview](../copilot-chat-usage.md).