---
applyTo: "**/*.{js,ts,py,json,yml,yaml,md}"
description: "Use when executing Node.js or Python feature workflows to reduce command retries and keep remediation iterative."
---

# Node and Python Command Resilience Rules

- Use this file as the source of truth for Node.js and Python command retry behavior in feature workflows.
- Follow `.github/instructions/command-resilience.instructions.md` as the shared baseline for preflight, retry, and failure-capture behavior.
- Keep command usage minimal and goal-oriented.
- Prefer non-interactive commands.

# Preflight Before Validation Commands

- Before executing verification or security commands, run lightweight preflight checks for:
  - required tools in PATH
  - expected files (for example package.json, pyproject.toml, requirements.txt)
  - working directory context
- If preflight fails, fix the environment or command context first, then execute the target command.

# Retry and Remediation Policy

- Continue workflow remediation for recoverable errors; do not stop the full workflow for non-destructive issues.
- If a command fails, apply a material fix before retrying.
- Do not rerun a command when the error fingerprint is unchanged from the previous attempt.
- Keep retries fix-driven and iterative until resolved, unless the issue is destructive, ambiguous, or blocked by an explicit user gate.
- Do not mark a workflow step as failed for recoverable command errors; keep it in-progress during remediation.

# Command Minimization

- Do not run extra diagnostics outside the approved workflow unless the user explicitly asks for them.
- Prefer one verification command per phase, then remediate and rerun only as needed.

# Reporting

- After each attempt, summarize:
  - command executed
  - key error or pass result
  - fix applied
  - next action
- Capture repeated failure patterns and successful fixes in improvement notes.
