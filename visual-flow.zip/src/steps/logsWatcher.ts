import * as vscode from "vscode";
import { promises as fs } from "fs";
import * as path from "path";
import { Logger, StepStatus } from "./shared";

export interface LogEntry {
  timestamp: string;
  step: string;
  status: StepStatus;
  notes: string;
}

export interface OnLogsChanged {
  (entries: LogEntry[]): void;
}

export class LogsWatcher implements vscode.Disposable {
  private pollingTimer: NodeJS.Timeout | undefined;
  private lastContent: string = "";
  private logsFilePath: string;
  private readonly logger: Logger;
  private readonly onChanged: OnLogsChanged;

  /**
   * @param logsFilePath Absolute path to the file to watch.
    *   Pass the workspace logs/logs.md path written by visual-log.
   */
  public constructor(logsFilePath: string, logger: Logger, onChanged: OnLogsChanged) {
    this.logsFilePath = logsFilePath;
    this.logger = logger;
    this.onChanged = onChanged;
  }

  public start(): void {
    this.stop();
    this.logger.log("Starting logs watcher.", { logsFilePath: this.logsFilePath });
    this.pollingTimer = setInterval(() => {
      void this.pollLogsFile();
    }, 1000); // Poll every 1000ms
    void this.pollLogsFile(); // Initial poll
  }

  public stop(): void {
    if (this.pollingTimer) {
      clearInterval(this.pollingTimer);
      this.pollingTimer = undefined;
    }
    this.lastContent = "";
  }

  public dispose(): void {
    this.stop();
  }

  private async pollLogsFile(): Promise<void> {
    try {
      const content = await fs.readFile(this.logsFilePath, "utf8");

      if (content === this.lastContent) {
        return; // No changes
      }

      this.lastContent = content;
      const entries = this.parseLogsContent(content);
      this.onChanged(entries);
    } catch (error) {
      const err = error as NodeJS.ErrnoException;
      // ENOENT is expected if file doesn't exist yet
      if (err?.code !== "ENOENT") {
        this.logger.log("Failed to read logs file.", { error: String(error) });
      }
    }
  }

  private parseLogsContent(content: string): LogEntry[] {
    try {
      // Extract JSON array from markdown content
      // The file may contain markdown formatting, so we need to extract just the JSON
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      if (!jsonMatch) {
        return [];
      }

      const parsed = JSON.parse(jsonMatch[0]) as unknown;

      if (!Array.isArray(parsed)) {
        this.logger.log("Logs file content is not a JSON array.");
        return [];
      }

      return parsed.map((entry: unknown) => this.normalizeLogEntry(entry)).filter((entry): entry is LogEntry => entry !== null);
    } catch (error) {
      this.logger.log("Failed to parse logs file JSON.", { error: String(error) });
      return [];
    }
  }

  private normalizeLogEntry(entry: unknown): LogEntry | null {
    if (!entry || typeof entry !== "object") {
      return null;
    }

    const e = entry as Record<string, unknown>;
    const timestamp = typeof e.timestamp === "string" ? e.timestamp : "";
    const step = typeof e.step === "string" ? e.step : "";
    const status = this.normalizeStatus(e.status);
    const notes = typeof e.notes === "string" ? e.notes : "";

    if (!timestamp || !step || !status) {
      return null;
    }

    return { timestamp, step, status, notes };
  }

  private normalizeStatus(status: unknown): StepStatus | null {
    const valid: StepStatus[] = ["pending", "in-progress", "completed", "failed", "skipped"];
    if (typeof status === "string" && valid.includes(status as StepStatus)) {
      return status as StepStatus;
    }
    return null;
  }
}
