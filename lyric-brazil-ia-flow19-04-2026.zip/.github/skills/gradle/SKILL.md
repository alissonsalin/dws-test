---
name: gradle
description: "Configure Java Gradle builds for required plugins, lifecycle wiring, and Checkstyle setup. Use when build.gradle or build.gradle.kts needs creation, repair, or missing Java quality plugins."
argument-hint: "Describe the Java module, Gradle file, and whether you need plugin setup, lifecycle wiring, or Checkstyle configuration"
---

# Gradle Build Configuration Rules

## When to Use

- Java work needs `build.gradle` or `build.gradle.kts` creation or repair.
- A Java project is missing required plugins or task wiring before implementation can proceed.
- You need to add or fix Checkstyle plugin configuration for Java linting.
- A Java module needs Gradle lifecycle wiring for repository-required quality plugins.

## Scope

- Keep Java build configuration in `build.gradle` or `build.gradle.kts`.
- Keep this skill focused on build-file setup rather than command execution.
- Keep plugin configuration in the build, not in ad-hoc shell commands or one-off local instructions.
- Make the smallest build change needed for the feature or remediation.

## Checkstyle Configuration Rules

- Use the Gradle Checkstyle plugin as the default Java lint plugin unless the repository already standardizes on another Java lint tool.
- Apply the `checkstyle` plugin in `build.gradle` or `build.gradle.kts` when Java lint setup is required and missing.
- Configure a stable Checkstyle tool version explicitly instead of relying on Gradle defaults.
- Point Checkstyle to repository-owned configuration under `config/checkstyle` when that directory exists; if no repository config exists yet, add only the minimum build wiring and note that the rules file still needs to be defined.
- Keep Checkstyle attached to the standard Gradle verification lifecycle through the plugin's `checkstyleMain` and `checkstyleTest` tasks.
- Do not disable Checkstyle tasks globally to make the build pass.
- Do not add broad suppressions unless the repository already has an approved suppression pattern.

## Build Wiring Expectations

- Keep plugin declarations, repositories, Java toolchain settings, and quality-tool configuration in the Gradle build file.
- When multiple Java quality plugins are required, keep their configuration separate and readable instead of collapsing everything into one generic block.
- If the repository uses JaCoCo, Dependency Check, Lombok, or Spring Boot, preserve existing configuration style and append only the missing pieces.
- Prefer wiring quality plugins into the default `check` lifecycle rather than inventing custom verification entry points.

## Procedure

1. Inspect `build.gradle` or `build.gradle.kts` before changing Java build behavior.
2. Identify whether Checkstyle and other required Java plugins are already configured.
3. Add or repair the Checkstyle plugin and its minimal configuration when Java lint setup is missing.
4. Preserve existing repository versions, conventions, and Gradle DSL style.
5. If a repository-owned Checkstyle ruleset exists, point the plugin to it instead of creating parallel config paths.
6. Leave command execution and verification reporting to `.github/skills/java-cli/SKILL.md` and `.github/skills/lint/SKILL.md`.

## Recommended Pairings

- `.github/skills/java/SKILL.md` for Java clean architecture and naming rules.
- `.github/skills/lint/SKILL.md` for implementation-time lint behavior and formal lint validation handling.
- `.github/skills/java-cli/SKILL.md` for approved Gradle Wrapper command execution.
- `.github/skills/jacoco/SKILL.md` when coverage wiring is added or changed.
- `.github/skills/lombok/SKILL.md` when Java model classes require Lombok setup.