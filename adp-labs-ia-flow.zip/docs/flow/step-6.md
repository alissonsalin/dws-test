# Step 6: Create Unit Tests

## Purpose

Unit tests ensure that every part of the code works as expected. This step creates a safety net that catches bugs early, prevents regressions, and documents the expected behavior of the code.

## Why This Step Matters

Without tests:
- Bugs slip into production
- Changes break existing functionality unexpectedly
- Developers are reluctant to refactor (fear of breaking things)
- Code behavior becomes undocumented over time

Good test coverage:
- Catches bugs early in development
- Enables confident refactoring and improvements
- Documents expected behavior and edge cases
- Increases development velocity (no firefighting production bugs)

## What You'll Do

1. **Write Comprehensive Tests**:
   - Cover all critical paths (happy path and error scenarios)
   - Test edge cases and boundary conditions
   - Test invalid input handling and error recovery
   - Target high coverage for changed critical paths and document any important remaining gaps

2. **Test Both Success and Failure Cases**:
   - **Success**: Normal operation with valid input
   - **Failure**: Invalid input, missing resources, exceptions, timeouts
   - **Edge Cases**: Empty inputs, large inputs, special characters, concurrent access

3. **Use Appropriate Frameworks**:
   - **Java**: JUnit 5, Mockito for mocking
   - **NodeJS**: Mocha, Chai, Sinon for mocking
   - **Python**: PyTest, unittest, Mock for mocking

4. **Follow Test Structure** — Use Arrange, Act, Assert pattern:
   ```java
   @Test
   void testLoginWithValidCredentials() {
       // Arrange: Set up test data and mocks
       User user = new User("user@example.com", "hashed_password");
       UserRepository repository = mock(UserRepository.class);
       when(repository.findByEmail("user@example.com")).thenReturn(user);
       
       // Act: Execute the code being tested
       LoginService service = new LoginService(repository);
       boolean result = service.login("user@example.com", "password");
       
       // Assert: Verify the result
       assertTrue(result);
       verify(repository).findByEmail("user@example.com");
   }
   ```

5. **Use Mocks Appropriately**:
   - Mock external dependencies (database, APIs, file system)
   - Don't mock the code being tested
   - Keep mocks simple and focused

6. **Performance and Security Tests** (if applicable):
   - For performance-critical code: test response times under load
   - For security-sensitive code: test authentication, authorization, input validation

## Test Coverage Goals

- **High coverage for changed critical business logic**
- **Coverage floors enforced for Java clean architecture layers**:
   - `domain`: 90%+ line coverage
   - `usecase`: 90%+ line coverage
- **Branches covered where behavior changes or risk is high**
- **Exception paths tested** for error handling
- **Happy path and error paths** both tested

## Running Tests

Use the repository command-line instruction file as the source of truth for:
- the approved verification command
- OS-specific command variants
- when verification is allowed in the flow
- retry rules when verification fails

For Java workflows, run the approved verification command after implementation and unit-test updates are complete, and follow the command policy for retries and failure handling.

## Coverage Report

After running tests, review the JaCoCo HTML coverage report to:
- Identify untested code
- Verify branch coverage for conditionals
- Check line coverage percentage
- Identify dead code

When JaCoCo verification rules are configured for Java features:
- Run coverage verification in the same test cycle
- Fix verification failures before closing Step 6
- Do not complete Step 6 if changed `domain` or `usecase` code is below the documented coverage floors unless an explicit approved exception is recorded

## Output

- Comprehensive unit test suite
- Test coverage report (JaCoCo for Java)
- All tests passing with high coverage on changed critical paths and documented gaps where needed
- Documentation of test data and mocking strategies

## Important Restrictions

- Do not run verification commands outside the repository command-line policy.
- Keep verification execution to the approved flow timing and retry behavior.
- If verification fails for a recoverable reason, keep remediation in progress and retry according to the command policy.

## When To Proceed

Before moving to Step 7:
- All tests pass
- Coverage goals for changed critical paths are satisfied or documented
- For Java features, changed `domain` and `usecase` code meets the documented coverage floors or an approved exception is recorded
- Both success and failure paths are tested
- Mocking is appropriate and minimal
- Test names clearly describe what they test
- Verification command execution followed the repository command-line policy

---

**Previous Step:** [Step 5 - Security Validation](step-5.md)  
**Next Step:** [Step 7 - Compare & Adjust](step-7.md)
