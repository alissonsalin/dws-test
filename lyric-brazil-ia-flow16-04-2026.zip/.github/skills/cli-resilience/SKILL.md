---
name: cli-resilience
description: "Run implementation, verification, and security commands with preflight checks, fix-driven retries, and concise failure capture. Use for Java, Node.js, and Python workflows when commands fail or need resilient execution."
argument-hint: "Describe the command goal, stack (Java/Node/Python), and current failure if any"
---

# CLI Resilience

## When to Use

- A verification or security command fails and you need a reliable retry loop.
- You want to run one command per phase with minimal noise.
- You need structured reporting of command failures and applied fixes.

## Procedure

1. Confirm phase and goal; keep command scope to the current phase.
2. Run preflight checks for required tools, expected stack files, and working directory context.
3. Execute one non-interactive target command; prefer Gradle Wrapper for Java projects.
4. If the command fails, capture the error fingerprint, apply a material fix, and retry only when the failure changed or was remediated.
5. Report each attempt with command executed, key pass/fail result, fix applied, and next action.
6. Record repeated failures and successful remediations for Step 9 improvement notes.

## Stack Notes

- Java: run Java environment inspection once at Step 4 start; parse major version before project Java configuration decisions.
- Node/Python: validate toolchain and manifest files (`package.json`, `pyproject.toml`, `requirements.txt`) before verification/security commands.

## Constraints

- Keep command usage minimal and goal-oriented.
- Do not run extra diagnostics unless requested or required by retry policy.
- Do not mark recoverable command issues as final workflow failures.
