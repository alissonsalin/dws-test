# Lyric Brazil GEN IA Flow

Documentation project for a GEN AI feature delivery workflow, built with MkDocs Material.

## What This Project Contains

- MkDocs configuration in `mkdocs.yml`
- Documentation content in `docs/`
- Reusable Copilot instructions in `.github/`

## Prerequisites

You need:

1. Python 3.10+
2. pip (Python package manager)
3. MkDocs and required plugins/themes

## Install Python and pip

### Windows

1. Download Python from the official website:
   - https://www.python.org/downloads/windows/
2. Run installer and check "Add Python to PATH".
3. Verify installation:

```powershell
python --version
python -m pip --version
```

Alternative (winget):

```powershell
winget install --id Python.Python.3.12 -e --source winget
```

### MacOS

Option A: Homebrew (recommended)

```bash
brew install python
python3 --version
pip3 --version
```

Option B: Official installer

1. Download from:
   - https://www.python.org/downloads/macos/
2. Verify:

```bash
python3 --version
pip3 --version
```

### Linux

Debian/Ubuntu:

```bash
sudo apt-get update
sudo apt-get install -y python3 python3-pip python3-venv
python3 --version
pip3 --version
```

Fedora/RHEL:

```bash
sudo dnf install -y python3 python3-pip
python3 --version
pip3 --version
```

Arch:

```bash
sudo pacman -S --noconfirm python python-pip
python3 --version
pip3 --version
```

## Python Virtual Environments

Use a local virtual environment to keep project dependencies isolated.

### Windows

Create the virtual environment:

```powershell
python -m venv .venv
```

Activate it:

```powershell
.\.venv\Scripts\activate
```

If PowerShell blocks activation, you can use Command Prompt instead:

```bat
.venv\Scripts\activate.bat
```

Install dependencies inside the virtual environment:

```powershell
python -m pip install --upgrade pip
python -m pip install mkdocs mkdocs-material pymdown-extensions
```

Deactivate when finished:

```powershell
deactivate
```

### macOS

Create the virtual environment:

```bash
python3 -m venv .venv
```

Activate it:

```bash
source .venv/bin/activate
```

Install dependencies inside the virtual environment:

```bash
python3 -m pip install --upgrade pip
python3 -m pip install mkdocs mkdocs-material pymdown-extensions
```

Deactivate when finished:

```bash
deactivate
```

### Linux

Create the virtual environment:

```bash
python3 -m venv .venv
```

Activate it:

```bash
source .venv/bin/activate
```

Install dependencies inside the virtual environment:

```bash
python3 -m pip install --upgrade pip
python3 -m pip install mkdocs mkdocs-material pymdown-extensions
```

Deactivate when finished:

```bash
deactivate
```

## Install MkDocs

From the project root:

```bash
python -m pip install --upgrade pip
python -m pip install mkdocs mkdocs-material pymdown-extensions
```

If your system uses `python3`:

```bash
python3 -m pip install --upgrade pip
python3 -m pip install mkdocs mkdocs-material pymdown-extensions
```

## Run Documentation Locally

Manual run:

```bash
mkdocs serve --livereload
```

Then open:
- http://127.0.0.1:8000

## Generate HTML Files (Static Build)

Use MkDocs build mode to generate static HTML files for publishing.

From the project root:

```bash
mkdocs build --clean
```

Optional strict mode (fails on warnings such as broken links):

```bash
mkdocs build --clean --strict
```

Build output:

- HTML and assets are generated in `site/`
- Main entry file is `site/index.html`

To regenerate after changes, run the build command again.

If `mkdocs` is not found, activate your virtual environment first.

## One-Command Setup Scripts

This project includes scripts that install what is needed and start MkDocs with livereload.

### Windows

```powershell
.\setup-and-serve.bat
```

### MacOS/Linux

```bash
chmod +x ./setup-and-serve.sh
./setup-and-serve.sh
```

Both scripts will:

1. Check/install Python and pip (best effort per OS)
2. Create a local virtual environment (`.venv`)
3. Install MkDocs dependencies
4. Start `mkdocs serve --livereload`

## Install Copilot Instructions Into Another Repository

Installer scripts are available in `install-instructions/`:

- `install-instructions/install-copilot-instructions.bat`
- `install-instructions/install-copilot-instructions.sh`

## IntelliJ Warning

If you use GitHub Copilot Chat in IntelliJ with the `flow-orchestrator`, `planner`, or `coder` agents, open `Configure Tools` and enable all Built-in tools for those agents before running the workflow.

If the Built-in tools are not enabled, delegated steps may fail to read files, search the workspace, edit files, or run verification commands even when the agent instructions are correct.

These scripts now require explicit input for:

1. Source project path (the project that contains `.github`)
2. Target repository path (destination for the `.github` copy)

Behavior:

1. If source `.github` does not exist, it is created.
2. The installer copies the full `.github` tree, including nested folders.
3. A final status summary is shown (`SUCCESS`, `NO_FILES_TO_COPY`, or `FAILURE`).

### Windows

```powershell
cd install-instructions
.\install-copilot-instructions.bat
```

### MacOS/Linux

```bash
cd install-instructions
bash ./install-copilot-instructions.sh
```

## Tech Refresh Workflow (Optional)

For occasional technology migration initiatives (for example NodeJS to Java), use the opt-in tech refresh prompt instead of changing the default workflow.

- Prompt: `.github/prompts/tech-refresh.prompt.md`
- Scoped instruction: `.github/instructions/tech-refresh.instructions.md`

This path enforces prerequisite analysis first (code analysis, migration plan, validations) and only then runs Step 1 to Step 9 after explicit approval.

## Troubleshooting

- If `mkdocs` is not found, activate the virtual environment and run again.
- If port 8000 is busy, stop the conflicting process and rerun.
- If package install fails, check network/proxy settings and retry.

## TODO List

- [ ] Review instructions
- [ ] Review documentation site
   - [ ] Find broken links
- [ ] Update Java definition for different project
- [ ] Review NodeJS instructions
- [ ] Review Python instructions
- [ ] Review tech refresh instructions and documentation
   - [ ] Create prompts or instructions to refresh code in small pieces to avoid a big bang of changes
   - [ ] Improve validation plan
- [ ] Create MCP server for LGIT (if not exist)
- [ ] Evaluate Context7 MCP server
- [ ] Evaluate creating agents by project
- [ ] Update instructions to a non-interactive process (no confirmations needed) - evaluate
- [ ] Improve CVE validation and integrate with Snyk
- [ ] Review unit tests and improve using existing instructions for all projects
- [ ] Integrate instructions with Jira MCP server
   - [ ] Create Jira stories associated with the used feature
      - [ ] Title
      - [ ] Description
      - [ ] Status
      - [ ] Assignee
      - [ ] Fix version
- [ ] Integrate instructions with Confluence MCP server
   - [ ] Update with technical design definition
   - [ ] Create page to centralize that
- [ ] Create a centralized view (Confluence or docs page) with all features in development
   - [ ] Title
   - [ ] Jira ticket and link
   - [ ] Target version
   - [ ] Team
   - [ ] Risk, projects/services impacted, and rollback plan
- [ ] Integrate instructions with Bitbucket MCP server
   - [ ] Create branch for new feature
   - [ ] Open PR with changes from the created branch
      - [ ] Integrate with Autobit
   - [ ] Update Jira status after PR approval (evaluate)
- [ ] Integrate with Playwright for automated tests
- [ ] Automate deploy

> **Note:** Remember to update documentation after the changes.
