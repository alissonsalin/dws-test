import * as vscode from "vscode";
import {
  AVAILABLE_AGENTS,
  DEFAULT_FEATURE_OPTIONS,
  FLOW_ORCHESTRATOR_AGENT,
  FeatureOption,
  Logger,
  RunState,
  StartRunRequest,
  safeStringify
} from "./shared";
import { FlowStore } from "./flowStore";
import { LogsWatcher, LogEntry } from "./logsWatcher";

export class DashboardController implements vscode.Disposable {
  private panel: vscode.WebviewPanel | undefined;
  private webviewReady = false;
  private featureOptions: FeatureOption[] = [...DEFAULT_FEATURE_OPTIONS];
  private featureLoading = false;
  private featureError = "";
  private readonly disposables: vscode.Disposable[] = [];
  private readonly context: vscode.ExtensionContext;
  private readonly store: FlowStore;
  private readonly onStartRun: (request: StartRunRequest) => Promise<void>;
  private readonly onLoadFeatures: () => Promise<void>;
  private readonly logger: Logger;
  private logsWatcher: LogsWatcher | undefined;

  public constructor(
    context: vscode.ExtensionContext,
    logger: Logger,
    store: FlowStore,
    onStartRun: (request: StartRunRequest) => Promise<void>,
    onLoadFeatures: () => Promise<void>,
    workspaceRootPath: string | undefined
  ) {
    this.context = context;
    this.store = store;
    this.onStartRun = onStartRun;
    this.onLoadFeatures = onLoadFeatures;
    this.logger = logger;
    this.disposables.push(this.store.onDidChangeState((state) => this.postState(state)));
  }

  public async show(): Promise<void> {
    if (!this.panel) {
      this.panel = vscode.window.createWebviewPanel(
        "visualFlow.dashboard",
        "Visual Flow Dashboard",
        vscode.ViewColumn.One,
        {
          enableScripts: true,
          retainContextWhenHidden: true
        }
      );

      this.panel.onDidDispose(
        () => {
          this.panel = undefined;
          this.webviewReady = false;
        },
        undefined,
        this.disposables
      );

      this.panel.webview.onDidReceiveMessage(
        async (message: unknown) => {
          if (!message || typeof message !== "object") {
            return;
          }
          const payload = message as { type?: string; request?: StartRunRequest };
          if (payload.type === "webviewReady") {
            this.webviewReady = true;
            this.syncWebview();
            return;
          }
          if (payload.type === "startRun" && payload.request) {
            try {
              await this.onStartRun(payload.request);
            } catch (error) {
              const messageValue = error instanceof Error ? error.message : String(error);
              this.logger.log("Failed to start run via dashboard callback.", { message: messageValue });
              void vscode.window.showErrorMessage(messageValue);
            }
            return;
          }
          if (payload.type === "requestFeatureRefresh") {
            try {
              await this.onLoadFeatures();
            } catch (error) {
              const messageValue = error instanceof Error ? error.message : String(error);
              this.logger.log("Failed to load features via dashboard callback.", { message: messageValue });
              this.setFeatureError(messageValue);
              void vscode.window.showErrorMessage(messageValue);
            }
          }
        },
        undefined,
        this.disposables
      );
    }

    this.webviewReady = false;
    this.panel.webview.html = this.getHtml(this.panel.webview);
    this.panel.reveal(vscode.ViewColumn.One, true);
    await this.postState(this.store.getState());

    const hasLoadedFeatures =
      this.featureOptions.length > 1 ||
      this.featureOptions.some((feature) => feature.value !== DEFAULT_FEATURE_OPTIONS[0].value);
    if (!this.featureLoading && !hasLoadedFeatures) {
      void this.handleLoadFeatures();
    }
  }

  public setFeatures(featureOptions: FeatureOption[]): void {
    this.featureOptions = featureOptions.length > 0 ? featureOptions : [...DEFAULT_FEATURE_OPTIONS];
    this.featureError = "";
    this.postFeatureOptions();
  }

  public setFeatureLoading(loading: boolean): void {
    this.featureLoading = loading;
    this.postFeatureLoadingState();
  }

  public setFeatureError(message: string): void {
    this.featureError = message;
    this.postFeatureLoadingState();
  }

  public getFeatures(): FeatureOption[] {
    return [...this.featureOptions];
  }

  public dispose(): void {
    this.panel?.dispose();
    this.disposables.forEach((item) => item.dispose());
  }

  /**
   * Start watching logsFilePath for changes.
    * Pass the workspace logs/logs.md path so visual-log writes drive UI updates.
   */
  public startLogsWatcher(logsFilePath: string): void {
    this.stopLogsWatcher();
    this.logsWatcher = new LogsWatcher(logsFilePath, this.logger, (entries) => {
      this.handleLogsChanged(entries);
    });
    this.disposables.push(this.logsWatcher);
    this.logsWatcher.start();
  }

  public stopLogsWatcher(): void {
    if (this.logsWatcher) {
      this.logsWatcher.stop();
      this.logsWatcher = undefined;
    }
  }

  private handleLogsChanged(entries: LogEntry[]): void {
    // Map log entries to step updates and timeline milestones.
    for (const entry of entries) {
      const stepMatch = entry.step.match(/^Step\s+(\d+)\s*-\s*(.+)$/i);
      if (stepMatch) {
        const stepNumber = parseInt(stepMatch[1], 10);
        const stepName = stepMatch[2].trim();
        this.store.updateStep(stepNumber, entry.status, "visual-log", entry.notes || stepName, entry.timestamp);

        const timelineType = this.mapLogStatusToTimelineType(entry.status);
        if (timelineType) {
          this.store.recordEvent({
            timestamp: entry.timestamp,
            type: timelineType,
            owner: "visual-log",
            level: "info",
            message: `Step ${stepNumber} - ${stepName} [${entry.status}]`,
            stepNumber,
            stepStatus: entry.status
          });
        }
      }
    }
  }

  private mapLogStatusToTimelineType(status: LogEntry["status"]): string | undefined {
    switch (status) {
      case "in-progress":
        return "step-started";
      case "completed":
        return "step-completed";
      case "failed":
        return "step-failed";
      case "skipped":
        return "step-skipped";
      default:
        return undefined;
    }
  }

  private async handleLoadFeatures(): Promise<void> {
    try {
      await this.onLoadFeatures();
    } catch (error) {
      const messageValue = error instanceof Error ? error.message : String(error);
      this.logger.log("Failed to load features via dashboard callback.", { message: messageValue });
      this.setFeatureError(messageValue);
      void vscode.window.showErrorMessage(messageValue);
    }
  }

  private syncWebview(): void {
    this.postFeatureLoadingState();
    this.postFeatureOptions();
    this.postState(this.store.getState());
  }

  private postFeatureOptions(): void {
    if (!this.panel || !this.webviewReady) {
      return;
    }
    void this.panel.webview.postMessage({
      type: "featureOptions",
      featureOptions: this.featureOptions
    });
  }

  private postFeatureLoadingState(): void {
    if (!this.panel || !this.webviewReady) {
      return;
    }
    const message = this.featureError
      ? `Failed to load Jira features: ${this.featureError}`
      : this.featureLoading
        ? "Loading Jira sample features..."
        : `Loaded ${this.featureOptions.length} Jira sample features.`;

    void this.panel.webview.postMessage({
      type: "featureLoadingState",
      loading: this.featureLoading,
      message
    });
  }

  private postState(state: RunState | undefined): void {
    if (!this.panel || !this.webviewReady) {
      return;
    }
    void this.panel.webview.postMessage({
      type: "state",
      state
    });
  }

  private getHtml(webview: vscode.Webview): string {
    const nonce = createNonce();
    const featureOptionsPayload = safeStringify(this.featureOptions);
    const agentsPayload = safeStringify(AVAILABLE_AGENTS);
    const statePayload = safeStringify(this.store.getState());
    const loadingPayload = this.featureLoading ? "true" : "false";
    const loadingMessagePayload = safeStringify(
      this.featureError
        ? `Failed to load Jira features: ${this.featureError}`
        : this.featureLoading
          ? "Loading Jira sample features..."
          : `Loaded ${this.featureOptions.length} Jira sample features.`
    );

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}';" />
  <title>Visual Flow Dashboard</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #0f1b2f;
      --panel: #13233d;
      --panel-alt: #0d1a2f;
      --line: #27446f;
      --text: #e8f1ff;
      --muted: #9fb2d4;
      --ok: #3ccf91;
      --warn: #f8b454;
      --err: #ff7b7b;
      --run: #69b5ff;
    }
    body {
      margin: 0;
      padding: 14px;
      font-family: "Segoe UI", sans-serif;
      color: var(--text);
      background: var(--bg);
    }
    .card {
      border: 1px solid var(--line);
      border-radius: 10px;
      background: var(--panel);
      padding: 10px;
      margin-bottom: 12px;
    }
    .title {
      margin: 0 0 8px 0;
      font-size: 22px;
      font-weight: 700;
      letter-spacing: 0.03em;
      color: #b8d6ff;
    }
    .grid2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }
    label {
      display: block;
      margin-bottom: 6px;
      color: #c7dbff;
      font-size: 12px;
    }
    select, textarea, button {
      width: 100%;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: #071427;
      color: var(--text);
      font-size: 14px;
      box-sizing: border-box;
    }
    select {
      min-height: 36px;
      padding: 6px 10px;
    }
    textarea {
      min-height: 112px;
      padding: 10px;
      resize: vertical;
      line-height: 1.35;
    }
    .status {
      margin: 0 0 10px 0;
      display: flex;
      align-items: center;
      gap: 8px;
      color: #ffd38f;
      font-size: 13px;
    }
    .status.loading {
      color: #ffd38f;
    }
    .status.success {
      color: var(--ok);
    }
    .status.error {
      color: var(--err);
    }
    .dot {
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background: var(--warn);
      opacity: 0.9;
    }
    .dot.success {
      background: var(--ok);
    }
    .dot.error {
      background: var(--err);
    }
    .dot.loading {
      animation: pulse 1.1s ease-in-out infinite;
    }
    @keyframes pulse {
      0% { transform: scale(0.8); opacity: 0.35; }
      50% { transform: scale(1.2); opacity: 1; }
      100% { transform: scale(0.8); opacity: 0.35; }
    }
    .actions {
      margin-top: 10px;
      display: flex;
      gap: 8px;
      align-items: center;
    }
    button {
      width: auto;
      padding: 8px 14px;
      background: #1f4f87;
      cursor: pointer;
    }
    button:hover {
      background: #2763a7;
    }
    button.secondary {
      background: #183457;
    }
    .hint {
      margin-top: 8px;
      color: var(--muted);
      font-size: 12px;
    }
    .panel-title {
      margin: 0 0 10px 0;
      color: #b8d6ff;
      font-size: 22px;
      font-weight: 600;
      letter-spacing: 0.02em;
    }
    .step-list, .timeline-list {
      list-style: none;
      margin: 0;
      padding: 0;
      display: grid;
      gap: 8px;
    }
    .timeline-item {
      border: 1px solid #22426f;
      border-radius: 8px;
      background: var(--panel-alt);
      padding: 8px 10px;
      min-width: 0;
      overflow: hidden;
    }
    .step-list table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }
    .step-list th, .step-list td {
      border-bottom: 1px solid #22426f;
      padding: 6px 8px;
      text-align: left;
      vertical-align: top;
    }
    .step-list th {
      color: #c7dbff;
      font-weight: 600;
    }
    .badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 999px;
      border: 1px solid transparent;
      font-size: 11px;
      text-transform: lowercase;
      font-weight: 600;
      line-height: 1.2;
    }
    .badge.pending {
      color: #ffcf82;
      border-color: color-mix(in srgb, #ffcf82 60%, transparent);
      background: color-mix(in srgb, #ffcf82 14%, transparent);
    }
    .badge.in-progress {
      color: var(--run);
      border-color: color-mix(in srgb, var(--run) 60%, transparent);
      background: color-mix(in srgb, var(--run) 14%, transparent);
    }
    .badge.completed {
      color: var(--ok);
      border-color: color-mix(in srgb, var(--ok) 60%, transparent);
      background: color-mix(in srgb, var(--ok) 14%, transparent);
    }
    .badge.failed {
      color: var(--err);
      border-color: color-mix(in srgb, var(--err) 60%, transparent);
      background: color-mix(in srgb, var(--err) 14%, transparent);
    }
    .badge.skipped {
      color: var(--muted);
      border-color: color-mix(in srgb, var(--muted) 60%, transparent);
      background: color-mix(in srgb, var(--muted) 14%, transparent);
    }
    .timeline-item {
      border-left: 2px solid var(--line);
    }
    .timeline-item strong,
    .timeline-item div {
      overflow-wrap: anywhere;
      word-break: break-word;
    }
    .timeline-detail {
      white-space: normal;
      overflow-wrap: anywhere;
      word-break: break-word;
    }
    .timeline-meta {
      color: var(--muted);
      font-size: 11px;
      margin-top: 4px;
      overflow-wrap: anywhere;
      word-break: break-word;
    }
    .empty {
      color: var(--muted);
      font-size: 12px;
    }
  </style>
</head>
<body>
  <section class="card">
    <h1 class="panel-title">START RUN</h1>
    <div id="loadingStatus" class="status loading">
      <span id="loadingDot" class="dot"></span>
      <span id="loadingText">Loading features...</span>
    </div>

    <div class="grid2">
      <div>
        <label for="featureNameSelect">Feature</label>
        <select id="featureNameSelect"></select>
      </div>
      <div>
        <label for="agentSelect">Agent</label>
        <select id="agentSelect"></select>
      </div>
    </div>

    <div style="margin-top:10px;">
      <label for="featureDescriptionInput">Feature description</label>
      <textarea id="featureDescriptionInput" readonly></textarea>
    </div>

    <div class="actions">
      <button id="startRunButton" type="button">Start Run</button>
      <button id="reloadFeaturesButton" class="secondary" type="button">Reload Features</button>
    </div>
    <div class="hint">Select an agent to prepare the feature input and prompt.</div>
  </section>

  <div class="grid2">
    <section class="card">
      <h2 class="title">STEP STATUS</h2>
      <div id="stepList" class="step-list"></div>
      <div id="stepEmpty" class="empty">No active flow run yet.</div>
    </section>

    <section class="card">
      <h2 class="title">TIMELINE</h2>
      <ul id="timelineList" class="timeline-list"></ul>
      <div id="timelineEmpty" class="empty">No timeline events yet.</div>
    </section>
  </div>

  <script nonce="${nonce}">
    const vscodeApi = acquireVsCodeApi();
    const featureNameSelect = document.getElementById("featureNameSelect");
    const agentSelect = document.getElementById("agentSelect");
    const featureDescriptionInput = document.getElementById("featureDescriptionInput");
    const startRunButton = document.getElementById("startRunButton");
    const reloadFeaturesButton = document.getElementById("reloadFeaturesButton");
    const loadingDot = document.getElementById("loadingDot");
    const loadingStatus = document.getElementById("loadingStatus");
    const loadingText = document.getElementById("loadingText");
    const stepList = document.getElementById("stepList");
    const stepEmpty = document.getElementById("stepEmpty");
    const timelineList = document.getElementById("timelineList");
    const timelineEmpty = document.getElementById("timelineEmpty");

    let currentFeatureOptions = ${featureOptionsPayload};
    let availableAgents = ${agentsPayload};
    let currentState = ${statePayload};
    let isFeatureLoading = ${loadingPayload};
    let loadingMessage = ${loadingMessagePayload};

    function escapeText(value) {
      return String(value ?? "");
    }

    function getSelectedFeature() {
      const value = featureNameSelect.value;
      return currentFeatureOptions.find((item) => item.value === value) || currentFeatureOptions[0];
    }

    function buildFeatureDescription(feature) {
      if (!feature) {
        return "";
      }
      return "ID: " + escapeText(feature.id) + "\\n"
        + "Title: " + escapeText(feature.title) + "\\n"
        + "Description: " + escapeText(feature.description || "");
    }

    function updateFeatureDescription() {
      featureDescriptionInput.value = buildFeatureDescription(getSelectedFeature());
    }

    function renderFeatureOptions() {
      const selectedValue = featureNameSelect.value;
      featureNameSelect.innerHTML = "";
      currentFeatureOptions.forEach((feature, index) => {
        const option = document.createElement("option");
        option.value = feature.value;
        option.textContent = feature.label;
        option.selected = selectedValue ? selectedValue === feature.value : index === 0;
        featureNameSelect.appendChild(option);
      });
      if (featureNameSelect.options.length > 0 && !featureNameSelect.value) {
        featureNameSelect.selectedIndex = 0;
      }
      updateFeatureDescription();
    }

    function renderAgents() {
      const selected = agentSelect.value || "${FLOW_ORCHESTRATOR_AGENT}";
      agentSelect.innerHTML = "";
      availableAgents.forEach((agent) => {
        const option = document.createElement("option");
        option.value = agent;
        option.textContent = agent;
        option.selected = selected === agent;
        agentSelect.appendChild(option);
      });
    }

    function setLoadingUi(loading, message) {
      isFeatureLoading = !!loading;
      loadingMessage = message || "";
      featureNameSelect.disabled = isFeatureLoading;
      loadingDot.classList.toggle("loading", isFeatureLoading);
      loadingDot.classList.toggle("success", !isFeatureLoading && !/^failed/i.test(loadingMessage));
      loadingDot.classList.toggle("error", !isFeatureLoading && /^failed/i.test(loadingMessage));
      loadingStatus.classList.toggle("loading", isFeatureLoading);
      loadingStatus.classList.toggle("success", !isFeatureLoading && !/^failed/i.test(loadingMessage));
      loadingStatus.classList.toggle("error", !isFeatureLoading && /^failed/i.test(loadingMessage));
      loadingText.textContent = loadingMessage || (isFeatureLoading ? "Loading features..." : "Features loaded");
    }

    function formatStepStatusLabel(status) {
      return String(status || "").replace("-", " ");
    }

    function formatAmericanDateTime(value) {
      if (!value) {
        return "-";
      }
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) {
        return String(value);
      }
      return date
        .toLocaleString("en-US", {
          month: "2-digit",
          day: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: true
        })
        .replace(",", "");
    }

    function compactTimelineMessage(value) {
      const text = escapeText(value || "No detail");
      return text
        .replace(/Run\\s+[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, "Run")
        .replace(/\\s+/g, " ")
        .trim();
    }

    function formatTimelineDetail(value) {
      return compactTimelineMessage(value)
        .replace(/^Step\s+\d+\s*-\s*/i, "")
        .replace(/^Step\s+\d+\s+failure summary:\s*/i, "Failure summary: ")
        .replace(/^Step\s+\d+\s+started$/i, "Started")
        .replace(/^Step\s+\d+\s+completed$/i, "Completed")
        .replace(/^Step\s+\d+\s+failed$/i, "Failed")
        .replace(/^Step\s+\d+\s+skipped$/i, "Skipped");
    }

    function renderSteps() {
      stepList.innerHTML = "";
      const state = currentState;
      if (!state || !Array.isArray(state.steps) || state.steps.length === 0 || state.selectedAgent !== "${FLOW_ORCHESTRATOR_AGENT}") {
        stepEmpty.style.display = "block";
        return;
      }
      stepEmpty.style.display = "none";
      const rows = state.steps.map((step) => {
        const safeName = escapeText(step.name);
        const safeStatus = escapeText(step.status);
        const safeOwner = escapeText(step.owner || "-");
        return "<tr>"
          + "<td>Step " + step.stepNumber + " - " + safeName + "</td>"
          + "<td><span class=\\"badge " + safeStatus + "\\">" + formatStepStatusLabel(safeStatus) + "</span></td>"
          + "<td>" + safeOwner + "</td>"
          + "</tr>";
      }).join("");

      stepList.innerHTML =
        "<table><thead><tr><th>Step</th><th>Status</th><th>Agent</th></tr></thead><tbody>"
        + rows
        + "</tbody></table>";
    }

    function renderTimeline() {
      timelineList.innerHTML = "";
      const state = currentState;
      if (!state || !Array.isArray(state.timeline) || state.timeline.length === 0) {
        timelineEmpty.style.display = "block";
        return;
      }
      timelineEmpty.style.display = "none";
      const entries = [...state.timeline].reverse().slice(0, 20);
      entries.forEach((entry) => {
        const li = document.createElement("li");
        li.className = "timeline-item";
        const eventType = escapeText(entry.type || "event");
        const ownerPart = entry.owner ? (" | " + escapeText(entry.owner)) : "";
        const messageText = formatTimelineDetail(entry.message);

        const head = document.createElement("div");
        const strong = document.createElement("strong");
        strong.textContent = eventType;
        head.appendChild(strong);

        const detail = document.createElement("div");
        detail.className = "timeline-detail";
        detail.textContent = messageText;

        const meta = document.createElement("div");
        meta.className = "timeline-meta";
        meta.textContent = formatAmericanDateTime(entry.timestamp) + ownerPart;

        li.appendChild(head);
        li.appendChild(detail);
        li.appendChild(meta);
        timelineList.appendChild(li);
      });
    }

    function renderState() {
      renderSteps();
      renderTimeline();
    }

    featureNameSelect.addEventListener("change", updateFeatureDescription);
    reloadFeaturesButton.addEventListener("click", () => {
      vscodeApi.postMessage({ type: "requestFeatureRefresh" });
    });
    startRunButton.addEventListener("click", () => {
      const feature = getSelectedFeature();
      vscodeApi.postMessage({
        type: "startRun",
        request: {
          selectedAgent: agentSelect.value,
          featureValue: feature ? feature.value : "",
          instruction: ""
        }
      });
    });

    window.addEventListener("message", (event) => {
      const message = event.data || {};
      if (message.type === "featureOptions") {
        currentFeatureOptions = Array.isArray(message.featureOptions) ? message.featureOptions : [];
        renderFeatureOptions();
      }
      if (message.type === "featureLoadingState") {
        setLoadingUi(!!message.loading, message.message || "");
      }
      if (message.type === "state") {
        currentState = message.state;
        renderState();
      }
    });

    renderAgents();
    renderFeatureOptions();
    setLoadingUi(isFeatureLoading, loadingMessage);
    renderState();
    vscodeApi.postMessage({ type: "webviewReady" });
  </script>
</body>
</html>`;
  }
}

function createNonce(): string {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let nonce = "";
  for (let i = 0; i < 24; i += 1) {
    nonce += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return nonce;
}
