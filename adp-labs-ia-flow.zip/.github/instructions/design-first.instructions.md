---
applyTo: "**/*.{java,kt,js,ts,py,gradle,kts,yml,yaml,md}"
description: "Use when running feature workflows to enforce design approval before any implementation actions."
---

# Design-First Enforcement Rules

- Do not generate implementation code before Step 2 technical design approval is explicitly captured.
- Before approval, do not create or edit source files, test files, or build files.
- Before approval, do not run implementation commands, scaffolding commands, or code generation tools.
- Allowed before approval: requirement analysis, technical design drafting, user stories, Definition of Done drafting, and clarification questions.
- If the user asks for implementation before approval, refuse implementation and continue with design completion.
- At the beginning of Step 4, restate that Step 2 is completed and approval is recorded, then proceed to implementation.
- If approval status is ambiguous or missing, stop implementation and request explicit confirmation.
