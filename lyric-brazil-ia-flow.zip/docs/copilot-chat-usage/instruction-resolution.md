# Instruction Resolution

Copilot combines instruction sources in your repository to shape responses and code changes.

## Workspace Entrypoint

Source: .github/copilot-instructions.md

This file is the workspace entrypoint for shared Copilot behavior. It does not carry the full workflow logic anymore. Instead, it points to the main feature agent and registers always-on instruction files and on-demand skills.

It defines:

1. Which agent to use for feature work.
2. Which instruction files are always available by scope.
3. Which skills are available on demand.
4. Shared deliverable expectations for completed features.

## Custom Agents

Source: .github/agents/

Custom agents hold the main workflow logic when the task needs it.

Example in this repository:

1. `feature-flow.agent.md` runs the Step 1 to Step 9 feature workflow.
2. It manages gates, TODO tracking, implementation sequencing, validation, troubleshooting, and continuous improvement.
3. It also defines tool usage rules, autonomous execution behavior, and shortcut phrases such as `Implement this`.

## Scoped Instructions

Source: .github/instructions/

These files apply by file pattern using applyTo and provide focused guidance for specific work types.

Examples include:

1. Documentation rules
2. Clean architecture rules
3. Command resilience and retry rules
4. Testing rules
5. Workflow status rules
6. Tech refresh analysis rules

When you ask Copilot to work on a file that matches a scope, the corresponding instruction file is applied in addition to the workspace entrypoint and any selected agent.

## On-Demand Skills

Source: .github/skills/

Skills are loaded only for specialized tasks instead of being present in every chat turn.

Examples in this repository:

1. Language implementation baselines for Java, Node.js, and Python.
2. CLI resilience for fix-driven command retries and preflight checks.
3. Spring, Lombok, Java CLI, and OpenAPI guidance for implementation phases.
4. ArchUnit guidance for Java architecture boundary tests.

## Resolution Sequence

1. Load the workspace entrypoint from `.github/copilot-instructions.md`.
2. If the user selects or invokes a custom agent, load that agent.
3. Detect task context, for example docs, Java, tests, or Node.js.
4. Match relevant scoped instruction files by `applyTo` patterns.
5. Load on-demand skills only when the task calls for them, especially for language-specific implementation and specialized workflows.
6. Use the combined guidance to generate answers and edits.

## Next

Continue to [Workflow Gates](workflow-gates.md).