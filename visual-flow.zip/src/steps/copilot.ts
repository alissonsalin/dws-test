import { execFile } from "child_process";
import { promisify } from "util";
import * as vscode from "vscode";
import * as path from "path";
import {
  CopilotExecutable,
  JIRA_FEATURE_AGENT,
  JIRA_SAMPLE_REQUEST,
  quoteForDoubleQuotedShellArg,
  quoteForPowerShellSingleQuotedArg,
  parseFeatureOptionsFromCopilotOutput,
  FeatureOption,
  CLI_COMMAND_TEMPLATE_SETTING,
  CLI_TERMINAL_NAME_SETTING,
  Logger
} from "./shared";

const execFileAsync = promisify(execFile);

export function buildInstruction(
  featureId: string,
  featureTitle: string,
  featureDescription: string,
  selectedAgent: string
): string {
  const baseContext = [
    `Selected feature id: ${featureId}`,
    `Selected feature title: ${featureTitle}`,
    `Selected feature description: ${featureDescription || "No description provided."}`
  ];

  if (selectedAgent === JIRA_FEATURE_AGENT) {
    return `${baseContext.join("\n")}\n\nRespond with a concise Jira feature intake summary.`;
  }

  if (selectedAgent === "flow-orchestrator") {
    return `${baseContext.join("\n")}\n\nExecute Step 1 to Step 9 with explicit status progression and clear milestone updates. Start the flow status log at Step 0 and keep the flow status log updated throughout the run.`;
  }

  return `${baseContext.join("\n")}\n\nProceed with the selected agent objective and include concise status updates.`;
}

export async function loadFeaturesFromJiraAgent(workspaceRootPath: string | undefined, logger: Logger): Promise<FeatureOption[]> {
  if (!workspaceRootPath) {
    throw new Error("Open a workspace folder before loading Jira features.");
  }

  const executable = await resolveCopilotExecutable(workspaceRootPath);
  const copilotArgs = [
    ...executable.execArgsPrefix,
    "--agent",
    JIRA_FEATURE_AGENT,
    "-p",
    JIRA_SAMPLE_REQUEST,
    "--add-dir",
    workspaceRootPath,
    "--allow-all-tools",
    "--silent",
    "--no-color",
    "--stream",
    "off"
  ];

  const isPowerShellCopilotPathMode =
    executable.execFile.toLowerCase() === "powershell.exe" &&
    executable.commandForTemplate === "copilot";

  const args = isPowerShellCopilotPathMode
    ? [
        "-NoProfile",
        "-Command",
        ["copilot", ...copilotArgs]
          .map((arg) => {
            if (/^[a-zA-Z0-9_:\/\.\-]+$/.test(arg)) {
              return arg;
            }
            return `'${quoteForPowerShellSingleQuotedArg(arg)}'`;
          })
          .join(" ")
      ]
    : copilotArgs;

  logger.log("Loading Jira features.", {
    agent: JIRA_FEATURE_AGENT,
    cwd: workspaceRootPath,
    command: executable.execFile,
    args
  });

  const { stdout, stderr } = await execFileAsync(executable.execFile, args, {
    cwd: workspaceRootPath,
    windowsHide: true,
    encoding: "utf8",
    maxBuffer: 16 * 1024 * 1024,
    timeout: 90_000
  });

  if (stderr?.trim()) {
    logger.log("Jira agent stderr output.", { stderr });
  }

  const features = parseFeatureOptionsFromCopilotOutput(stdout);
  if (features.length === 0) {
    throw new Error("Jira agent returned no features.");
  }
  logger.log("Parsed Jira features.", { count: features.length });
  return features;
}

export async function resolveCopilotExecutable(workspaceRootPath: string | undefined): Promise<CopilotExecutable> {
  const configuredPath = process.env.COPILOT_CLI_PATH?.trim();
  if (configuredPath) {
    const normalized = configuredPath.replace(/^"(.*)"$/, "$1");
    if (normalized.toLowerCase().endsWith(".ps1")) {
      return {
        commandForTemplate: `& '${quoteForPowerShellSingleQuotedArg(normalized)}'`,
        execFile: "powershell.exe",
        execArgsPrefix: ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", normalized]
      };
    }
    return {
      commandForTemplate: normalized,
      execFile: normalized,
      execArgsPrefix: []
    };
  }

  const candidates: Array<{ execFile: string; args: string[]; commandForTemplate: string }> = [
    { execFile: "copilot", args: ["--version"], commandForTemplate: "copilot" },
    { execFile: "github-copilot-cli", args: ["--version"], commandForTemplate: "github-copilot-cli" }
  ];

  if (process.platform === "win32") {
    candidates.push({
      execFile: "powershell.exe",
      args: ["-NoProfile", "-Command", "copilot --version"],
      commandForTemplate: "copilot"
    });
  }

  if (workspaceRootPath) {
    const bundledPath = path.join(workspaceRootPath, "node_modules", ".bin", "copilot.ps1");
    candidates.push({
      execFile: "powershell.exe",
      args: ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", bundledPath, "--version"],
      commandForTemplate: `& '${quoteForPowerShellSingleQuotedArg(bundledPath)}'`
    });
  }

  candidates.push({ execFile: "gh", args: ["copilot", "--help"], commandForTemplate: "gh copilot" });

  for (const candidate of candidates) {
    try {
      await execFileAsync(candidate.execFile, candidate.args, {
        cwd: workspaceRootPath,
        windowsHide: true,
        timeout: 15000
      });
      if (candidate.execFile === "gh" && candidate.commandForTemplate === "gh copilot") {
        return {
          commandForTemplate: "gh copilot",
          execFile: "gh",
          execArgsPrefix: ["copilot"]
        };
      }

      if (candidate.execFile.toLowerCase() === "powershell.exe" && candidate.commandForTemplate === "copilot") {
        return {
          commandForTemplate: "copilot",
          execFile: "powershell.exe",
          execArgsPrefix: []
        };
      }

      if (candidate.commandForTemplate.startsWith("& '")) {
        const bundledPath = candidate.args[candidate.args.indexOf("-File") + 1];
        return {
          commandForTemplate: candidate.commandForTemplate,
          execFile: "powershell.exe",
          execArgsPrefix: ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", bundledPath]
        };
      }
      return {
        commandForTemplate: candidate.commandForTemplate,
        execFile: candidate.execFile,
        execArgsPrefix: []
      };
    } catch {
      // try next candidate
    }
  }

  throw new Error(
    "Copilot CLI is not available. Install `@github/copilot` or set COPILOT_CLI_PATH to a valid executable."
  );
}

export function buildRunCommandTemplate(
  workspaceConfiguration: vscode.WorkspaceConfiguration,
  executable: CopilotExecutable,
  selectedAgent: string,
  instruction: string
): string {
  const normalizeTemplate = (rawTemplate: string): string => {
    let normalized = rawTemplate.trim();

    // Keep compatibility with older templates that used a non-existent run subcommand.
    normalized = normalized.replace(/\bcopilot\s+run\b/gi, "copilot");
    normalized = normalized.replace(/\brun\s+--agent\b/gi, "--agent");
    normalized = normalized.replace(/\brun\s+-p\b/gi, "-p");

    if (!normalized.includes("{copilotExecutable}") && !normalized.includes("${copilotExecutable}")) {
      if (/^\s*copilot\b/i.test(normalized)) {
        normalized = normalized.replace(/^\s*copilot\b/i, "{copilotExecutable}");
      } else {
        normalized = `{copilotExecutable} ${normalized}`;
      }
    }

    if (!/--agent\s+"?\{agent\}"?/i.test(normalized) && !/--agent\s+"?\$\{agent\}"?/i.test(normalized)) {
      normalized += ' --agent "{agent}"';
    }

    if (!/(^|\s)-p\s+"?\{prompt\}"?|--prompt\s+"?\{prompt\}"?/i.test(normalized) &&
        !/(^|\s)-p\s+"?\$\{prompt\}"?|--prompt\s+"?\$\{prompt\}"?/i.test(normalized)) {
      normalized += ' -p "{prompt}"';
    }

    if (!/--add-dir\s+"?\{workspace\}"?/i.test(normalized) && !/--add-dir\s+"?\$\{workspace\}"?/i.test(normalized)) {
      normalized += ' --add-dir "{workspace}"';
    }

    if (!normalized.includes("--allow-all-tools") && !normalized.includes("--allow-all") && !normalized.includes("--yolo")) {
      normalized += " --allow-all-tools";
    }

    return normalized.replace(/\s+/g, " ").trim();
  };

  const configuredTemplate = workspaceConfiguration.get<string>(CLI_COMMAND_TEMPLATE_SETTING);
  if (configuredTemplate && configuredTemplate.trim().length > 0) {
    return normalizeTemplate(configuredTemplate);
  }

  return normalizeTemplate('{copilotExecutable} --agent "{agent}" -p "{prompt}" --add-dir "{workspace}" --allow-all-tools');
}

export function resolveRunCommand(template: string, values: Record<string, string>): string {
  let resolved = template.replace(/\$\{([a-zA-Z0-9_]+)\}/g, (_, key: string) => values[key] ?? "");
  resolved = resolved.replace(/\{([a-zA-Z0-9_]+)\}/g, (_, key: string) => values[key] ?? "");
  return resolved;
}

export function resolveTerminalName(workspaceConfiguration: vscode.WorkspaceConfiguration): string {
  return workspaceConfiguration.get<string>(CLI_TERMINAL_NAME_SETTING) || "Visual Flow Runner";
}
