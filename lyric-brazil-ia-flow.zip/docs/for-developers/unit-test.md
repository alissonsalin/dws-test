# Unit Test

## Purpose

Unit testing validates changed behavior early and protects against regressions.

## Testing Objectives

1. Validate business behavior of changed logic.
2. Prevent regressions across happy, failure, and edge paths.
3. Keep tests fast, deterministic, and easy to diagnose.
4. Preserve architecture boundaries through focused test scope.

## Test Expectations

- Cover happy paths and error paths for each behavior change.
- Add edge-case tests for boundary conditions and invalid input.
- Keep tests deterministic and easy to diagnose.
- Use mocks at external boundaries only.

## Layer-Based Test Strategy

1. `domain` tests
	- entity invariants
	- value object behavior
	- pure business rules
2. `usecase` tests
	- orchestration behavior
	- business error handling
	- boundary interface interactions
3. `adapter` tests
	- request/response mapping
	- input validation behavior
	- error-to-contract translation
4. `gateway` tests
	- integration mapping logic
	- external error translation
	- timeout/retry behavior at integration boundary

## Java-Specific Expectations

- Use JUnit and Mockito patterns for Java tests.
- For unit tests, prefer `@ExtendWith(MockitoExtension.class)`.
- For Spring-managed slices, use `@MockBean` to replace collaborators.
- Use ArchUnit tests to enforce clean architecture boundaries when Java structure changes.
- Keep Spring tests focused and avoid unnecessary full-context tests.

## Assertion Quality Guidelines

- Assert behavior, not private implementation details.
- Prefer explicit expected values over broad truthy/falsy assertions.
- Verify meaningful interactions with mocks (inputs, call count, order when relevant).
- Keep one behavior focus per test case.

## Quality And Maintainability

- Use behavior-focused test names.
- Follow Arrange, Act, Assert style.
- Keep fixtures local and minimal.
- Remove dead or duplicate tests when replacing behavior.

## Coverage Guidance

- Prioritize high coverage on changed critical paths.
- Cover branches where business behavior diverges.
- Document justified gaps when full coverage is not practical.
- Apply coverage floors as a verification gate for Java clean architecture code:
	- `domain`: 90%+ line coverage
	- `usecase`: 90%+ line coverage
- Do not close Java test work if changed `domain` or `usecase` code is below the floor unless the gap is explicitly documented and approved.

## JaCoCo Coverage Reports (Java)

- Use `.github/skills/jacoco/SKILL.md` as the source of truth for Java JaCoCo setup, report expectations, and coverage verification rules.
- Use `.github/skills/java-cli/SKILL.md` as the source of truth for the exact approved Gradle test-and-coverage command.
- Review the HTML report before finalizing Step 6 and share a short coverage summary.

## Related Technical References

- [Clean Architecture](clean-architecture.md)
- [Arch Unit](arch-unit.md)
- [JaCoCo](jacoco.md)
- [Java](languages/java.md)
- [NodeJS](languages/nodejs.md)
- [Python](languages/python.md)

## Related Flow Steps

- [Step 4 - Start Implementation](../flow/step-4.md)
- [Step 6 - Create Unit Tests](../flow/step-6.md)
- [Step 7 - Compare & Adjust](../flow/step-7.md)
- [Step 9 - Continuous Improvement](../flow/step-9.md)
