# Step 1: Identify Feature Details

## Purpose

The first and most critical step in feature development is to clearly understand **what** needs to be built and **why**. This step establishes the foundation for all downstream work by gathering, documenting, and summarizing requirements in a way that everyone on the team understands consistently.

## Why This Step Matters

Ambiguous or incomplete requirements lead to:
- Misaligned implementations that don't solve the real problem
- Rework and scope creep during development
- Wasted time on features that don't meet user needs
- Testing that validates the wrong behavior

Clear, comprehensive requirements prevent these issues and enable:
- Precise technical design decisions
- Testable acceptance criteria
- Realistic effort estimation
- Team alignment before coding begins

## What You'll Do

1. **Identify the Source** — Ask where the feature details originate:
   - A file (specification, requirements document)
   - Jira or other issue tracking system
   - Confluence or wiki documentation
   - Direct input from stakeholder conversation

2. **Gather Complete Content** — Collect all available information:
   - User stories or acceptance criteria
   - Business context and goals
   - Functional requirements
   - Non-functional considerations (performance, scalability, security)
   - Constraints and dependencies
   - Any existing related code or systems

3. **Lock the Feature Input Early** — If the feature comes from a file:
   - Treat that file as the single source of truth for the feature
   - Avoid introducing requirements that are not supported by that source
   - Reuse the file's stable identifier in downstream design and improvement document names when possible (for example `LRA-1234`)

4. **Summarize Clearly** — Produce a concise, written summary that includes:
   - What is being built
   - Why it's being built (business value)
   - Who will use it (users/stakeholders)
   - Key constraints or assumptions
   - Success criteria

## Output

A clear, documented requirement summary that answers:
- **Problem Statement**: What problem does this feature solve?
- **Scope**: What is in scope, and what is explicitly out of scope?
- **Key Features**: What are the main capabilities required?
- **Success Metrics**: How will we know this feature is successful?

## When To Confirm

Before moving to Step 2, confirm:
- The requirements are understood by both you and the stakeholder
- Ambiguities have been resolved
- Scope is realistic for the project timeline
- You have everything needed to design the solution
- If a source file exists, it is clearly identified as the authoritative feature input

---

**Next Step:** [Step 2 - Create Technical Design](step-2.md)
