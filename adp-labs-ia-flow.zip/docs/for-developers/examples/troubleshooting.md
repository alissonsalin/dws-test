# Example: Troubleshooting & Debugging Document

This page shows what a completed Step 8 troubleshooting document looks like.
The file is saved as `documentation/<feature-name>/<feature-name>-troubleshooting.md`.

---

## Feature: Client Registration API (`LRA-1042`)

---

## Issue Log

### Issue 1 — `application.properties` generated instead of `application.yml`

**Symptom:** Spring Boot project scaffolded with `application.properties` despite YAML convention.

**Root Cause:** Default Copilot training behavior falls back to `.properties` when the prohibition is not explicit in the instruction file.

**Fix Applied:** Added `Never create application.properties or any .properties configuration file` to `spring.instructions.md`.

**Status:** Resolved — re-ran Step 4, YAML files generated correctly.

---

### Issue 2 — ArchUnit test failing on `gateway` import in `usecase`

**Symptom:**

```
java.lang.AssertionError: Architecture Violation [Priority: MEDIUM]
Rule 'classes that reside in a package '..usecase..' should not depend on classes
that reside in a package '..gateway..' was violated (1 times):
```

**Root Cause:** `RegisterClientUseCase` was directly importing `ClientRepositoryJdbc` (the JDBC gateway implementation) instead of the `ClientRepository` interface defined in the `domain` layer.

**Fix Applied:** Changed the constructor parameter type from `ClientRepositoryJdbc` to the `ClientRepository` interface. Spring injects the correct implementation at runtime.

```java
// Before (wrong — gateway dependency in usecase)
public RegisterClientUseCase(ClientRepositoryJdbc repository) { ... }

// After (correct — domain interface dependency)
public RegisterClientUseCase(ClientRepository repository) { ... }
```

**Status:** Resolved — ArchUnit tests pass.

---

### Issue 3 — `409 Conflict` not returned for duplicate email

**Symptom:** Submitting a duplicate email returned `500 Internal Server Error` instead of `409 Conflict`.

**Root Cause:** `DuplicateEmailException` was thrown in the use case but no `@ExceptionHandler` existed in the controller to map it to a HTTP response.

**Fix Applied:** Added exception handler in `ClientController`:

```java
@ExceptionHandler(DuplicateEmailException.class)
@ResponseStatus(HttpStatus.CONFLICT)
public ErrorResponse handleDuplicate(DuplicateEmailException ex) {
    return new ErrorResponse("DUPLICATE_EMAIL", ex.getMessage());
}
```

**Status:** Resolved — controller test added to cover 409 path.

---

## Monitoring — Splunk Queries

### Track registration errors

```spl
index=app source="client-service" level=ERROR "RegisterClientUseCase"
| stats count by message
| sort -count
```

### Track duplicate email rejections

```spl
index=app source="client-service" "DUPLICATE_EMAIL"
| timechart span=1h count
```

### Track successful registrations

```spl
index=app source="client-service" "Client registered successfully"
| timechart span=1h count
```

---

**Related:** [Step 8 - Troubleshooting & Debugging](../../flow/step-8.md)
