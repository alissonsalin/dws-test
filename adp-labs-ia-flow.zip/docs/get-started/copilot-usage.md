# Copilot Usage

After installation, use Copilot Chat normally in the target repository. Project instructions are applied automatically.

## Example Prompts

1. Follow project instructions and create a technical design for this feature.
2. Implement this change using clean architecture from the repository instructions.
3. Update tests according to the testing instruction file.
4. For docs updates, follow documentation rules from .github/instructions.

## Developer References

1. [For developers - Overview](../for-developers/overview.md)
2. [For developers - Clean Architecture](../for-developers/clean-architecture.md)
3. [For developers - Arch Unit](../for-developers/arch-unit.md)
4. [For developers - Languages](../for-developers/languages/java.md)
5. [For developers - Unit test](../for-developers/unit-test.md)

## Next Step

If needed, go to [Troubleshooting](troubleshooting.md).