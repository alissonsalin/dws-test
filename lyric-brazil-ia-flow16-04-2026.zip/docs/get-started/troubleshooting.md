# Troubleshooting

Use these checks if setup or instruction behavior is not working as expected.

1. If files were not copied, re-run the installer and verify the target path.
2. If Copilot seems to ignore rules, open a new chat session after installation.
3. In IntelliJ, if instructions do not seem active, verify the plugin is enabled and restart the IDE.
4. If only some rules apply, narrow applyTo patterns in .github/instructions files.

## Back to Overview

Return to [Get Started Overview](../get-started.md).