# Step 5: Security - Validate and Update Code and Libraries

## Mandatory Delegation

This step is performed by the `verifier` agent. If vulnerabilities are detected, they must be resolved by delegating back to the `coder` agent before restarting the security validation.

## Purpose

Before moving to testing, you must ensure the code is secure and all dependencies are up-to-date and free of known vulnerabilities. This step prevents security issues from reaching production and ensures compliance with security best practices.

## Why This Step Matters

Security vulnerabilities can:
- Expose user data or systems to attackers
- Violate compliance requirements (GDPR, SOC 2, etc.)
- Damage customer trust
- Result in costly incidents and legal action

Validating security early:
- Catches vulnerabilities before they proliferate through the codebase
- Ensures dependencies are patched against known issues
- Establishes secure coding practices from the start

## What You'll Do

1. **Code Security Review**:
   - Ensure sensitive data (passwords, tokens, keys) is never logged or exposed
   - Validate and sanitize all external inputs (forms, API calls, file uploads)
   - Check for common vulnerabilities: SQL injection, XSS, CSRF, insecure serialization
   - Verify cryptographic operations use appropriate algorithms (no MD5, DES)
   - Confirm secure storage of secrets (environment variables, not hardcoded)

2. **Dependency Vulnerability Scan**:
   - Follow the repository command skills for vulnerability validation command usage
   - Skip security validation by default unless it was explicitly requested
   - If the workflow is running interactively, ask once whether to run security validation before executing the approved security-validation command
   - For Java workflows, use the dedicated Step 5 CVE scan task from `.github/skills/java-cli/SKILL.md`
   - `dependencyUpdates` may be used for dependency update analysis, but it does not count as a dedicated CVE scan by itself
   - Run only the approved validation flow and avoid extra diagnostic validation commands
   - If security validation is skipped because it was not requested or because of user choice or command policy, record the reason explicitly
   - Review and address identified vulnerabilities

3. **Update Outdated Libraries**:
   - Update any outdated framework or library versions to latest secure versions
   - Ensure compatibility before and after updates
   - Document any breaking changes

4. **Compliance Checks**:
   - Verify secure handling of user data (encryption, access controls)
   - Ensure authentication and authorization mechanisms are properly implemented
   - Check that audit logging is in place for sensitive operations

## Command Policy for This Step

- Do not define ad-hoc commands in this step; use the repository command skills as the source of truth.
- For Java workflows, use `.github/skills/java-cli/SKILL.md` for the exact approved security-validation command.
- For NodeJS and Python workflows, use `.github/skills/node-python-cli/SKILL.md` for exact security-command selection from repository scripts and configuration.
- Do not switch between equivalent security commands from run to run when the repository-approved command is already defined.
- Run security validation only as allowed by that command policy.
- If validation finds issues, fix code or dependencies first and rerun only when the command policy allows it.
- For recoverable issues, keep this step in progress while remediation is ongoing instead of treating it as a hard failure.

## Output

- Code reviewed and confirmed free of common security issues
- All dependencies updated to latest secure versions
- Dedicated CVE scan passed (if run)
- Documented security considerations for the feature
- Any security debt or open issues logged for future mitigation

## When To Proceed

Before moving to Step 6:
- Security review is complete
- All identified vulnerabilities have been addressed or documented
- Dependency updates are complete and tested
- Dedicated CVE scan shows no critical or high-severity issues (if run)
- The security-validation run or skip decision has been explicitly recorded
- Command execution followed the repository command-line policy without extra validation commands

---

**Previous Step:** [Step 4 - Start Implementation](step-4.md)  
**Next Step:** [Step 6 - Test Verification and Coverage](step-6.md)
