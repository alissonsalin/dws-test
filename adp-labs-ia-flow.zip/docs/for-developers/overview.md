# For Developers - Overview

## Purpose

This section defines the technical implementation model used by this repository: architecture boundaries, stack conventions, architecture tests, and test quality rules.

## Solution Baseline

1. Implement business behavior in `domain` and `usecase` layers.
2. Keep adapters/controllers thin and focused on mapping.
3. Isolate infrastructure concerns in `gateway` implementations.
4. Enforce boundaries with architecture tests (ArchUnit for Java).
5. Validate behavior with deterministic unit tests and boundary-focused mocks.

## What This Section Covers

- Clear clean architecture layer responsibilities.
- Human loop guidance for collaborative checkpoints across all workflow stages.
- Tech refresh workflow guidance for migration-oriented initiatives.
- Language-specific implementation conventions (Java, NodeJS, Python).
- Architecture test constraints with explicit layer dependency rules.
- Unit testing strategy, isolation rules, and maintainability guidance.

## Technical Design Principles

1. Dependency direction must be inward.
2. Frameworks must not leak into business rules.
3. Cross-layer communication should use explicit DTOs/contracts.
4. Error handling must be explicit, deterministic, and testable.
5. Security checks belong at boundaries, not scattered in core logic.

## Recommended Reading Order

1. [Custom Instructions](custom-instructions.md)
2. [Agents](agents.md)
3. [Skills](skills.md)
4. [Human loop](../human-loop.md) for interaction checkpoints and quality gates
5. [Tech Refresh](tech-refresh.md) for migration-focused work
6. [Clean Architecture](clean-architecture.md)
7. [Arch Unit](arch-unit.md)
8. [Languages - Java](languages/java.md), [NodeJS](languages/nodejs.md), [Python](languages/python.md)
9. [Lombok](lombok.md) (Java features only)
10. [Unit test](unit-test.md)

## Related Flow Steps

- [Step 4 - Start Implementation](../flow/step-4.md)
- [Step 6 - Create Unit Tests](../flow/step-6.md)
- [Step 7 - Compare & Adjust](../flow/step-7.md)

## Instruction Sources

- `.github/instructions/clean-architecture.instructions.md`
- `.github/instructions/tech-refresh.instructions.md`
- `.github/instructions/java.instructions.md`
- `.github/instructions/nodejs.instructions.md`
- `.github/instructions/python.instructions.md`
- `.github/instructions/spring.instructions.md`
- `.github/instructions/archunit.instructions.md`
- `.github/instructions/lombok.instructions.md`
- `.github/instructions/testing.instructions.md`
